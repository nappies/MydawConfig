
reaper.Main_OnCommand(40289,0) --Item: Unselect (clear selection of) all items
reaper.Main_OnCommand(40421,0) --Item: Select all items in track
reaper.Main_OnCommand(40332,0) --Envelope: Select all points
