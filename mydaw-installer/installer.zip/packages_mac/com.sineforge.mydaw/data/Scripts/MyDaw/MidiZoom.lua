local midieditor =  reaper.MIDIEditor_GetActive()


reaper.MIDIEditor_OnCommand(midieditor, 40466) --- zoom to content 



reaper.MIDIEditor_OnCommand(midieditor, 40467) ---rm
