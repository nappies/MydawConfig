
local items = reaper.CountSelectedMediaItems()
if items == 0 then return end

function DB(vol) return 20*math.log(vol, 10) end

function VOL(db) return 10^(0.05*db) end


reaper.Undo_BeginBlock() reaper.PreventUIRefresh(1)

reaper.Main_OnCommand(reaper.NamedCommandLookup('_BR_NORMALIZE_LOUDNESS_ITEMS23'), 0)  -- Item properties: Normalize items


t = {}

for i = 0,items-1 do
  local item = reaper.GetSelectedMediaItem(0,i)
  local take = reaper.GetActiveTake(item)
  if not take then goto cnt end
  local tr = reaper.GetMediaItem_Track(item)
  vol = reaper.GetMediaItemTakeInfo_Value(take, 'D_VOL')
  vol_db = DB(vol)
  tr_str = tostring(tr)
  if not t[tr_str] then t[tr_str] = {} end
  if t[tr_str][3] then
    if vol_db > t[tr_str][3] then t[tr_str] = {tr,item,vol_db} end
  else t[tr_str] = {tr,item,vol_db} end
  ::cnt::
end

for _,v in pairs(t) do
  local tr = v[1]
  local item = v[2]
  vol_db = v[3]
  tr_vol = reaper.GetMediaTrackInfo_Value(tr, 'D_VOL')
  tr_vol_db = DB(tr_vol)
  reaper.SetMediaTrackInfo_Value(tr, 'D_VOL',VOL(tr_vol_db-vol_db))
end




 


reaper.PreventUIRefresh(-1) reaper.Undo_EndBlock('normalize items + compensation', -1)
