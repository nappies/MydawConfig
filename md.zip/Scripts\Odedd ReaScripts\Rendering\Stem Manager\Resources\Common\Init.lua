-- @noindex

_OD_ISMAC = (reaper.GetOS():lower():match("osx") or reaper.GetOS():lower():match("macos")) ~= nil