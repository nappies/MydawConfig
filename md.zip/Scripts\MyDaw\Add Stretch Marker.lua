package.path = debug.getinfo(1, "S").source:match [[^@?(.*[\/])[^\/]-$]] .. "?.lua;" -- GET DIRECTORY FOR REQUIRE
require("Functions")

israzor = IsRazorEdits()


function getitems()
    lastitem = reaper.GetExtState("MyDaw", "Click On Bottom Half")
    if not lastitem or lastitem == "" then
        return
    end

    item = GuidToItem(lastitem)

    if not item then
        return
    end

    reaper.SetMediaItemSelected(item, true)

    reaper.Main_OnCommand(41842, 0) -----add strech

    reaper.SetMediaItemSelected(item, false)
end



function justinserttoitems()
 

    local items = reaper.CountSelectedMediaItems()

    if items == 0 then
        getitems()
    else
        reaper.Main_OnCommand(41842, 0) -----add strech
    end
end

if not israzor then
    reaper.Undo_BeginBlock()
    reaper.PreventUIRefresh(1)

    justinserttoitems()

    reaper.PreventUIRefresh(-1)
    reaper.Undo_EndBlock("Insert Marker", -1)
else
    reaper.Undo_BeginBlock()
    reaper.PreventUIRefresh(1)

    reaper.Main_OnCommand(41843, 0) ----add strech a time

    reaper.PreventUIRefresh(-1)
    reaper.Undo_EndBlock("Insert Marker", -1)
end

