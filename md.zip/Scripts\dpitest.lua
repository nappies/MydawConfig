desired_width, desired_height = 150, 150 -- size of gfx window
font_size = 18
gfx.setfont(1, "Arial", font_size)

-- Get the retina scale
local OS = reaper.GetOS()
scale, gfx.ext_retina = 1, 1 -- init with 1

-- Open gfx window
gfx.init("Retina test", desired_width, desired_height )

function run()
  if scale ~= gfx.ext_retina then -- dpi changed (either initially or from the user moving the window or the OS changing
    scale = gfx.ext_retina
    gfx.setfont(1, "Arial", font_size * (1+scale)*0.5)
    -- Resize manually gfx window, if not MacOS
    if OS ~= "OSX64" and OS ~= "OSX32" and OS ~= "macOS-arm64" then
      gfx.init("", desired_width*scale, desired_height*scale)
    end
  end
 
  -- Draw stuff
  gfx.x, gfx.y = 0, 0
  gfx.drawstr( string.format("Width: %.1f\nHeight: %.1f\nFont size: %i\nRetina: %.2f\nOS: %s",
      gfx.w, gfx.h, gfx.texth, gfx.ext_retina, OS) )
  local mid, p = gfx.w/2, math.pi
 gfx.update()

  local c = gfx.getchar() -- returns <0 if the window was closed by the user, or 27 if the user hit escape
  if c >= 0 and c ~= 27 then
    reaper.defer(run)
  end
end

run()
