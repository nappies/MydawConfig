--Based on Kawa PitchBendGlide



function m(s)
  reaper.ShowConsoleMsg(tostring(s) .. "\n")
 end


function deepcopy(t)
    local n = type(t)
    local e
    if n == "table" then
        e = {}
        for t, n in next, t, nil do
            e[deepcopy(t)] = deepcopy(n)
        end
        setmetatable(e, deepcopy(getmetatable(t)))
    else
        e = t
    end
    return e
end


function string:split(e)
    local t, e = e or ":", {}
    local t = string.format("([^%s]+)", t)
    self:gsub(
        t,
        function(t)
            e[#e + 1] = t
        end
    )
    return e
end

local i = 300
local x = true
local G = true

local e = 40659
local o = 40681
local s = 40832
local k = 40501
local e = 40003
local S = 40214
local M = 1011
local N = 1012
local I = 40112
local P = 40111
local e = 40468
local e = 40726
local e = 40725
local T = 40466
local n = "kawa_MidiClip"

local t = {}







function createMIDIClip(g)
    local e = {}
    e.editorHwnd = nil
    e.mediaTrack = nil
    e.mediaItem = nil
    e.take = nil
    e.mediaItemInfo = {}
    e.editingNotes = {}
    e.m_originalNotes = {}
    e.m_existMaxNoteIdx = -1
    e.m_firstSelectionCheck = nil
    e.m_processLimitNoteNum = i
    e.m_processLimitNoteNum_min = 0
    function e:isMidiEditorActive()
        return (self.editorHwnd ~= nil)
    end
    function e:getMidiEditorMode()
        if (self.editorHwnd == nil) then
            return nil
        end
        local e = reaper.MIDIEditor_GetMode(self.editorHwnd)
        return e
    end
    function e:isEditorMode_PianoRoll()
        return (self:getMidiEditorMode() == 0)
    end
    function e:isEditorMode_EventList()
        return (self:getMidiEditorMode() == 1)
    end
    function e:isEditorMode_Notation()
        return (self:getMidiEditorMode() == 2)
    end
    function e:isSelectionInEditingNotes(e)
        if (self.m_firstSelectionCheck == nil or e ~= nil) then
            for t, e in ipairs(self.editingNotes) do
                if (e.selection == true) then
                    self.m_isSelection = true
                    break
                end
                self.m_isSelection = false
            end
            self.m_firstSelectionCheck = true
        end
        return self.m_isSelection
    end
    function e:checkProcessLimitNum()
       
        if (self:isMidiEditorActive() ~= true) then
            return false
        end
        local e = self:_checkProcessLimitNum()
        if (e ~= true and #self.editingNotes > 1 and x == true) then
            local e = self.m_processLimitNoteNum
            reaper.ShowMessageBox("over " .. tostring(e) .. " notes.\nstop process.", "stop", 0)
        end
        return e
    end
    function e:setProcessLimitNum(e)
        self.m_processLimitNoteNum = e
    end
    function e:setProcessLimitNum_Min(e)
        self.m_processLimitNoteNum_min = e
    end
    function e:callReaperCommand(e)
        if (self:isMidiEditorActive()) then
            reaper.MIDIEditor_OnCommand(self.editorHwnd, e)
        end
    end
    function e:getMIDIEditorHwnd()
        return self.editorHwnd
    end
    
    function e:changeOctave(e)
        self:transpose(12 * math.floor(e))
    end
    function e:transpose(e)
        local t = math.floor(e)
        local e = self:_detectTargetNotes()
        for n, e in ipairs(e) do
            e.pitch = e.pitch + t
            if (e.pitch < 0) then
                e.pitch = e.pitch + 127 - 7
            end
            if (e.pitch > 127) then
                e.pitch = e.pitch - 127 + 7
            end
        end
    end
    function e:changeLengh(e)
        local t = e or .8
        local e = self:_detectTargetNotes()
        for n, e in ipairs(e) do
            local n = e.startpos + e.length * t
            if (self.mediaItemInfo.endProjQN >= n) then
                e.length = e.length * t
                e.endpos = e.startpos + e.length
            end
        end
    end
    function e:showItemStateChunk()
        local t, e = reaper.GetItemStateChunk(self.mediaItem, "", false)
        reaper.ShowConsoleMsg(e)
    end
    function e:changeStartPos(e)
        local t = e or .8
        local e = self:_detectTargetNotes()
        for n, e in ipairs(e) do
            local t = e.length * (1 - t)
            local n = e.startpos - t
            if (self.mediaItemInfo.startProjQN <= n) then
                e.startpos = e.startpos - t
                e.length = e.length + t
                e.endpos = e.startpos + e.length
            end
        end
    end
    function e:changeVelocity(e)
        local t = e or .8
        local e = self:_detectTargetNotes()
        for n, e in ipairs(e) do
            if (t > 1) then
                e.vel = math.floor(e.vel * t)
            elseif (t <= 1) then
                e.vel = math.floor(e.vel * t)
            end
            if (e.vel > 127) then
                e.vel = 127
            end
            if (e.vel < 1) then
                e.vel = 1
            end
        end
    end
    function e:changeVelocityDistance(e)
        local o = e or .2
        local n = self:_detectTargetNotes()
        local e = 0
        local t = 200
        for o, n in ipairs(n) do
            t = math.min(n.vel, t)
            e = math.max(n.vel, e)
        end
        local t = (e + t) / 2
        for n, e in ipairs(n) do
            local n = 0
            if (e.vel >= t) then
                n = (e.vel - t) * o
            else
                n = -(t - e.vel) * o
            end
            e.vel = math.floor(e.vel + n)
            if (e.vel > 127) then
                e.vel = 127
            end
            if (e.vel < 0) then
                e.vel = 1
            end
        end
    end
    function e:randomVelocity(e)
        local o = e or 60
        local e = reaper.GetExtState(n, a)
        local l = reaper.GetCursorPosition()
        e = tonumber(e) or 0
        local t = self:_detectTargetNotes()
        if (math.floor(e * 1e3) / 1e3 ~= math.floor(l * 1e3) / 1e3) then
            local e = self:_detectTargetNotes()
            local e = table.toString(e)
            reaper.SetExtState(n, C, e, false)
        else
            local e = reaper.GetExtState(n, C)
            t = table.fromString(e)
            if (#t < 1) then
                local e = self:_detectTargetNotes()
            end
        end
        local e = self:_detectTargetNotes()
        if (#e ~= #t) then
            t = deepcopy(e)
        end
        for n, e in ipairs(e) do
            e.vel = t[n].vel + (math.random() * o) - (o / 2)
            e.vel = math.floor(e.vel)
            if (e.vel > 127) then
                e.vel = 127
            end
            if (e.vel < 0) then
                e.vel = 1
            end
        end
        reaper.SetExtState(n, a, tostring(l), false)
    end
    function e:fixVelocity()
        local e, t = reaper.GetUserInputs("fix Velocity", 7, "velocity (1 ~127)", "90,--,--,--,--,--,--")
        if (e ~= true) then
            return
        end
        local t = tonumber(t:split(",")[1]) or 90
        local e = self:_detectTargetNotes()
        for n, e in ipairs(e) do
            e.vel = math.floor(t)
            if (e.vel > 127) then
                e.vel = 127
            end
            if (e.vel < 0) then
                e.vel = 1
            end
        end
    end
    function e:velocityInterpolation(n, e)
        local t = self:_detectTargetNotes()
        table.sort(
            t,
            function(e, t)
                return (e.startpos < t.startpos)
            end
        )
        local r = n or 3
        local i = e or 0
        local function a(n, t, e, i)
            local o = 0
            if (e == 1) then
                o = n * t
            elseif (e == 2) then
                local e = n * t
                o = e + math.sin(math.rad(360 * t)) * n / 4
            elseif (e == 3) then
                local function l(e)
                    e = e * 2
                    if e < 1 then
                        return .5 * e * e * e
                    else
                        e = e - 2
                        return .5 * (e * e * e + 2)
                    end
                end
                local e = l(t)
                o = n * e
            end
            local e = 0
            if (t ~= 0 and t ~= 1) then
                e = i * math.random()
            end
            return o + e
        end
        local l = t[1].startpos
        local e = t[#t].startpos
        local n = t[1].vel
        local c = t[#t].vel
        local o = (e - l) or 1
        local c = c - n
        if (o <= 0) then
            return
        end
        for t, e in ipairs(t) do
            local t = (e.startpos - l) / o
            local t = n + a(c, t, r, i)
            e.vel = t
            if (e.vel > 127) then
                e.vel = 127 - (e.vel - 127)
            end
            if (e.vel < 0) then
                e.vel = 1 - e.vel
            end
            e.vel = math.floor(e.vel)
        end
    end
    function e:splitNote(t)
        local n = self:_detectTargetNotes()
        local e = t
        local l = self:_getSelectionNoteCount(n)
        local o = {}
        for n, e in ipairs(n) do
            if (e.length > .001) then
                e.length = (e.length / t)
                e.endpos = e.startpos + e.length - 1e-6
                for n = 1, t - 1, 1 do
                    local t = deepcopy(e)
                    t.startpos = t.startpos + (t.length) * n
                    t.endpos = t.startpos + e.length - 1e-5
                    t.selection = true
                    table.insert(o, t)
                end
            end
        end
        self:insertNotesFromC(o)
        if (l == 0) then
            for t, e in ipairs(n) do
                e.selection = true
            end
        end
    end
    function e:copyToOctaveUp()
        local e = self:_detectTargetNotes()
        for t, e in ipairs(e) do
            local e = deepcopy(e)
            e.pitch = e.pitch + 12
            if (e.pitch < 0) then
                e.pitch = e.pitch + 127 - 7
            end
            if (e.pitch > 127) then
                e.pitch = e.pitch - 127 + 7
            end
            self:insertNoteFromC(e)
        end
    end
    function e:copyToOctaveDown()
        local e = self:_detectTargetNotes()
        for t, e in ipairs(e) do
            local e = deepcopy(e)
            e.pitch = e.pitch - 12
            if (e.pitch < 0) then
                e.pitch = e.pitch + 127 - 7
            end
            if (e.pitch > 127) then
                e.pitch = e.pitch - 127 + 7
            end
            self:insertNoteFromC(e)
        end
    end
    function e:resolveOverLap()
        local t = self:_detectTargetNotes()
        table.sort(
            t,
            function(e, t)
                return (e.startpos < t.startpos)
            end
        )
        for n, e in ipairs(t) do
            for n, t in ipairs(t) do
                if (e.idx <= t.idx and e.startpos ~= t.startpos and e.endpos > t.startpos) then
                    e.endpos = t.startpos
                    e.length = e.endpos - e.startpos
                end
            end
        end
    end
    function e:deleteAllNote()
        self.editingNotes = {}
    end
    function e:nudgeNote(e)
        local t = e or .8
        local e = 1 / 4
        local n = 1 / 32
        local t = e * t
        local e = self:_detectTargetNotes()
        for o, e in ipairs(e) do
            if (e.length > n) then
                e.startpos = e.startpos + t
                e.endpos = e.endpos + t
                e.length = e.endpos - e.startpos
            end
        end
    end
    function e:strokeDown(t)
        local e = self:_detectTargetNotes()
        local l = self:_getExistStartPosTable(e)
        local o = t or .005
        local n = 1
        for l, t in ipairs(l) do
            local t, e = self:_getSameStartPosNotes(t, e, n)
            for n, e in ipairs(t) do
                e.startpos = e.startpos + o * (#t - n)
            end
        end
    end
    function e:strokeUp(t)
        local e = self:_detectTargetNotes()
        local o = self:_getExistStartPosTable(e)
        local n = t or .015
        local l = 1
        for o, t in ipairs(o) do
            local e, t = self:_getSameStartPosNotes(t, e, l)
            for t, e in ipairs(e) do
                e.startpos = e.startpos + n * (t - 1)
            end
        end
    end
    function e:simpleDuplicate()
        local i = self.mediaItemInfo
        local t = self:_detectTargetNotes()
        local e = self:_getFinalEndPos(t)
        local n = self:_getFirstStartPos(t)
        local o = e - n
        local n = {}
        for l, e in ipairs(t) do
            local e = deepcopy(e)
            e.startpos = e.startpos + o
            e.endpos = e.endpos + o
            if (i.endProjQN >= e.endpos) then
                e.selection = true
                table.insert(n, e)
            else
            end
            t[l].selection = false
        end
        self:insertNotesFromC(n)
    end
    function e:simpleDuplicateType3()
        local o = self:_detectTargetNotes()
        local n = self:_getFinalEndPos(o)
        local e = self:_getFirstStartPos(o)
        local t = reaper.TimeMap_QNToTime(e)
        local e = n - e
        local l, n, t = reaper.TimeMap_GetTimeSigAtTime(0, t + .001)
        local t = 0
        local n = l * (4 / n)
        if (e <= .25) then
            t = .25 - e
        elseif (e <= .5) then
            t = .5 - e
        elseif (e <= 1) then
            t = 1 - e
        elseif (e <= 2) then
            t = 2 - e
        elseif (e <= n) then
            t = n - e
        else
            local o = math.floor(e / n)
            local n = (o + 1) * n
            t = n - e
        end
        e = e + t
        e = math.floor((e) * 100) / 100
        local l = {}
        for t, n in ipairs(o) do
            local t = deepcopy(n)
            t.startpos = t.startpos + e
            t.endpos = t.endpos + e
            n.selection = false
            if (self.mediaItemInfo.endProjQN >= t.endpos) then
                t.selection = true
                table.insert(l, t)
            else
            end
            o.selection = false
        end
        self:insertNotesFromC(l)
    end
    function e:growUp(n, t)
        local e = self:_detectTargetNotes()
        local i = t or .25
        local a = {}
        local l = {}
        local n = n or 4
        local function r(e)
            return i / (n / e)
        end
        for e, t in ipairs(e) do
            local o = -1
            for l = n, 1, -1 do
                local e = deepcopy(t)
                e.pitch = t.pitch - (n) + l
                local n = r(l)
                e.startpos = t.startpos + (i * n)
                if (o ~= -1) then
                    e.endpos = o + .1
                end
                table.insert(a, e)
                o = e.startpos
            end
            table.insert(l, t)
        end
        self:deleteNotes(l)
        self:insertNotesFromC(a)
    end
    function e:twoNoteNudge(e)
        local n = self:_getSelectionNotes()
        if (#n ~= 2) then
            return
        end
        table.sort(
            n,
            function(t, e)
                return (t.startpos < e.startpos)
            end
        )
        local o = e or .9
        local t = n[1]
        local e = n[2]
        if ((t.length < .015 or e.length < .015) and t.startpos >= e.startpos) then
            return
        end
        local o = t.length * o
        local l = t.startpos + o
        local i = l
        local a = e.endpos - i
        if (o > .01 and a > .01 and l < e.endpos) then
            t.length = o
            t.endpos = l
            e.startpos = i
            e.length = a
        end
        self:deleteNotes(n)
        self:insertNoteFromC(t)
        self:insertNoteFromC(e)
    end
    function e:selectAllNoteCurrentTake()
        reaper.PreventUIRefresh(1)
        reaper.MIDIEditor_OnCommand(self.editorHwnd, S)
        reaper.PreventUIRefresh(-1)
        reaper.MIDI_SelectAll(self.take, true)
    end
    function e:noteLengthToEnd()
        local e = self:_detectTargetNotes()
        local t = self:_getFinalEndPos(e)
        for n, e in ipairs(e) do
            e.endpos = t
        end
    end
    function e:legatoType2()
        local n = self:_detectTargetNotes()
        local e = self:_getExistStartPosTable(n)
        local l = 1
        for t, o in ipairs(e) do
            local n, l = self:_getSameStartPosNotes(o, n, l)
            for l, n in pairs(n) do
                local n = n
                if (t + 1 <= #e and n.startpos >= o and n.endpos < e[t + 1] and n.startpos < e[t + 1]) then
                    n.endpos = e[t + 1]
                end
            end
        end
    end
    function e:changeLengthType1(e)
        local o = self:_detectTargetNotes()
        local n = nil
        local i = (e == true) or false
        local function a(t)
            local e = nil
            if (t < .25) then
                e = .25
            elseif (t < .5) then
                e = .5
            elseif (t < 1) then
                e = 1
            elseif (t < 2) then
                e = 2
            elseif (t < 4) then
                e = 4
            else
                e = .125
            end
            return e
        end
        local function l(t)
            local e = nil
            if (t >= 4) then
                e = 2
            elseif (t >= 2) then
                e = 1
            elseif (t >= 1) then
                e = .5
            elseif (t >= .5) then
                e = .25
            elseif (t >= .25) then
                e = .125
            else
                e = 4
            end
            return e
        end
        for t, e in ipairs(o) do
            if (n == nil) then
                if (i == true) then
                    n = a(e.length)
                else
                    n = l(e.length)
                end
            end
            e.length = n
            e.endpos = e.startpos + e.length
        end
    end
    function e:changeLengthType2(e)
        local a = self:_detectTargetNotes()
        local n = nil
        local i = (e == true) or false
        local function o(t)
            local e = nil
            if (t < .25) then
                e = .25
            elseif (t < .5) then
                e = .5
            elseif (t < 1) then
                e = 1
            elseif (t < 2) then
                e = 2
            elseif (t < 4) then
                e = 4
            else
                e = .125
            end
            return e
        end
        local function l(t)
            local e = nil
            if (t >= 4) then
                e = 2
            elseif (t >= 2) then
                e = 1
            elseif (t >= 1) then
                e = .5
            elseif (t >= .5) then
                e = .25
            elseif (t >= .25) then
                e = .125
            else
                e = 4
            end
            return e
        end
        for t, e in ipairs(a) do
            if (i == true) then
                n = o(e.length)
            else
                n = l(e.length)
            end
            e.length = n
            e.endpos = e.startpos + e.length
        end
    end
    function e:selectedNotesToNewMediaClip(o, n, t)
        local e = self:_detectTargetNotes()
        if (#e < 1 or self:_isExistSelectionNotes(e) == false) then
            return
        end
        local o = o or false
        local n = n or false
        local l = t or false
        local i = self.mediaTrack
        local t = self.mediaTrack
        if (n == true) then
            local e = reaper.GetMediaTrackInfo_Value(i, "IP_TRACKNUMBER")
            t = reaper.InsertTrackAtIndex(e, l)
            local n = 0
            t = reaper.GetTrack(n, e)
        end
        local n = self.mediaItem
        local n = self.mediaItemInfo
        local t = reaper.CreateNewMIDIItemInProj(t, n.startTime, n.endTime, false)
        local t = reaper.GetMediaItemTake(t, 0)
        local n = {}
        for l, e in ipairs(e) do
            local c = e.selection or false
            local s = e.mute
            local d = reaper.MIDI_GetPPQPosFromProjQN(t, e.startpos)
            local r = reaper.MIDI_GetPPQPosFromProjQN(t, e.endpos)
            local a = e.chan
            local l = e.pitch
            local i = e.vel
            reaper.MIDI_InsertNote(t, c, s, d, r, a, l, i, false)
            if (o == true) then
                table.insert(n, e)
            end
        end
        self:deleteNotes(n)
    end
    function e:explodeNoteByPitchClass(o, i, n)
        local e = self:_detectTargetNotes()
        if (#e < 1) then
            return
        end
        local t = {}
        local r = createPitchInfo()
        local l = o or false
        local i = i or false
        local a = n or false
        for e, n in ipairs(e) do
            local e = n.pitch
            local o = (e % 12)
            local e = r:getPitchName(tostring(o), false)
            if (t[e] == nil) then
                t[e] = {}
                t[e].key = o
                t[e].pitchNameStr = e
                t[e].notes = {}
            end
            table.insert(t[e].notes, deepcopy(n))
            if (l == true) then
                n.mute = true
            end
        end
        local n = {}
        for t, e in pairs(t) do
            table.insert(n, e)
        end
        table.sort(
            n,
            function(e, t)
                return (e.key > t.key)
            end
        )
        local t = self.mediaTrack
        local e = self.mediaTrack
        local l = self.mediaItem
        local o = self.mediaItemInfo
        local l = reaper.GetMediaItemTake(l, reaper.GetMediaItemInfo_Value(l, "I_CURTAKE"))
        local c, r = reaper.GetSetMediaTrackInfo_String(t, "P_NAME", "", false)
        local c, l = reaper.GetSetMediaItemTakeInfo_String(l, "P_NAME", "", false)
        for c, n in pairs(n) do
            keyPitchName = n.pitchNameStr
            if (i == true) then
                local t = reaper.GetMediaTrackInfo_Value(t, "IP_TRACKNUMBER")
                e = reaper.InsertTrackAtIndex(t, a)
                local n = 0
                e = reaper.GetTrack(n, t)
                local t = r .. " - " .. keyPitchName
                reaper.GetSetMediaTrackInfo_String(e, "P_NAME", t, true)
            end
            local e = reaper.CreateNewMIDIItemInProj(e, o.startTime, o.endTime, false)
            local t = reaper.GetMediaItemTake(e, 0)
            reaper.GetSetMediaItemTakeInfo_String(t, "P_NAME", l .. " - " .. keyPitchName, true)
            for n, e in ipairs(n.notes) do
                local n = e.selection or false
                local o = e.mute
                local l = reaper.MIDI_GetPPQPosFromProjQN(t, e.startpos)
                local i = reaper.MIDI_GetPPQPosFromProjQN(t, e.endpos)
                local a = e.chan
                local r = e.pitch
                local e = e.vel
                reaper.MIDI_InsertNote(t, n, o, l, i, a, r, e, false)
            end
        end
    end
    function e:addBPMMarker()
        local e = 120
        local r = reaper.GetCursorPosition()
        local n = 0
        local e = reaper.CountTempoTimeSigMarkers(n) + 1
        local a, o, e = reaper.TimeMap_GetTimeSigAtTime(n, r)
        local t, e =
            reaper.GetUserInputs(
            "Add BPM Marker",
            7,
            "BPM( 60 ~ 300 ),Time Sig , / Time Sig Denom",
            tostring(e) .. "," .. tostring(a) .. "," .. tostring(o) .. "," .. "--,--,--,--"
        )
        if (t == nil or t == false) then
            return
        end
        local c = tonumber(e:split(",")[1] or "120") or 120
        local i = 0
        local l = 0
        if
            (e:split(",")[2] ~= nil and e:split(",")[3] ~= nil and e:split(",")[2] ~= "" and e:split(",")[3] ~= "" and
                (a ~= tonumber(e:split(",")[2]) or o ~= tonumber(e:split(",")[3])))
         then
            i = math.floor(tonumber(e:split(",")[2] or "4")) or 4
            l = math.floor(tonumber(e:split(",")[3] or "4")) or 4
        end
        t = reaper.SetTempoTimeSigMarker(n, -1, r, -1, -1, c, i, l, false)
    end
    function e:autoSelection(e)
        local c = e or 1
        local i = reaper.GetExtState(n, a)
        local r = reaper.GetCursorPosition()
        i = tonumber(i) or 0
        local o = 0
        local t = 127
        local e = {}
        if (math.floor(i * 1e3) / 1e3 ~= math.floor(r * 1e3) / 1e3) then
            local l = self:_detectTargetNotes()
            o, t = self:_getMaxMinPitch(l)
            e = self:_getExistPitchNumber(l)
            local e = table.toString(e)
            reaper.SetExtState(n, h, e, false)
            reaper.SetExtState(n, p, tostring(o), false)
            reaper.SetExtState(n, f, tostring(t), false)
        else
            o = reaper.GetExtState(n, p)
            t = reaper.GetExtState(n, f)
            o = tonumber(o) or 0
            t = tonumber(t) or 127
            local t = reaper.GetExtState(n, h)
            e = table.fromString(t)
            if (#e < 1) then
                local t = self:_detectTargetNotes()
                e = self:_getExistPitchNumber(t)
            end
        end
        self.editingNotes = self:_getNotes_(false)
        self.m_originalNotes = deepcopy(self.editingNotes)
        local t = reaper.GetExtState(n, u)
        if (t == nil or t == "") then
            t = l[1]
        end
        local o = nil
        for e, n in ipairs(l) do
            if (n == t) then
                local e = e + c
                if (e > #l) then
                    e = 1
                end
                if (e < 1) then
                    e = #l
                end
                o = l[e]
                break
            end
        end
        local l = self.loopRangeInfo.startProjQN
        local s = self.loopRangeInfo.endProjQN
        local d = self.loopRangeInfo.lengthProjQN
        local i = tonumber(o:split(",")[1])
        local c = tonumber(o:split(",")[2])
        for n, t in ipairs(self.editingNotes) do
            t.selection = false
            local n = math.floor(t.startpos * 100 + .6) / 100
            for o, e in ipairs(e) do
                if
                    ((d <= 0 or (t.startpos >= l and t.startpos < s)) and e == t.pitch and
                        (math.floor((n) / i)) % 2 == c)
                 then
                    t.selection = true
                end
            end
        end
        reaper.SetExtState(n, u, o, false)
        reaper.SetExtState(n, a, tostring(r), false)
    end
    function e:toggleSelectionCrop()
        local e = self.mediaItemInfo.ptrID
        local e = b .. "_" .. e
        local t = reaper.GetExtState(n, e)
        if (t ~= "") then
            local t = table.fromString(t)
            self:_selectionReset(t)
            self:insertNotesFromC(t)
            reaper.SetExtState(n, e, "", false)
        else
            if (self:_getSelectionNoteCount() < 1) then
                reaper.SetExtState(n, e, "", false)
                return
            end
            local t = deepcopy(self.editingNotes)
            reaper.MIDIEditor_OnCommand(self.editorHwnd, k)
            self.editingNotes = self:_getNotes()
            self.m_originalNotes = deepcopy(self.editingNotes)
            local t = self:_detectTargetNotes()
            reaper.SetExtState(n, e, table.toString(t), false)
            self:deleteNotes(t)
        end
    end
    function e:_chengePitchCursol(t, e)
        local l = e or false
        local e = reaper.MIDIEditor_GetSetting_int(self.editorHwnd, "active_note_row")
        local t = math.floor(math.min(math.max(0, t), 127))
        if (e == t) then
            return
        end
        local n = 40049
        local o = 40050
        local n = n
        if (e > t) then
            n = o
        end
        local o = 0
        while (o < 200) do
            e = reaper.MIDIEditor_GetSetting_int(self.editorHwnd, "active_note_row")
            e = math.floor(math.min(math.max(0, e), 127))
            if (e == t) then
                break
            end
            if (l) then
                reaper.PreventUIRefresh(10)
                reaper.MIDIEditor_OnCommand(self.editorHwnd, n)
                reaper.PreventUIRefresh(-1)
            else
                reaper.MIDIEditor_OnCommand(self.editorHwnd, n)
            end
            o = o + 1
        end
    end
    function e:_ScrollToPitchRow(e)
        self:_chengePitchCursol(e, false)
    end
    function e:VerticalScrollToTopNotePosition()
        self.editingNotes = self:_getNotes_(false)
        self.m_originalNotes = deepcopy(self.editingNotes)
        local t = self.editingNotes
        local e = -1
        for n, t in ipairs(t) do
            e = math.max(e, t.pitch)
        end
        self:_ScrollToPitchRow(e)
    end
    function e:VerticalScrollToBottomNotePosition()
        self.editingNotes = self:_getNotes_(false)
        self.m_originalNotes = deepcopy(self.editingNotes)
        local t = self.editingNotes
        local e = 200
        for n, t in ipairs(t) do
            e = math.min(e, t.pitch)
        end
        self:_ScrollToPitchRow(e)
    end
    function e:VerticalScrollToCenterPosition()
        self.editingNotes = self:_getNotes_(false)
        self.m_originalNotes = deepcopy(self.editingNotes)
        local n = self.editingNotes
        local e = 200
        local t = 0
        for o, n in ipairs(n) do
            e = math.min(e, n.pitch)
            t = math.max(t, n.pitch)
        end
        local e = math.floor(e + (t - e) / 2)
        self:_ScrollToPitchRow(e)
    end
    function e:VerticalScrollToStep(o)
        if (self:isEditorMode_Notation() == true) then
            return
        end
        local e = reaper.GetExtState(n, m)
        local t = o or false
        if (e == "" or tonumber(e) == nil) then
            e = 1
        else
            e = tonumber(e)
        end
        local t = 1
        if (o == true) then
            if (e == 1) then
                self:VerticalScrollToBottomNotePosition()
                t = 2
            elseif (e == 2) then
                self:VerticalScrollToCenterPosition()
                t = 3
            elseif (e == 3) then
                self:VerticalScrollToTopNotePosition()
                t = 1
            end
        else
            if (e == 1) then
                self:VerticalScrollToBottomNotePosition()
                t = 2
            else
                self:VerticalScrollToTopNotePosition()
                t = 1
            end
        end
        reaper.SetExtState(n, m, tostring(t), false)
    end
    function e:zoomInHorizontal(e)
        local t = N
        for e = 1, e do
            reaper.MIDIEditor_OnCommand(self.editorHwnd, t)
        end
    end
    function e:zoomOutHorizontal(e)
        local t = M
        for e = 1, e do
            reaper.MIDIEditor_OnCommand(self.editorHwnd, t)
        end
    end
    function e:zoomInVertical(e)
        local t = P
        for e = 1, e do
            reaper.MIDIEditor_OnCommand(self.editorHwnd, t)
        end
    end
    function e:zoomOutVertical(e)
        local t = I
        for e = 1, e do
            reaper.MIDIEditor_OnCommand(self.editorHwnd, t)
        end
    end
    function e:_zoomReset(n, t)
        local e = 100
        if (n == true) then
            self:zoomInVertical(e)
        end
        if (t == true) then
            self:zoomInHorizontal(e)
        end
    end
    function e:changeZoom(t, e)
        self:_zoomReset((t ~= 0), (e ~= 0))
        if (t > 0) then
            self:zoomOutVertical(t)
        end
        if (e > 0) then
            self:zoomOutHorizontal(e)
        end
    end
    function e:stepChangeZoom(t, l, o)
        if (self:isEditorMode_Notation() == true) then
            return
        end
        local e = reaper.GetExtState(n, _ .. o)
        if (e == "" or tonumber(e) == nil) then
            e = 1
        else
            e = tonumber(e)
        end
        local e = e + l
        if (e > #t) then
            e = 1
        end
        if (e < 1) then
            e = #t
        end
        self:changeZoom(t[e][1], t[e][2])
        if (type(t[e][3]) == "function") then
            t[e][3](self)
        end
        reaper.SetExtState(n, _ .. o, tostring(e), false)
    end
    function e:horizontalZoomToContent()
        reaper.MIDIEditor_OnCommand(self.editorHwnd, T)
    end
    function e:changeNoteColoriseModeAsCircle()
        local t = 40739
        local o = 40738
        local n = 40740
        local a = reaper.GetToggleCommandStateEx(self.actionContextInfo.sectionID, t)
        local i = reaper.GetToggleCommandStateEx(self.actionContextInfo.sectionID, o)
        local l = reaper.GetToggleCommandStateEx(self.actionContextInfo.sectionID, n)
        local e = t
        if (math.floor(a) == 1) then
            e = o
        elseif (math.floor(i) == 1) then
            e = n
        elseif (math.floor(l) == 1) then
            e = t
        else
            e = t
        end
        reaper.MIDIEditor_OnCommand(self.editorHwnd, e)
    end
    function e:detectTopNote()
        local e = self:_detectTargetNotes()
        local t = self:_getExistStartPosTable(e)
        local n = {}
        local o = 1
        for l, t in ipairs(t) do
            local e, t = self:_getSameStartPosNotes(t, e, o)
            local t = -1
            for n, e in ipairs(e) do
                if (t < e.pitch) then
                    t = e.pitch
                end
            end
            if (#e > 1) then
                for o, e in ipairs(e) do
                    if (e.pitch < t) then
                        table.insert(n, e)
                    end
                end
            end
        end
        self:deleteNotes(n)
    end
    function e:detectBottomNote()
        local e = self:_detectTargetNotes()
        local t = self:_getExistStartPosTable(e)
        local n = {}
        local o = 1
        for l, t in ipairs(t) do
            local e, t = self:_getSameStartPosNotes(t, e, o)
            local t = 200
            for n, e in ipairs(e) do
                if (t > e.pitch) then
                    t = e.pitch
                end
            end
            if (#e > 1) then
                for o, e in ipairs(e) do
                    if (e.pitch > t) then
                        table.insert(n, e)
                    end
                end
            end
        end
        self:deleteNotes(n)
    end
    function e:deleteTopNote()
        local e = self:_detectTargetNotes()
        local t = self:_getExistStartPosTable(e)
        local n = {}
        local o = 1
        for l, t in ipairs(t) do
            local e, t = self:_getSameStartPosNotes(t, e, o)
            local t = -1
            for n, e in ipairs(e) do
                if (t < e.pitch) then
                    t = e.pitch
                end
            end
            if (#e > 1) then
                for o, e in ipairs(e) do
                    if (e.pitch == t) then
                        table.insert(n, e)
                    end
                end
            end
        end
        self:deleteNotes(n)
    end
    function e:deleteBottomNote()
        local e = self:_detectTargetNotes()
        local t = self:_getExistStartPosTable(e)
        local n = {}
        local o = 1
        for l, t in ipairs(t) do
            local e, t = self:_getSameStartPosNotes(t, e, o)
            local t = 200
            local o = 0
            for n, e in ipairs(e) do
                if (t > e.pitch) then
                    t = e.pitch
                end
            end
            if (#e > 1) then
                for o, e in ipairs(e) do
                    if (e.pitch == t) then
                        table.insert(n, e)
                    end
                end
            end
        end
        self:deleteNotes(n)
    end
    function e:selectTopNote()
        local e = self:_detectTargetNotes()
        local t = self:_getExistStartPosTable(e)
        local n = 1
        for o, t in ipairs(t) do
            local e, t = self:_getSameStartPosNotes(t, e, n)
            local t = -1
            for n, e in ipairs(e) do
                if (t < e.pitch) then
                    t = e.pitch
                end
            end
            if (#e >= 1) then
                for n, e in ipairs(e) do
                    if (e.pitch == t) then
                        e.selection = true
                    else
                        e.selection = false
                    end
                end
            end
        end
    end
    function e:selectBottomNote()
        local e = self:_detectTargetNotes()
        local n = self:_getExistStartPosTable(e)
        local t = 1
        for o, n in ipairs(n) do
            local e, t = self:_getSameStartPosNotes(n, e, t)
            local t = 200
            for n, e in ipairs(e) do
                if (t > e.pitch) then
                    t = e.pitch
                end
            end
            if (#e >= 1) then
                for n, e in ipairs(e) do
                    if (e.pitch == t) then
                        e.selection = true
                    else
                        e.selection = false
                    end
                end
            end
        end
    end
    function e:selectMiddleNotes()
        local e = self:_detectTargetNotes()
        local n = self:_getExistStartPosTable(e)
        local t = 1
        for o, n in ipairs(n) do
            local e, t = self:_getSameStartPosNotes(n, e, t)
            local n = 200
            local t = 0
            for o, e in ipairs(e) do
                n = math.min(n, e.pitch)
                t = math.max(t, e.pitch)
            end
            if (#e >= 1) then
                for o, e in ipairs(e) do
                    if (e.pitch > n and e.pitch < t) then
                        e.selection = true
                    else
                        e.selection = false
                    end
                end
            end
        end
    end
    function e:selectSimilerChord(e)
        if (self:_getSelectionNoteCount() < 1) then
            return
        end
        local t = self:_getSelectionNotes(self.editingNotes)
        local r = self:_getExistPitchNumber(t)
        self.editingNotes = self:_getNotes_(false)
        self.m_originalNotes = deepcopy(self.editingNotes)
        self:_selectionReset(self.editingNotes)
        local e = e or 0
        local a = self:_getChordTones_Near(e)
        local function i(t, n)
            local e = false
            for o, t in ipairs(t) do
                if (t.pitch == n) then
                    e = true
                    break
                end
            end
            return e
        end
        local function l(e, o)
            local n = false
            local t = 0
            for l, n in ipairs(e) do
                if (i(o, n) == true and #e == #o) then
                    t = t + 1
                end
            end
            if (t >= #e) then
                n = true
            end
            return n
        end
        for t, e in ipairs(a) do
            if (l(r, e) == true) then
                for t, e in ipairs(e) do
                    e.selection = true
                end
            end
        end
    end
    function e:selectEvenOddChordTone(t)
        local e = self:_detectTargetNotes()
        local n = self:_getExistStartPosTable(e)
        local l = 1
        local o = t or false
        local function t(e)
            return ((e % 2) == 0)
        end
        for n, t in ipairs(n) do
            local e, t = self:_getSameStartPosNotes(t, e, l)
            if (#e >= 1) then
                local function t(e)
                    return ((e % 2) == 0)
                end
                table.sort(
                    e,
                    function(e, t)
                        return (e.pitch < t.pitch)
                    end
                )
                for n, e in ipairs(e) do
                    if (t(n) == o) then
                        e.selection = true
                    else
                        e.selection = false
                    end
                end
            end
        end
    end
    function e:generateSelectionArp()
        local l = {}
        local o = self:_getMidiGrid()
        local function i(e)
            local t = 0
            for n, e in ipairs(e) do
                if
                    (t < e.length and
                        (self:isSelectionInEditingNotes() == true and e.selection == true or
                            self:isSelectionInEditingNotes() == false))
                 then
                    t = e.length
                end
            end
            return t
        end
        local function e(e)
            local t = {}
            for n, e in ipairs(e) do
                if
                    (self:isSelectionInEditingNotes() == true and e.selection == true or
                        self:isSelectionInEditingNotes() == false)
                 then
                    table.insert(t, e)
                end
            end
            return t
        end
        local function r()
            local e = self:_detectTargetNotes()
            local n = self:_getExistStartPosTable(e)
            local t = 1
            for a, n in ipairs(n) do
                local e, t = self:_getSameStartPosNotes(n, e, t)
                if (#e >= 1) then
                    local t = i(e)
                    local i = math.floor(t / o)
                    local a = #e
                    table.sort(
                        e,
                        function(e, t)
                            return (e.pitch < t.pitch)
                        end
                    )
                    local n = e[1].startpos
                    local o = o * .99999
                    local t = 1
                    local function r()
                        t = t + 1
                        if (t > a) then
                            t = 1
                        end
                    end
                    for l = 1, i, 1 do
                        local e = deepcopy(e[t])
                        e.length = o
                        e.startpos = n
                        e.endpos = e.startpos + e.length
                        self:insertNoteFromC(e)
                        n = n + o
                        r()
                    end
                    for t, e in ipairs(e) do
                        table.insert(l, e)
                    end
                end
            end
        end
        r()
        self:deleteNotes(l)
    end
    function e:generateRandomArp()
        local a = {}
        local l = self:_getMidiGrid()
        local function o(e)
            local t = 0
            for n, e in ipairs(e) do
                if
                    (t < e.length and
                        (self:isSelectionInEditingNotes() == true and e.selection == true or
                            self:isSelectionInEditingNotes() == false))
                 then
                    t = e.length
                end
            end
            return t
        end
        local function e(t)
            local e = {}
            for n, t in ipairs(t) do
                if
                    (self:isSelectionInEditingNotes() == true and t.selection == true or
                        self:isSelectionInEditingNotes() == false)
                 then
                    table.insert(e, t)
                end
            end
            return e
        end
        local function c()
            local e = self:_detectTargetNotes()
            local n = self:_getExistStartPosTable(e)
            local t = 1
            for i, n in ipairs(n) do
                local e, t = self:_getSameStartPosNotes(n, e, t)
                if (#e >= 1) then
                    local t = o(e)
                    local r = math.floor(t / l)
                    local n = #e
                    table.sort(
                        e,
                        function(t, e)
                            return (t.pitch < e.pitch)
                        end
                    )
                    local o = e[1].startpos
                    local l = l * .99999
                    local t = 1
                    local function i()
                        t = t + 1
                        if (t > n) then
                            t = 1
                        end
                    end
                    local i = -1
                    for t = 1, r, 1 do
                        local t = math.floor(math.random(1, n))
                        t = math.max(math.min(t, n), 1)
                        while (i == t and #e ~= 1) do
                            t = math.floor(math.random() * n)
                            t = math.max(math.min(t, n), 1)
                        end
                        i = t
                        local e = deepcopy(e[t])
                        e.length = l
                        e.startpos = o
                        e.endpos = e.startpos + e.length
                        self:insertNoteFromC(e)
                        o = o + l
                    end
                    for t, e in ipairs(e) do
                        table.insert(a, e)
                    end
                end
            end
        end
        c()
        self:deleteNotes(a)
    end
    function e:generateExprodeArp()
        local c = {}
        local n = self:_getMidiGrid()
        local function o(e)
            local t = 0
            for n, e in ipairs(e) do
                if
                    (t < e.length and
                        (self:isSelectionInEditingNotes() == true and e.selection == true or
                            self:isSelectionInEditingNotes() == false))
                 then
                    t = e.length
                end
            end
            return t
        end
        local function e(e)
            local t = {}
            for n, e in ipairs(e) do
                if
                    (self:isSelectionInEditingNotes() == true and e.selection == true or
                        self:isSelectionInEditingNotes() == false)
                 then
                    table.insert(t, e)
                end
            end
            return t
        end
        local function s()
            local e = self:_detectTargetNotes()
            local l = self:_getExistStartPosTable(e)
            local t = 1
            local f = -100
            local h = -100
            local d = -100
            for i, l in ipairs(l) do
                local t, e = self:_getSameStartPosNotes(l, e, t)
                if (#t >= 1) then
                    local e = o(t)
                    local l = math.floor(e / n)
                    local o = #t
                    table.sort(
                        t,
                        function(e, t)
                            return (e.pitch < t.pitch)
                        end
                    )
                    local i = t[1].startpos
                    local a = n * .99999
                    local e = 1
                    local function n()
                        e = e + 1
                        if (e > o) then
                            e = 1
                        end
                    end
                    for e = 1, l, 1 do
                        local r = math.floor(math.random(-2, 2))
                        local l = 12 * r
                        local n = math.floor(math.random(1, o))
                        n = math.max(math.min(n, o), 1)
                        local e = deepcopy(t[n])
                        e.length = a
                        e.startpos = i
                        e.endpos = e.startpos + e.length
                        e.pitch = e.pitch + (math.floor(l))
                        e.pitch = math.min(math.max(e.pitch, 1), 127)
                        local c = e.pitch
                        while (math.floor(d) == math.floor(c) and #t ~= 1) do
                            r = math.floor(math.random(-2, 2))
                            l = 12 * r
                            n = math.floor(math.random() * o)
                            n = math.max(math.min(n, o), 1)
                            e = deepcopy(t[n])
                            e.length = a
                            e.startpos = i
                            e.endpos = e.startpos + e.length
                            e.pitch = e.pitch + (math.floor(l))
                            e.pitch = math.min(math.max(e.pitch, 1), 127)
                            c = e.pitch
                        end
                        f = l
                        h = n
                        d = e.pitch
                        self:insertNoteFromC(e)
                        i = i + a
                    end
                    for t, e in ipairs(t) do
                        table.insert(c, e)
                    end
                end
            end
        end
        s()
        self:deleteNotes(c)
    end
    function e:selectTopNote_Near(o)
        local e = self:_detectTargetNotes()
        table.sort(
            e,
            function(t, e)
                return (t.startpos < e.startpos)
            end
        )
        local n = 1
        local o = o or 1 / 4
        for l, t in ipairs(e) do
            if (t._checkedAsChordNote_ ~= true) then
                local e, t = self:_detectChordNotesNear(t.startpos, e, n, o)
                local t = -1
                for n, e in ipairs(e) do
                    t = math.max(t, e.pitch)
                end
                for n, e in ipairs(e) do
                    if (e._isChordChecked_ ~= true) then
                        if (e.pitch == t) then
                            e.selection = true
                        else
                            e.selection = false
                        end
                    else
                        e._isChordChecked_ = true
                    end
                end
            end
        end
    end
    function e:detectTopNote_Near(n)
        local e = self:_detectTargetNotes()
        table.sort(
            e,
            function(t, e)
                return (t.startpos < e.startpos)
            end
        )
        local o = 1
        local l = n or 1 / 4
        local t = {}
        for i, n in ipairs(e) do
            if (n._checkedAsChordNote_ ~= true) then
                local n, e = self:_detectChordNotesNear(n.startpos, e, o, l)
                local e = -1
                for n, t in ipairs(n) do
                    e = math.max(e, t.pitch)
                end
                for o, n in ipairs(n) do
                    if (n.pitch < e) then
                        table.insert(t, n)
                    end
                end
            end
        end
        self:deleteNotes(t)
    end
    function e:deleteTopNote_Near(t)
        local e = self:_detectTargetNotes()
        table.sort(
            e,
            function(t, e)
                return (t.startpos < e.startpos)
            end
        )
        local l = 1
        local o = t or 1 / 4
        local n = {}
        for i, t in ipairs(e) do
            if (t._checkedAsChordNote_ ~= true) then
                local e, t = self:_detectChordNotesNear(t.startpos, e, l, o)
                local t = -1
                for n, e in ipairs(e) do
                    t = math.max(t, e.pitch)
                end
                for o, e in ipairs(e) do
                    if (e._isChordChecked_ ~= true) then
                        if (e.pitch == t) then
                            table.insert(n, e)
                        end
                    else
                        e._isChordChecked_ = true
                    end
                end
            end
        end
        self:deleteNotes(n)
    end
    function e:selectBottomNote_Near(o)
        local e = self:_detectTargetNotes()
        table.sort(
            e,
            function(e, t)
                return (e.startpos < t.startpos)
            end
        )
        local n = 1
        local o = o or 1 / 4
        for l, t in ipairs(e) do
            if (t._checkedAsChordNote_ ~= true) then
                local e, t = self:_detectChordNotesNear(t.startpos, e, n, o)
                local t = 200
                for n, e in ipairs(e) do
                    t = math.min(t, e.pitch)
                end
                for n, e in ipairs(e) do
                    if (e._isChordChecked_ ~= true) then
                        if (e.pitch == t) then
                            e.selection = true
                        else
                            e.selection = false
                        end
                    else
                        e._isChordChecked_ = true
                    end
                end
            end
        end
    end
    function e:detectBottomNote_Near(n)
        local e = self:_detectTargetNotes()
        table.sort(
            e,
            function(t, e)
                return (t.startpos < e.startpos)
            end
        )
        local o = 1
        local l = n or 1 / 4
        local n = {}
        for i, t in ipairs(e) do
            if (t._checkedAsChordNote_ ~= true) then
                local e, t = self:_detectChordNotesNear(t.startpos, e, o, l)
                local t = 200
                for n, e in ipairs(e) do
                    t = math.min(t, e.pitch)
                end
                for o, e in ipairs(e) do
                    if (e._isChordChecked_ ~= true) then
                        if (e.pitch > t) then
                            table.insert(n, e)
                        end
                    else
                        e._isChordChecked_ = true
                    end
                end
            end
        end
        self:deleteNotes(n)
    end
    function e:deleteBottomNote_Near(t)
        local e = self:_detectTargetNotes()
        table.sort(
            e,
            function(t, e)
                return (t.startpos < e.startpos)
            end
        )
        local o = 1
        local l = t or 1 / 4
        local n = {}
        for i, t in ipairs(e) do
            if (t._checkedAsChordNote_ ~= true) then
                local e, t = self:_detectChordNotesNear(t.startpos, e, o, l)
                local t = 200
                for n, e in ipairs(e) do
                    t = math.min(t, e.pitch)
                end
                for o, e in ipairs(e) do
                    if (e._isChordChecked_ ~= true) then
                        if (e.pitch == t) then
                            table.insert(n, e)
                        end
                    else
                        e._isChordChecked_ = true
                    end
                end
            end
        end
        self:deleteNotes(n)
    end
    function e:selectMiddleNotes_Near(t)
        local e = self:_detectTargetNotes()
        table.sort(
            e,
            function(e, t)
                return (e.startpos < t.startpos)
            end
        )
        local o = 1
        local n = t or 1 / 4
        for l, t in ipairs(e) do
            if (t._checkedAsChordNote_ ~= true) then
                local o, e = self:_detectChordNotesNear(t.startpos, e, o, n)
                local n = 200
                local t = 0
                for o, e in ipairs(o) do
                    n = math.min(n, e.pitch)
                    t = math.max(t, e.pitch)
                end
                for o, e in ipairs(o) do
                    if (e.pitch > n and e.pitch < t) then
                        e.selection = true
                    else
                        e.selection = false
                    end
                end
            end
        end
    end
    function e:selectEvenOddChordTone_Near(l, n)
        local e = self:_detectTargetNotes()
        table.sort(
            e,
            function(t, e)
                return (t.startpos < e.startpos)
            end
        )
        local o = 1
        local n = n or false
        local l = l or 1 / 4
        local function i(e)
            return ((e % 2) == 0)
        end
        for a, t in ipairs(e) do
            if (t._checkedAsChordNote_ ~= true) then
                local e, t = self:_detectChordNotesNear(t.startpos, e, o, l)
                if (#e >= 1) then
                    table.sort(
                        e,
                        function(e, t)
                            return (e.pitch < t.pitch)
                        end
                    )
                    for t, e in ipairs(e) do
                        if (i(t) == n) then
                            e.selection = true
                        else
                            e.selection = false
                        end
                    end
                end
            end
        end
    end
    function e:_patternSelect(n, t)
        local e = 1
        table.sort(
            n,
            function(t, e)
                return (t.pitch < e.pitch)
            end
        )
        for o, n in ipairs(n) do
            n.selection = t[e] or false
            e = e + 1
            if (e > #t) then
                e = 1
            end
        end
    end
    function e:_getChordTones_Near(t)
        local e = self:_detectTargetNotes()
        table.sort(
            e,
            function(t, e)
                return (t.startpos < e.startpos)
            end
        )
        local o = 1
        local l = t or 1 / 4
        local t = {}
        for i, n in ipairs(e) do
            if (n._checkedAsChordNote_ ~= true) then
                local n, e = self:_detectChordNotesNear(n.startpos, e, o, l)
                local e = {}
                for n, t in ipairs(n) do
                    table.insert(e, t)
                end
                table.insert(t, e)
            end
        end
        return t
    end
    function e:incrementNoteChannel()
        local e = self:_detectTargetNotes()
        local n = 40482
        local t = 0
        for n, e in ipairs(e) do
            e.chan = e.chan + 1
            if (e.chan > 15) then
                e.chan = 0
            end
            if (e.chan < 0) then
                e.chan = 15
            end
            t = e.chan
        end
        local e = n + t
        reaper.MIDIEditor_OnCommand(self.editorHwnd, e)
    end
    function e:decrementNoteChannel()
        local e = self:_detectTargetNotes()
        local n = 40482
        local t = 0
        for n, e in ipairs(e) do
            e.chan = e.chan - 1
            if (e.chan > 15) then
                e.chan = 0
            end
            if (e.chan < 0) then
                e.chan = 15
            end
            t = e.chan
        end
        local e = n + t
        reaper.MIDIEditor_OnCommand(self.editorHwnd, e)
    end
    function e:assignChordToneToChannel_B()
        local e = self:_detectTargetNotes()
        local n = self:_getExistStartPosTable(e)
        local t = 1
        for o, n in ipairs(n) do
            local t, e = self:_getSameStartPosNotes(n, e, t)
            table.sort(
                t,
                function(e, t)
                    return (e.pitch < t.pitch)
                end
            )
            local e = 0
            for n, t in ipairs(t) do
                if (n == 1) then
                    e = t.chan
                else
                    t.chan = e
                end
                e = e + 1
                if (e > 15) then
                    e = 0
                end
                if (e < 0) then
                    e = 15
                end
            end
        end
    end
    function e:assignChordToneToChannel_B_Near(o)
        local e = self:_detectTargetNotes()
        table.sort(
            e,
            function(t, e)
                return (t.startpos < e.startpos)
            end
        )
        local n = 1
        local o = o or 1 / 4
        for l, t in ipairs(e) do
            if (t._checkedAsChordNote_ ~= true) then
                local t, e = self:_detectChordNotesNear(t.startpos, e, n, o)
                table.sort(
                    t,
                    function(e, t)
                        return (e.pitch < t.pitch)
                    end
                )
                local e = 0
                for n, t in ipairs(t) do
                    if (n == 1) then
                        e = t.chan
                    else
                        t.chan = e
                    end
                    e = e + 1
                    if (e > 15) then
                        e = 0
                    end
                    if (e < 0) then
                        e = 15
                    end
                end
            end
        end
    end
    function e:flush(t, e)
        if (self:_checkProcessLimitNum() == 0) then
            return
        end
        if (t == nil) then
            self:_deleteMinimunLengthNote()
        end
        if (e == nil) then
            self:_safeOverLap()
        end
        self:_deleteAllOriginalNote()
        self:_editingNoteToMediaItem()
        reaper.MIDI_Sort(self.take)
    end
    function e:resetEditingNotes()
        self.editingNotes = {}
        self.editingNotes = deepcopy(self.m_originalNotes)
    end
    function e:resetAndReInit()
        self:_init()
    end
    function e:insertNoteFromC(e)
        e.idx = self.m_existMaxNoteIdx + 1
        self.m_existMaxNoteIdx = self.m_existMaxNoteIdx + 1
        table.insert(self.editingNotes, e)
        return e
    end
    function e:insertNotesFromC(e)
        for t, e in ipairs(e) do
            self:insertNoteFromC(e)
        end
        return e
    end
    function e:insertMidiNote(c, i, t, e, n, l, o)
        local t = t
        local e = e
        local a = i
        local r = n or false
        local i = o or false
        local l = l or 1
        local o = c
        local n = self.m_existMaxNoteIdx + 1
        self.m_existMaxNoteIdx = self.m_existMaxNoteIdx + 1
        local e = {
            selection = r,
            mute = i,
            startpos = t,
            endpos = e,
            chan = l,
            pitch = o,
            vel = a,
            take = self.take,
            idx = n,
            length = e - t
        }
        table.insert(self.editingNotes, e)
    end
    function e:deleteNote_B(e)
        for n, t in ipairs(self.editingNotes) do
            if (t.startpos == e.startpos and t.chan == e.chan and t.pitch == e.pitch) then
                table.remove(self.editingNotes, n)
                break
            end
        end
    end
    function e:deleteNotes_B(e)
        if (e == self.editingNotes) then
            self.editingNotes = {}
            return
        end
        for t, e in ipairs(e) do
            self:deleteNote_B(e)
        end
    end
    function e:deleteNote(e)
        for t, n in ipairs(self.editingNotes) do
            if (n.idx == e.idx) then
                table.remove(self.editingNotes, t)
                break
            end
        end
    end
    function e:deleteNotes(e)
        if (e == self.editingNotes) then
            self.editingNotes = {}
            return
        end
        for t, e in ipairs(e) do
            self:deleteNote(e)
        end
    end
    function e:genHarmonyTone()
        local e = reaper.GetExtState(n, c)
        local t = reaper.GetExtState(n, d)
        if (e == "") then
            e = "C"
        end
        if (t == "") then
            t = "5"
        end
        local e, t =
            reaper.GetUserInputs(
            "Harmony",
            7,
            'Key(Major) "C C# D D# " ,Degree Num ( -8 ~ 8)',
            e .. "," .. t .. "," .. "--,--,--,--,--"
        )
        if (e == false) then
            return
        end
        local l = createPitchInfo()
        local o = t:split(",")[1]
        local e = tonumber(t:split(",")[2]) or 5
        local a = l:getPitchNumber(o)
        if (e == 0 or e == 1) then
            return
        end
        if (e > 8) then
            e = 8
        end
        if (e < -8) then
            e = -8
        end
        local i = self:_detectTargetNotes()
        local o = {}
        for n, t in ipairs(i) do
            local n = l:getHarmonyTone(a, t.pitch, e)
            local e = deepcopy(t)
            e.pitch = n
            table.insert(o, e)
        end
        self:insertNotesFromC(o)
        reaper.SetExtState(n, c, t:split(",")[1], false)
        reaper.SetExtState(n, d, e, false)
    end
    function e:getFirstNote()
        local t = nil
        local e = self:_detectTargetNotes()
        if (e ~= nil) then
            t = e[1]
        end
        return t
    end
    function e:getFirstSelectedNote()
        local e = nil
        local t = self:_detectTargetNotes()
        if (t ~= nil and self:isSelectionInEditingNotes(true) == true) then
            e = t[1]
        end
        return e
    end
    function e:_duplicateMorseCode(e, t, n)
        if (self:_checkProcessLimitNum() == false) then
            return
        end
        local l = n or self.mediaItemInfo.endProjQN
        local i = e
        local n = t or 1
        if (n < .05) then
            n = .5
        end
        local c = {}
        local r = {}
        local e = self:_detectTargetNotes()
        for e, a in pairs(e) do
            local e = a
            local o = e.length
            local t = e.startpos
            if (e.length > 1e-4) then
                for a, i in ipairs(i) do
                    if (i ~= -1) then
                        local o = i * o
                        local e = deepcopy(e)
                        e.startpos = t
                        local n = o * n
                        if (n < .1) then
                            n = .1
                        end
                        e.endpos = e.startpos + n
                        e.length = e.endpos - e.startpos
                        e.selection = false
                        if (e.endpos > l) then
                            break
                        end
                        table.insert(r, e)
                        t = e.startpos + o
                    else
                        local e = t + o
                        if (e > l) then
                            break
                        end
                        t = e
                    end
                end
                table.insert(c, a)
            end
        end
        self:deleteNotes(c)
        self:insertNotesFromC(r)
    end
    function e:_genMorseCode(e, o)
        local e = e or "A"
        local n = {}
        local o = o or 1
        e = string.upper(e)
        for l, e in stringIter(e) do
            if (t[e] ~= nil) then
                local e = t[e]
                for t, e in ipairs(e) do
                    table.insert(n, e)
                end
                if (o > 1) then
                    for e = 1, o do
                        table.insert(n, -1)
                    end
                end
            end
        end
        return n
    end
    function e:DuplicateAsMorseCode()
        if (#self:_getSelectionNotes() < 1) then
            return
        end
        local e, t =
            reaper.GetUserInputs(
            "Morse Code Duplicate",
            7,
            "Text,Margin (0.1 ~ 1.0),BreakNum(1 ~ )",
            "A,0.5,1,--,--,--,--"
        )
        if (e == false) then
            return
        end
        local e = {}
        local n = t:split(",")[1] or "A"
        n = string.upper(n)
        local e = tonumber(t:split(",")[2]) or 1
        local t = tonumber(t:split(",")[3])
        if (e < .05) then
            e = .5
        end
        local t = self:_genMorseCode(n, t)
        self:_duplicateMorseCode(t, e)
    end
    function e:DuplicateRandomMorse()
        if (#self:_getSelectionNotes() < 1) then
            return
        end
        local t = (math.random() * .4) + .5
        local n = math.floor(math.random() * 2)
        local o = 4 * math.random() + 1
        local e = ""
        for t = 1, o do
            e = e .. string.char(math.floor(25 * math.random()) + 64)
        end
        local e = self:_genMorseCode(e, n)
        self:_duplicateMorseCode(e, t)
    end
    function e:_splitAsMorse__(e, t)
        if (self:_checkProcessLimitNum() == false) then
            return
        end
        local d = e
        local n = t or .5
        if (n < .05) then
            n = .5
        end
        local e, t, t = self:_getMidiGrid()
        local l = {}
        local c = {}
        local i = e
        local e = self:_detectTargetNotes()
        for e, a in ipairs(e) do
            local e = a
            local r = e.endpos
            local t = e.startpos
            local o = true
            while (o == true) do
                for a, l in ipairs(d) do
                    if (l ~= -1) then
                        local l = l * i
                        local e = deepcopy(e)
                        e.startpos = t
                        local n = l * n
                        if (n < .1) then
                            n = .1
                        end
                        e.endpos = e.startpos + n
                        e.length = e.endpos - e.startpos
                        e.selection = false
                        if (e.endpos > r) then
                            o = false
                        else
                            table.insert(c, e)
                            t = e.startpos + l
                        end
                    else
                        local e = t + i
                        if (e > r) then
                            o = false
                        else
                            t = e
                        end
                    end
                end
            end
            table.insert(l, a)
        end
        self:deleteNotes(l)
        self:insertNotesFromC(c)
    end
    function e:splitAsMorseCode()
        if (#self:_getSelectionNotes() < 1) then
            return
        end
        local e, t =
            reaper.GetUserInputs("Morse Code Split", 7, "Text,Margin (0.1 ~ 1.0),BreakNum(1 ~ )", "A,0.5,1,--,--,--,--")
        if (e == false) then
            return
        end
        local n = t:split(",")[1] or "A"
        n = string.upper(n)
        local e = tonumber(t:split(",")[2]) or 1
        local t = tonumber(t:split(",")[3])
        if (e < .05) then
            e = .5
        end
        local t = self:_genMorseCode(n, t)
        local n = self:_getExistStartPosTable()
        self:_splitAsMorse__(t, e)
    end
    function e:splitAsRandomMorseCodeU()
        if (#self:_getSelectionNotes() < 1) then
            return
        end
        math.randomseed(reaper.time_precise() * os.time() / 1e3)
        local o = (math.random() * .4) + .5
        local l = math.floor(math.random() * 2.5)
        local e = 4
        local n = ""
        for e = 1, e do
            local e = string.char(math.floor(25 * math.random()) + 64)
            while (t[e] == nil) do
                e = string.char(math.floor(25 * math.random()) + 64)
            end
            n = n .. e
        end
        local e = self:_genMorseCode(n, l)
        self:_splitAsMorse__(e, o)
    end
    function e:showSelecteNoteInfo(e)
        local o = 0
        local n = 0
        local t = 200
        local i = ""
        local l = ""
        local a = e or false
        local e = self:_detectTargetNotes()
        o = #e
        for o, e in ipairs(e) do
            n = math.max(n, e.pitch)
            t = math.min(t, e.pitch)
        end
        local e = createPitchInfo()
        i = e:getPitchName(n, true)
        l = e:getPitchName(t, true)
        local e = ""
        e = " ======== NOTE INFO ======== \n"
        e = e .. " Note Count : " .. tostring(o) .. "\n"
        e = e .. " TopNote Pitch Number  : " .. tostring(n) .. "\n"
        e = e .. " BassNote Pitch Number : " .. tostring(t) .. "\n"
        e = e .. " TopNote Pitch Name : " .. i .. "\n"
        e = e .. " BassNote Pitch Name : " .. l .. "\n"
        e = e .. " =========================== \n"
        if (a == true) then
            reaper.ShowMessageBox(e, "selection Note Info", 0)
        else
            reaper.ClearConsole()
            reaper.ShowConsoleMsg(e)
        end
        if (reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64") then
            local n = reaper.GetProjectPath("")
            local o = package.config:sub(1, 1)
            local t = "selectionNoteInfo.txt"
            local t = n .. o .. t
            local t = io.open(t, "w")
            t:write(e)
            t:close()
        end
    end
    function e:_init(e)
        self.editorHwnd = reaper.MIDIEditor_GetActive()
        self.take = e or reaper.MIDIEditor_GetTake(self.editorHwnd)
        if (self.take == nil) then
            return
        end
     
        self.mediaItem = reaper.GetMediaItemTake_Item(self.take)
        self.mediaTrack = reaper.GetMediaItemTrack(self.mediaItem)
        self.mediaItemInfo = self:_storeMediaItemInfo()
        self.editingNotes = self:_getNotes()
        self.m_originalNotes = deepcopy(self.editingNotes)
       
    end
    function e:_storeTimeSelectionInfo()
        local e, o = reaper.GetSet_LoopTimeRange2(0, false, G, 0, 0, false)
        local a = reaper.MIDI_GetPPQPosFromProjTime(self.take, e)
        local i = reaper.MIDI_GetPPQPosFromProjTime(self.take, o)
        local r = reaper.MIDI_GetProjQNFromPPQPos(self.take, a)
        local c = reaper.MIDI_GetProjQNFromPPQPos(self.take, i)
        local n = o - e
        local t = reaper.MIDI_GetPPQPosFromProjTime(self.take, n)
        local l = reaper.MIDI_GetProjQNFromPPQPos(self.take, t)
        if (n <= 0) then
            t = 0
            l = 0
        end
        local e = {
            startTime = e,
            endTime = o,
            lengthTime = n,
            startPpq = a,
            endPpq = i,
            lengthPpq = t,
            startProjQN = r,
            endProjQN = c,
            lengthProjQN = l
        }
        return e
    end
    function e:_getMidiGrid()
        local t, n, e = reaper.MIDI_GetGrid(self.take)
        return t, n, e
    end
    function e:_storeActionContextInfo()
        local a, n, t, o, i, l, e = reaper.get_action_context()
        self.actionContextInfo = {
            is_new_value = a,
            filename = n,
            sectionID = t,
            cmdID = o,
            mode = i,
            resolution = l,
            val = e
        }
        return self.actionContextInfo
    end
    function e:_storeMediaItemInfo()
        local e = reaper.GetMediaItemInfo_Value(self.mediaItem, "D_POSITION")
        local t = reaper.GetMediaItemInfo_Value(self.mediaItem, "D_LENGTH")
        local l = e + t
        local n = reaper.MIDI_GetPPQPosFromProjTime(self.take, e)
        local o = reaper.MIDI_GetPPQPosFromProjTime(self.take, t)
        local i = reaper.MIDI_GetPPQPosFromProjTime(self.take, l)
        local d = reaper.MIDI_GetProjQNFromPPQPos(self.take, n)
        local c = reaper.MIDI_GetProjQNFromPPQPos(self.take, o)
        local r = reaper.MIDI_GetProjQNFromPPQPos(self.take, i)
        local a = reaper.GetMediaItemInfo_Value(self.mediaItem, "IP_ITEMNUMBER")
        local e = {
            startTime = e,
            lengthTime = t,
            endTime = l,
            startPpq = n,
            lengthPpq = o,
            endPpq = i,
            startProjQN = d,
            lengthProjQN = c,
            endProjQN = r,
            mediaItem = midiMediaItem,
            take = takeMidi,
            IP_NUM_RO = a,
            ptrID = tostring(self.mediaItem)
        }
        return e
    end
    function e:_getNotes()
        local e = {}
       
            e = self:_getNotes_(true)
            if (#e < 1) then
                e = self:_getNotes_(false)
            end
       
        return e
    end
    function e:_getNotes_(r)
      
        local i = {}
        local h = self.take
        if (self.take == nil) then
            return i
        end
        local u, l, f, n, t, s, d, c = reaper.MIDI_GetNote(self.take, 0)
        local e = 0
        while u do
            n = reaper.MIDI_GetProjQNFromPPQPos(h, n)
            t = reaper.MIDI_GetProjQNFromPPQPos(h, t)
            local o = {
                selection = l,
                mute = f,
                startpos = n,
                endpos = t,
                chan = s,
                pitch = d,
                vel = c,
                take = self.take,
                idx = e,
                length = t - n
            }
            if (r == true and l == r or r == false) then
                table.insert(i, o)
            end
            e = e + 1
            u, l, f, n, t, s, d, c = reaper.MIDI_GetNote(self.take, e)
        end
        self.m_existMaxNoteIdx = e
        if (self.editorHwnd ~= nil and a == 0) then
            reaper.MIDIEditor_OnCommand(self.editorHwnd, o)
        end
        return i
    end
    function e:_deleteAllOriginalNote(e)
        local e = e or self.m_originalNotes
        while (#e > 0) do
            local t = #e
            reaper.MIDI_DeleteNote(e[t].take, e[t].idx)
            table.remove(e, #e)
        end
    end
    function e:_insertNoteToMediaItem(e)
        local t = self.take
        if t == nil then
            return
        end
        local l = e.selection or false
        local i = e.mute
        local r = reaper.MIDI_GetPPQPosFromProjQN(t, e.startpos)
        local a = reaper.MIDI_GetPPQPosFromProjQN(t, e.endpos)
        local n = e.chan
        local o = e.pitch
        local e = e.vel
        reaper.MIDI_InsertNote(t, l, i, r, a, n, o, e, false)
    end
    function e:_editingNoteToMediaItem()
        local e = reaper.GetToggleCommandStateEx(self.actionContextInfo.sectionID, o)
        if (self.editorHwnd ~= nil and (e == 0 or e == 0)) then
            reaper.MIDIEditor_OnCommand(self.editorHwnd, o)
        end
        table.sort(
            self.editingNotes,
            function(e, t)
                return (e.idx < t.idx)
            end
        )
        for t, e in ipairs(self.editingNotes) do
            self:_insertNoteToMediaItem(e)
        end
        if (self.editorHwnd ~= nil and (e == 0)) then
            reaper.MIDIEditor_OnCommand(self.editorHwnd, o)
        end
    end
    function e:_safeOverLap(e)
        local t = e or self.editingNotes
        local function n(t, n)
            local e = {}
            for o, t in ipairs(t) do
                if (n.pitch == t.pitch) then
                    table.insert(e, t)
                end
            end
            table.sort(
                e,
                function(e, t)
                    return (e.startpos < t.startpos)
                end
            )
            return e
        end
        table.sort(
            t,
            function(t, e)
                return (t.startpos < e.startpos)
            end
        )
        local o = deepcopy(t)
        local l = {}
        local i = {}
        while (#o > 0) do
            local n = n(o, o[1])
            while (#n >= 2) do
                local e = n[1]
                local t = n[2]
                if (t ~= nil and e.startpos < t.startpos and e.endpos > t.startpos) then
                    table.insert(i, e)
                    e.endpos = t.startpos - .001
                    e.length = e.endpos - e.startpos
                    t.startpos = e.endpos + .001
                    table.insert(l, e)
                end
                table.remove(n, 1)
            end
            table.remove(o, 1)
        end
        self:deleteNotes(i)
        self:insertNotesFromC(l)
    end
    function e:_deleteMinimunLengthNote()
        local t = {}
        for n, e in ipairs(self.editingNotes) do
            if (e.endpos - e.startpos < .001) then
                table.insert(t, e)
            end
        end
        self:deleteNotes(t)
    end
    function e:_checkProcessLimitNum()
        local e = true
        if (#self.editingNotes < self.m_processLimitNoteNum_min + 1) then
            e = false
        end
        if (#self.editingNotes >= self.m_processLimitNoteNum) then
            e = false
        end
        return e
    end
    function e:_detectTargetNotes()
        local e = nil
        if (self:isSelectionInEditingNotes() == true) then
            e = self:_getSelectionNotes(self.editingNotes)
        else
            e = self.editingNotes
        end
        return e
    end
    function e:_getSameStartPosNotes(l, n, e)
        local t = {}
        local e = e or 1
        local n = n or self.editingNotes
        for o = e, #n do
            local n = n[o]
            if (n.startpos == l) then
                table.insert(t, n)
                e = o
            end
        end
        table.sort(
            t,
            function(e, t)
                return (e.pitch > t.pitch)
            end
        )
        return t, e
    end
    function e:_getNearStartPosNotes(i, t, n, o)
        local e = {}
        local n = n or 1
        local t = t or self.editingNotes
        local l = o or 1 / 16
        for o = n, #t do
            local t = t[o]
            if (t.startpos > i - l * .9999 and t.startpos < i + l * .9999) then
                table.insert(e, t)
                n = o
            end
        end
        table.sort(
            e,
            function(e, t)
                return (e.pitch > t.pitch)
            end
        )
        return e, n
    end
    function e:_detectChordNotesNear(o, e, n, l)
        local t = {}
        local n = n or 1
        local e = e or self.editingNotes
        local l = l or 1 / 16
        for i = n, #e do
            local e = e[i]
            if (e.startpos >= o - l * .9999 and e.startpos <= o + l * .9999 and e._checkedAsChordNote_ ~= true) then
                e._checkedAsChordNote_ = true
                table.insert(t, e)
                n = i
            end
        end
        table.sort(
            t,
            function(e, t)
                return (e.pitch > t.pitch)
            end
        )
        return t, n
    end
    function e:_getExistStartPosTable(e)
        local n = {}
        local e = e or self.editingNotes
        table.sort(
            e,
            function(t, e)
                return (t.startpos < e.startpos)
            end
        )
        local t = -100
        for o, e in ipairs(e) do
            if (t ~= e.startpos) then
                table.insert(n, e.startpos)
                t = e.startpos
            end
        end
        return n
    end
    function e:_getFinalEndPos(t)
        local e = 0
        local t = t or self.editingNotes
        for n, t in ipairs(t) do
            if (e < t.endpos) then
                e = t.endpos
            end
        end
        return e
    end
    function e:_getFirstStartPos(e)
        local t = e or self.editingNotes
        local e = self:_getFinalEndPos(t, isSelection)
        for n, t in ipairs(t) do
            if (e > t.startpos) then
                e = t.startpos
            end
        end
        return e
    end
    function e:_getRangeContainsNotes(e, t)
        local n = e.startpos
        local o = e.endpos
        local n = e.length
        local n = t or self.editingNotes
        local t = {}
        for l, n in ipairs(n) do
            if (e.startpos <= n.startpos and n.startpos <= o) then
                table.insert(t, n)
            end
        end
        table.sort(
            t,
            function(t, e)
                return (t.pitch < e.pitch)
            end
        )
        return t
    end
    function e:_selectionReset(e)
        local e = e or self.editingNotes
        for t, e in ipairs(e) do
            e.selection = false
        end
        if (e == self.editingNotes) then
            self.m_isSelection = false
        end
    end
    function e:_toSelectionAll(e)
        local e = e or self.editingNotes
        for t, e in ipairs(e) do
            e.selection = true
        end
        if (e == self.editingNotes) then
            self.m_isSelection = true
        end
    end
    function e:_toSelectionInverse(e)
        local e = e or self.editingNotes
        for t, e in ipairs(e) do
            e.selection = (e.selection == false)
        end
        if (e == self.editingNotes) then
            self.m_firstSelectionCheck = nil
        end
    end
    function e:_getSelectionNoteCount(t)
        local e = 0
        local t = t or self.editingNotes
        for n, t in ipairs(t) do
            if (t.selection == true) then
                e = e + 1
            end
        end
        return e
    end
    function e:_getMaxMinPitch(e)
        local n = e or self.editingNotes
        local e = 200
        local t = -1
        for o, n in ipairs(n) do
            e = math.min(e, n.pitch)
            t = math.max(t, n.pitch)
        end
        return e, t
    end
    function e:_getExistPitchNumber(e)
        local t = e or self.editingNotes
        local e = {}
        for n, t in ipairs(t) do
            local n = false
            for o, e in ipairs(e) do
                if (e == t.pitch) then
                    n = true
                    break
                end
            end
            if (n == false) then
                table.insert(e, t.pitch)
            end
        end
        return e
    end
    function e:_getSelectionNotes(e)
        local t = {}
        local e = e or self.editingNotes
        for n, e in ipairs(e) do
            if (e.selection == true) then
                table.insert(t, e)
            end
        end
        return t
    end
    function e:_getSelectionNotesNum(e)
        local e = self:_getSelectionNotes(e)
        return #e
    end
    function e:_isExistSelectionNotes(t)
        local e = false
        local t = t or self.editingNotes
        for n, t in ipairs(t) do
            if (t.selection == true) then
                e = true
                break
            end
        end
        return e
    end
    function e:_getMaxNoteIdx(t)
        local t = -1
        local n = targetNotes_ or self.editingNotes
        for n, e in ipairs(n) do
            t = math.max(t, e.idx)
        end
        return t
    end
    e:_init(g)
    return e
end




local s = "kawa_MIDICCFunc2"
function createMIDIClipCC()
    local e = createMIDIClip()
    e.m_original_CC = {}
    e.editing_CC = {}
    e.lastTouchedCCLane = 0
    e.processLimitCCCount = 1e3
    e.processLimitCCCount_MIN = 1
    e._isExistSelectedCC = false
    e.maxIdx = 0

	e.midiClip_checkProcessLimitNum = e.checkProcessLimitNum
    
	function e:checkProcessLimitNum(e)
        local t = e or false
        local e = nil
        if (t == true) then
            e = self:midiClip_checkProcessLimitNum()
        else
            e = self:checkCCCountLimit()
        end
        return e
    end

	e._MIDIClip_flush_ = e.flush
    function e:flush(n, t, e)
        if (e == true) then
            self:_MIDIClip_flush_(n, t)
        end
        self:_deleteAllOriginalCCs()
        self:_editingCCToMediaItem()
        reaper.MIDI_Sort(self.take)
    end
    function e:insertCC(e)
        self.maxIdx = self.maxIdx + 1
        e.idx = self.maxIdx
        table.insert(self.editing_CC, e)
    end
    function e:insertCC_B(e)
        if (e == self.editing_CC) then
            return
        end
        for t, e in ipairs(e) do
            self:insertCC(e)
        end
    end
    function e:deleteCC(e)
        for t, n in ipairs(self.editing_CC) do
            if (n.idx == e.idx) then
                table.remove(self.editing_CC, t)
                break
            end
        end
    end
    function e:deleteCC_B(e)
        if (e == self.editing_CC) then
            self.editing_CC = {}
            return
        end
        for t, e in ipairs(e) do
            self:deleteCC(e)
        end
    end
   
   function e:PitchBendGlide(Semitones, res, lenms)
		local seconds = tonumber(lenms) * 0.001 
		local lentick = reaper.TimeMap2_timeToQN( 0, seconds )
        local NotesTable = self:_detectTargetNotes()
        local NoteStart = self:_getExistStartPosTable(NotesTable)
        local Semitones = tonumber(Semitones) or 12
        local res = tonumber(res) or 10  ---Ticks 
        local i = lentick / res
        local n = {}
        
		
		for key, val in ipairs(NoteStart) do
            local val, key = self:_getSameStartPosNotes(val, NotesTable, a)
            table.sort(
                val,
                function(key, val)
                    return (key.pitch < val.pitch)
                end
            )
            local key = -1
            local NotesTable = 200
            for n, val in ipairs(val) do
                key = math.max(key, val.pitch)
                NotesTable = math.min(NotesTable, val.pitch)
            end
            for NotesTable, val in ipairs(val) do
                if (val.pitch == key) then
                    table.insert(n, val)
                end
            end
        end
        
		for NoteStart, NotesTable in ipairs(n) do
            if (NoteStart + 1 <= #n) then
                local cur_note = NotesTable
			
                local NoteStart = n[NoteStart + 1]
				
                local n = cur_note.pitch - NoteStart.pitch
                if (n > Semitones) then
                    n = Semitones
                end
                if (n < -Semitones) then
                    n = -Semitones
                end
                local Semitones = (8192 / Semitones)
                local Semitones = (Semitones * n)
                local Semitones = Semitones / res
                for n = 1, res do
                    local Semitones = 8192 + Semitones * (res - n + 1)
                    local res = math.floor(Semitones / 128)
                    local Semitones = math.floor(Semitones / 128)
                    if (res < 0) then
                        res = 0
                    end
                    if (Semitones < 0) then
                        Semitones = 0
                    end
                    if (res > 127) then
                        res = 127
                    end
                    if (Semitones > 127) then
                        Semitones = 127
                    end
                    
					if (NoteStart.startpos + i * (n - 1)) < NoteStart.endpos
					then
					
					local AddTable = {
                        selection = false,
                        mute = false,
                        position = NoteStart.startpos + i * (n - 1),
                        chanMsg = 224,
                        chan = NotesTable.chan,
                        ccValue = res,
                        ccNum = Semitones,
                        take = self.take
                    }
                    
					self:insertCC(AddTable)
					
					end
					
					
                end
                
				if (NoteStart.startpos + i * res) < NoteStart.endpos
					then
				 
				local AddTable = {
                    selection = false,
                    mute = false,
                    position = NoteStart.startpos + i * res,
                    chanMsg = 224,
                    chan = NotesTable.chan,
                    ccValue = 64,
                    ccNum = 0,
                    take = self.take
                }
                self:insertCC(AddTable)
				end
			
			
            end
        end
    end
 
     function e:_insertCCToMediaItem(e)
        local t = self.take
        if t == nil then
            return
        end
        local c = e.selection or false
        local r = e.mute
        local i = reaper.MIDI_GetPPQPosFromProjQN(t, e.position)
        local l = e.chan
        local o = e.chanMsg
        local n = math.floor(e.ccNum)
        local a = math.floor(e.ccValue)
        local e = e.take
        reaper.MIDI_InsertCC(t, c, r, i, o, l, n, a, false)
    end
     function e:_editingCCToMediaItem()
        for t, e in ipairs(self.editing_CC) do
            self:_insertCCToMediaItem(e)
        end
    end
     function e:_deleteAllOriginalCCs()
        while (#self.m_original_CC > 0) do
            reaper.MIDI_DeleteCC(
                self.m_original_CC[#self.m_original_CC].take,
                self.m_original_CC[#self.m_original_CC].idx
            )
            table.remove(self.m_original_CC, #self.m_original_CC)
        end
    end

    return e
end
local e = createMIDIClipCC()
if (e:checkProcessLimitNum(true)) then
    local ret, uinputstr =
        reaper.GetUserInputs(
        "pitchBend Glide",
        3,
        "PitchBend range (+-semitone),GlideResolution,GlideLength (ms)",
        "12,32,80,--,--,--,--"
    )
    if (ret) then
        reaper.Undo_BeginBlock()
        uinputstr = string.gsub(uinputstr, " ", "")
        local uinputstr = uinputstr:split(",")
        local n = uinputstr[1]
        local o = uinputstr[2]
        local lenms = uinputstr[3]
        e:PitchBendGlide(n, o, lenms)
        e:flush()
        reaper.Undo_EndBlock("kawa Dummy PitchBend Glide", -1)
        reaper.UpdateArrange()
    end
end

