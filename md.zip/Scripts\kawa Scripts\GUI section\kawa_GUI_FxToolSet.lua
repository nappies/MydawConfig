﻿--======================================================================
--[[ 
* ReaScript Name: "kawa_GUI_FxToolSet. 
* Version: 2017/08/18 
* Author: kawa_ 
* Author URI: http://forum.cockos.com/member.php?u=105939 
* Repository: BitBucket - kawaCat - ReaScript-M2B 
* Repository URI: https://bitbucket.org/kawaCat/reascript-m2bpack/ 
--]]
--======================================================================
bit32 = {band = function(a, b)
        return a & b
    end, bor = function(a, b)
        return a | b
    end, bxor = function(a, b)
        return a ~ b
    end, bnot = function(a)
        return ~a
    end, rshift = function(a, n)
        return a >> n
    end, lshift = function(a, n)
        return a << n
    end}
function checkReaperAppVersion()
    local e = false
    for n, t in pairs(reaper) do
        if (tostring(n) == "Envelope_GetParentTake") then
            e = true
            break
        end
    end
    if (e == false) then
        reaper.ShowMessageBox("This script Need Reaper Version 5.24 ~ ", "Can Not Execute", 0)
    end
    return e
end
function check_SWS_Function(n)
    local e = false
    e = reaper.APIExists("BR_EnvAlloc")
    if (e == false and n ~= true) then
        reaper.ShowMessageBox(
            "This Scripts Need SWS/S&M Extenstion. \n" .. "\n" .. "Please Check  www.sws-extension.org .",
            "stop",
            0
        )
    end
    return e
end
function getDirSep()
    return (package.config:sub(1, 1))
end
function getExecutedScriptName(t)
    local n, e, n, n, n, n, n = reaper.get_action_context()
    local n = "kawa " .. string.gsub(e, (#e) - 20, (#e))
    local a = getDirSep()
    local a = "(.*" .. a .. ")"
    local n = string.match(e, a) or n
    local e = string.gsub(e, n, "")
    e = e:gsub("_", " ")
    if (t == true) then
        e = e:match("(.*)%.lua")
    end
    return e
end
function sqrt2(t)
    local n = t
    local e
    if (t == 0) then
        return 0
    end
    while (n < e) do
        e = n
        n = bit32.rshift((e + t / e), 1)
        n = (e + t / e) / 2
    end
    return e
end
function sqrt3(e)
    local e = e
    local n = (e + e / e) / 2
    local e = (n + e / n) / 2
    return x4
end
function sqrt4(e)
    local e = e
    local n = (e + e / e) / 2
    local n = (n + e / n) / 2
    local e = (n + e / n) / 2
    return e
end
function sqrt10(e)
    local e = e
    local n = (e + e / e) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local e = (n + e / n) / 2
    return e
end
function sqrt8(e)
    if (e == 0) then
        return 0
    end
    local e = e
    local n = (e + e / e) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local e = (n + e / n) / 2
    return e
end
function sqrt9(e)
    if (e == 0) then
        return 0
    end
    local e = e
    local n = (e + e / e) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local n = (n + e / n) / 2
    local e = (n + e / n) / 2
    return e
end
local a = {}
local n = -1
local function e(e)
    n = e
    local n = math.pi / 2 / e
    for e = 1, e do
        table.insert(a, math.cos(e * n))
    end
end
local function o(e)
    local t = 1
    if (e < 0) then
        e = -e
    end
    e = e / math.pi
    e = (e - (math.floor)(e / 2) * 2)
    if (e > 1) then
        e = 2 - e
    end
    if (e > .5) then
        e = 1 - e
        t = -1
    end
    local e = math.floor(e * 2 * (n)) + 1
    if (e > n) then
        e = e - 1
    end
    return (t * a[e])
end
local function e(e)
    return o(e - (math.pi / 2))
end
local function n(e)
    if e == 0 then
        return 1
    else
        return e * n(e - 1)
    end
end
local function o(a)
    local t = 0
    local e = 0
    for e = 1, 5 do
        t = t + (a ^ (4 * e - 3)) / n(4 * e - 3)
    end
    for t = 1, 5 do
        e = e + (a ^ (4 * t - 1)) / n(4 * t - 1)
    end
    local e = t - e
    return e
end
local function e(e)
    return o(e + (math.pi / 2))
end
local a = 4 / math.pi
local t = -4 / (math.pi * math.pi)
local function e(e)
    e = e - math.pi
    local n = e
    if (e < 0) then
        n = -e
    end
    return -(a * e + t * e * n)
end
function deepcopy(n)
    local t = type(n)
    local e
    if t == "table" then
        e = {}
        for t, n in next, n, nil do
            e[deepcopy(t)] = deepcopy(n)
        end
        setmetatable(e, deepcopy(getmetatable(n)))
    else
        e = n
    end
    return e
end
function metaTableCopy(...)
    local e = {}
    local o = {...}
    local function a(t, e)
        for n = 1, #e do
            local e = e[n][t]
            if e then
                return e
            end
        end
    end
    setmetatable(
        e,
        {__index = function(t, e)
                local n = a(e, o)
                t[e] = n
                return n
            end}
    )
    e.__index = e
    return e
end
function mergeClass(...)
    return metaTableCopy(...)
end
function table.toString(t)
    local function d(e)
        return string.format("%q", e)
    end
    local s = ""
    local function e(e)
        s = s .. e
    end
    local c, n = "   ", "\n"
    local i, t = {t}, {[t] = 1}
    e("return {" .. n)
    for a, r in ipairs(i) do
        e("-- Table: {" .. a .. "}" .. n)
        e("{" .. n)
        local s = {}
        for o, a in ipairs(r) do
            s[o] = true
            local o = type(a)
            if o == "table" then
                if not t[a] then
                    table.insert(i, a)
                    t[a] = #i
                end
                e(c .. "{" .. t[a] .. "}," .. n)
            elseif o == "string" then
                e(c .. d(a) .. "," .. n)
            elseif o == "number" then
                e(c .. tostring(a) .. "," .. n)
            end
        end
        for r, l in pairs(r) do
            if (not s[r]) then
                local a = ""
                local o = type(r)
                if o == "table" then
                    if not t[r] then
                        table.insert(i, r)
                        t[r] = #i
                    end
                    a = c .. "[{" .. t[r] .. "}]="
                elseif o == "string" then
                    a = c .. "[" .. d(r) .. "]="
                elseif o == "number" then
                    a = c .. "[" .. tostring(r) .. "]="
                end
                if (a ~= "") then
                    o = type(l)
                end
                if o == "table" then
                    if not t[l] then
                        table.insert(i, l)
                        t[l] = #i
                    end
                    e(a .. "{" .. t[l] .. "}," .. n)
                elseif o == "string" then
                    e(a .. d(l) .. "," .. n)
                elseif o == "number" then
                    e(a .. tostring(l) .. "," .. n)
                elseif o == "boolean" then
                    e(a .. tostring(l) .. "," .. n)
                end
            end
        end
        e("}," .. n)
    end
    e("}")
    return s
end
function table.fromString(e)
    local e = load(e)
    local e = e()
    if (type(e) ~= "table") then
        local e = {}
        return e
    end
    for n = 1, #e do
        local o = {}
        for t, a in pairs(e[n]) do
            if type(a) == "table" then
                e[n][t] = e[a[1]]
            end
            if type(t) == "table" and e[t[1]] then
                table.insert(o, {t, e[t[1]]})
            end
        end
        for a, t in ipairs(o) do
            e[n][t[2]], e[n][t[1]] = e[n][t[1]], nil
        end
    end
    return e[1]
end
function table.doubleCheck(a, o, e)
    local t = false
    local n = e or true
    local e = ipairs
    if (n == false) then
        e = pairs
    end
    for n, e in e(a) do
        if (e == o) then
            return true
        end
    end
    return t
end
function table.metaTableCopy(e)
    return metaTableCopy(e)
end
function table.deepcopy(e)
    return deepcopy(e)
end
function table.mergeTable(a, ...)
    local n = {}
    local t = {...}
    local e = ipairs
    if (a) then
        e = pairs
    end
    for a, t in e(t) do
        for t, e in e(t) do
            table.insert(n, e)
        end
    end
    return n
end
function _toIntColor(e, n, a)
    local e = string.format("%x", e)
    local t = string.format("%x", n)
    local n = string.format("%x", a)
    if (#e < 2) then
        e = "0" .. e
    end
    if (#t < 2) then
        t = "0" .. t
    end
    if (#n < 2) then
        n = "0" .. n
    end
    local e = "01" .. n .. t .. e
    return tonumber(e, 16)
end
function _toIntColor2(t, n, e)
    return t + math.floor(n * 256) + math.floor((e * 65536))
end
function _colorToNative(t, e, n)
    return reaper.ColorToNative(t, e, n)
end
function _nativeToColor(e)
    local n, t, e = reaper.ColorFromNative(e)
    return n, t, e
end
function HSVToRGB(d, i, f)
    local o, r, a, l, s, e, n, c, t
    local d = d
    local i = i
    if (d > 360) then
        d = d - 360
    elseif (d < 0) then
        d = d + 360
    end
    if (i > 1) then
        i = 1
    elseif (i < 0) then
        i = 0
    end
    e = math.floor(255 * f)
    if (e > 255) then
        e = 255
    elseif (e < 0) then
        e = 0
    end
    if (i == 0) then
        o = e
        r = e
        a = e
    else
        l = math.floor(d / 60)
        s = d / 60 - l
        n = math.floor(e * (1 - i))
        if (n < 0) then
            n = 0
        elseif (n > 255) then
            n = 255
        end
        c = math.floor(e * (1 - s * i))
        if (c < 0) then
            c = 0
        elseif (c > 255) then
            c = 255
        end
        t = math.floor(e * (1 - (1 - s) * i))
        if (t < 0) then
            t = 0
        elseif (t > 255) then
            t = 255
        end
        if (l == 0) then
            o = e
            r = t
            a = n
        elseif (l == 1) then
            o = c
            r = e
            a = n
        elseif (l == 2) then
            o = n
            r = e
            a = t
        elseif (l == 3) then
            o = n
            r = c
            a = e
        elseif (l == 4) then
            o = t
            r = n
            a = e
        elseif (l == 5) then
            o = e
            r = n
            a = c
        else
            o = e
            r = t
            a = n
        end
    end
    return o, r, a
end
function RGBToHSV(a, t, o)
    local e, l, i
    local r = math.min(a, t, o)
    local n = math.max(a, t, o)
    i = n
    local r = n - r
    if (n ~= 0) then
        l = r / n
    else
        l = 0
        e = 0
        return e, l, i / 255
    end
    if (a == n) then
        e = (t - o) / r
    elseif (t == n) then
        e = 2 + (o - a) / r
    else
        e = 4 + (a - t) / r
    end
    e = e * 60
    if (e < 0) then
        e = e + 360
    end
    return e, l, i / 255
end
function color_Mul(e, n)
    return {e[1] * n, e[2] * n, e[3] * n, e[4]}
end
function color_Darker(e, n)
    local n = n or .8
    return color_Mul(e, n)
end
function color_Brighter(n, e)
    local e = e or 1.2
    return color_Mul(n, e)
end
function color_getInvert(e, t)
    local a = 1 - e[1]
    local o = 1 - e[2]
    local r = 1 - e[3]
    local n = e[4]
    if (t) then
        n = 1 - e[4]
    end
    return {a, o, r, n}
end
function rotPoint(o, a, t, n, e)
    local t = t - o
    local n = n - a
    local r = t * math.cos(e) - n * math.sin(e)
    local e = t * math.sin(e) + n * math.cos(e)
    local n = o + r
    local e = a + e
    return n, e
end
function scalePoint(t, n, o, a, e)
    local t = ((o - t) * e) + t
    local e = ((a - n) * e) + n
    return t, e
end
function string:split(e)
    local n, e = e or ":", {}
    local n = string.format("([^%s]+)", n)
    self:gsub(
        n,
        function(n)
            e[#e + 1] = n
        end
    )
    return e
end
function stringIter(n)
    local e = 0
    local t = string.len(n)
    return function()
        e = e + 1
        if (e > t) then
            return nil
        else
            return e, string.sub(n, e, e)
        end
    end
end
function stringToTable(n)
    local e = {}
    n:gsub(
        ".",
        function(n)
            table.insert(e, n)
        end
    )
    return e
end
function stringIterMB(n)
    local e = 0
    local t = string.len(n)
    return function()
        e = e + 1
        if (e > t) then
            return nil
        else
            return e, mbStrSub(n, e, e)
        end
    end
end
function toByteString(n)
    local e = {}
    for t, n in stringIter(n) do
        table.insert(e, string.byte(n))
    end
    return table.concat(e, ",")
end
function restorByteString(n)
    local e = {}
    for t, n in ipairs(n) do
        table.insert(e, string.char(n))
    end
    return table.concat(e, "")
end
function getMbLengh(r)
    local e = r
    local o = ""
    local e = nil
    local n = 0
    local t = 1
    local a = 0
    while (true) do
        o = string.sub(r, t, t)
        e = string.byte(o)
        if (e == nil) then
            break
        end
        if e < 128 then
            n = 1
        elseif e < 224 then
            n = 2
        elseif e < 240 then
            n = 3
        elseif e < 248 then
            n = 4
        elseif e < 252 then
            n = 5
        elseif e < 254 then
            n = 6
        end
        t = t + n
        a = a + 1
    end
    return a
end
function isContainMultiByteStr(a)
    local o = false
    local e = a
    local r = ""
    local n = nil
    local e = 0
    local t = 1
    while (true) do
        r = string.sub(a, t, t)
        n = string.byte(r)
        if (n == nil) then
            break
        end
        if n < 128 then
            e = 1
        elseif n < 224 then
            e = 2
        elseif n < 240 then
            e = 3
        elseif n < 248 then
            e = 4
        elseif n < 252 then
            e = 5
        elseif n < 254 then
            e = 6
        end
        t = t + e
        if (e > 1) then
            o = true
            break
        end
    end
    return o
end
function mbStrSub(o, c, d)
    if type(o) ~= "string" then
        return "-"
    end
    local r = ""
    local l = ""
    local e = nil
    local a = 0
    local n = 0
    local t = 1
    local i = 1
    local i = {}
    while (true) do
        l = string.sub(o, t, t)
        e = string.byte(l)
        if (e == nil) then
            break
        end
        if e < 128 then
            n = 1
        elseif e < 224 then
            n = 2
        elseif e < 240 then
            n = 3
        elseif e < 248 then
            n = 4
        elseif e < 252 then
            n = 5
        elseif e < 254 then
            n = 6
        end
        local e = string.sub(o, t, t + (n - 1))
        t = t + n
        if (e ~= nil) then
            table.insert(i, e)
        end
        a = a + 1
    end
    local n = c or 1
    local e = d or a
    if (n < 1) then
        n = 1
    end
    if (e < n) then
        e = n
    end
    if (n > e) then
        n = e - 1
    end
    if (e > a) then
        e = a
    end
    for e = n, e do
        r = r .. i[e]
    end
    return r
end
DEFINE_MIN_DB = -96
DEFINE_MIN_DB_VALUE = (10 ^ (DEFINE_MIN_DB * .05))
function math.valueToDecivel(e)
    local e = math.log(e, 10) * 20
    if (e < DEFINE_MIN_DB) then
        e = DEFINE_MIN_DB
    end
    return e
end
function math.decivelToValue(e)
    local e = (10 ^ (e * .05))
    if (e < DEFINE_MIN_DB_VALUE) then
        e = DEFINE_MIN_DB_VALUE
    end
    return e
end
function math.getNearEven(e)
    local e = e
    if ((e % 2) ~= 0) then
        e = e - 1
    end
    return math.floor(e)
end
function math.getNearOdd(e)
    local e = e
    if ((e % 2) == 0) then
        e = e - 1
    end
    return math.floor(e)
end
function getManhattanDist(n, e, t, a)
    return math.abs(n - t) + math.abs(e - a)
end
function getEuclideanDist(e, t, a, n)
    local e = math.abs(e - a)
    local n = math.abs(t - n)
    local e = math.sqrt((e ^ 2) + (n ^ 2))
    return e
end
function getChebyshevDist(e, t, a, n)
    local e = math.abs(e - a)
    local n = math.abs(t - n)
    if (e > n) then
        return e
    else
        return n
    end
end
local o = 123 / 128
local i = 51 / 128
function approx_distance(e, r, n, l)
    local a
    local t
    local n = math.abs(e - n)
    local e = math.abs(r - l)
    a = math.min(n, e)
    t = math.max(n, e)
    return (o * t) + (i * a)
end
function checkValueLength_circle(e, a, n)
    local e = e
    local t = math.max(a, n)
    local n = math.min(a, n)
    if (e > t) then
        e = n
    end
    if (e < n) then
        e = t
    end
    return e
end
local t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
function base_64_enc(a)
    return ((a:gsub(
        ".",
        function(e)
            local e, t = "", e:byte()
            for n = 8, 1, -1 do
                e = e .. (t % 2 ^ n - t % 2 ^ (n - 1) > 0 and "1" or "0")
            end
            return e
        end
    ) .. "0000"):gsub(
        "%d%d%d?%d?%d?%d?",
        function(a)
            if (#a < 6) then
                return ""
            end
            local e = 0
            for n = 1, 6 do
                e = e + (a:sub(n, n) == "1" and 2 ^ (6 - n) or 0)
            end
            return t:sub(e + 1, e + 1)
        end
    ) .. ({"", "==", "="})[#a % 3 + 1])
end
function base_64_dec(e)
    e = string.gsub(e, "[^" .. t .. "=]", "")
    return (e:gsub(
        ".",
        function(e)
            if (e == "=") then
                return ""
            end
            local e, t = "", (t:find(e) - 1)
            for n = 6, 1, -1 do
                e = e .. (t % 2 ^ n - t % 2 ^ (n - 1) > 0 and "1" or "0")
            end
            return e
        end
    ):gsub(
        "%d%d%d?%d?%d?%d?%d?%d?",
        function(t)
            if (#t ~= 8) then
                return ""
            end
            local n = 0
            for e = 1, 8 do
                n = n + (t:sub(e, e) == "1" and 2 ^ (7 - e) or 0)
            end
            return string.char(n)
        end
    ))
end
local e = {}
e.char = {"A", "B", "C", "D", "E", "F", "1", "2", "3", "4", "5", "6", "7", "8", "9"}
e.isHyphen = {[9] = 1, [14] = 1, [19] = 1, [24] = 1}
e.used = {}
function generateGUID()
    local n = 0
    math.randomseed(reaper.time_precise() * os.time() / 1e3)
    e.currentGuid = nil
    while (true) do
        n = n + 1
        if (n > 20) then
            return false
        end
        e.pass = {}
        for n = 1, 36 do
            if e.isHyphen[n] then
                e.x = "-"
            else
                e.a = math.random(1, #e.char)
                e.x = e.char[e.a]
            end
            table.insert(e.pass, e.x)
        end
        z = nil
        e.currentGuid = tostring(table.concat(e.pass))
        if e.used[e.currentGuid] == nil then
            e.used[e.currentGuid] = e.currentGuid
            return (e.currentGuid)
        else
        end
    end
end
function fileExists(e)
    local e = io.open(e, "rb")
    if (e ~= nil) then
        e:close()
    end
    return (e ~= nil)
end
function readFileWithSplitedLine(e)
    if (fileExists(e) == false) then
        return {}
    end
    local n = {}
    for e in io.lines(e) do
        table.insert(n, e)
    end
    return n
end
function readAll(e)
    local e = io.open(e, "rb")
    local n = e:read("*all")
    e:close()
    return n
end
function getBezierPointQB(e, i, l, r, o, t, a)
    local n = 1 - e
    local t = e * e * t + 2 * e * n * r + n * n * i
    local e = e * e * a + 2 * e * n * o + n * n * l
    return t, e
end
function getBezierAngleQB(e, o, r, n, t, l, i)
    local a = 1 - e
    local n = 2 * (e * (l - n) + a * (n - o))
    local e = 2 * (e * (i - t) + a * (t - r))
    return math.atan2(e, n)
end
if (package.config:sub(1, 1) == "\\") then
else
end
DEFINE_COMPONENT_USE_OFFSCREEN = true
if (DEFINE_COMPONENT_USE_OFFSCREEN) then
    DEFINE_COMPONENT_USE_EACH_OFFSCREEN = false
end
local C = "@"
local F = "r"
local P = "s"
local r = 1023
local i = 1022
local d = 1021
local c = 1020
local s = 1019
local b = .5
local f = 160
local p = {
    82,
    101,
    97,
    83,
    99,
    114,
    105,
    112,
    116,
    45,
    77,
    105,
    100,
    105,
    58,
    10,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    10,
    67,
    111,
    110,
    116,
    114,
    105,
    98,
    117,
    116,
    111,
    114,
    115,
    58,
    32,
    82,
    101,
    97,
    112,
    101,
    114,
    32,
    70,
    111,
    114,
    117,
    109,
    32,
    97,
    110,
    100,
    32,
    50,
    99,
    104,
    32,
    70,
    111,
    114,
    117,
    109,
    32,
    10,
    80,
    114,
    111,
    103,
    114,
    97,
    109,
    58,
    32,
    107,
    97,
    119,
    97,
    95,
    10,
    82,
    101,
    97,
    112,
    101,
    114,
    32,
    70,
    111,
    114,
    117,
    109,
    32,
    85,
    115,
    101,
    114,
    32,
    73,
    68,
    58,
    32,
    91,
    107,
    97,
    119,
    97,
    95,
    93,
    32,
    117,
    61,
    49,
    48,
    53,
    57,
    51,
    57,
    32,
    10,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    10
}
local g = {
    10,
    229,
    144,
    141,
    231,
    132,
    161,
    227,
    129,
    151,
    227,
    130,
    181,
    227,
    131,
    179,
    227,
    131,
    151,
    227,
    131,
    170,
    227,
    131,
    179,
    227,
    130,
    176,
    239,
    188,
    160,
    52,
    56,
    107,
    72,
    122,
    10,
    50,
    48,
    49,
    54,
    47,
    48,
    50,
    47,
    50,
    51,
    40,
    231,
    129,
    171,
    41,
    32,
    50,
    49,
    58,
    51,
    53,
    58,
    48,
    49,
    46,
    48,
    56,
    32,
    73,
    68,
    58,
    50,
    56,
    100,
    49,
    121,
    112,
    116,
    81,
    10,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    239,
    188,
    143,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    227,
    131,
    189,
    58,
    32,
    58,
    32,
    58,
    239,
    188,
    188,
    10,
    46,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    239,
    188,
    143,
    58,
    32,
    47,
    58,
    32,
    58,
    32,
    58,
    47,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    227,
    131,
    189,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    39,
    44,
    58,
    32,
    58,
    32,
    58,
    46,
    227,
    131,
    189,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    47,
    58,
    32,
    58,
    32,
    47,
    58,
    32,
    58,
    32,
    58,
    47,
    123,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    124,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    46,
    58,
    124,
    58,
    46,
    58,
    46,
    58,
    46,
    58,
    46,
    58,
    46,
    58,
    46,
    46,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    47,
    58,
    32,
    58,
    32,
    47,
    58,
    239,
    188,
    188,
    47,
    226,
    136,
    167,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    124,
    58,
    46,
    32,
    58,
    46,
    32,
    58,
    32,
    58,
    124,
    58,
    46,
    58,
    227,
    131,
    143,
    46,
    58,
    46,
    58,
    46,
    58,
    39,
    44,
    10,
    46,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    47,
    58,
    32,
    58,
    32,
    58,
    32,
    124,
    239,
    188,
    188,
    47,
    95,
    95,
    95,
    227,
    131,
    142,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    227,
    131,
    136,
    239,
    189,
    152,
    95,
    95,
    95,
    32,
    108,
    46,
    58,
    46,
    124,
    58,
    46,
    58,
    124,
    46,
    58,
    46,
    58,
    46,
    58,
    46,
    124,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    39,
    58,
    32,
    58,
    32,
    33,
    58,
    32,
    58,
    124,
    58,
    32,
    58,
    123,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    226,
    136,
    168,
    239,
    188,
    188,
    95,
    95,
    124,
    227,
    128,
    128,
    227,
    131,
    189,
    58,
    32,
    58,
    108,
    58,
    46,
    58,
    124,
    58,
    46,
    58,
    124,
    46,
    58,
    46,
    58,
    46,
    58,
    46,
    124,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    239,
    189,
    137,
    58,
    32,
    58,
    32,
    58,
    124,
    58,
    229,
    133,
    171,
    58,
    32,
    124,
    32,
    227,
    128,
    128,
    32,
    95,
    95,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    95,
    95,
    227,
    128,
    128,
    86,
    58,
    32,
    47,
    58,
    32,
    58,
    124,
    46,
    58,
    46,
    58,
    46,
    58,
    46,
    124,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    124,
    58,
    32,
    58,
    32,
    58,
    108,
    32,
    58,
    32,
    58,
    227,
    131,
    189,
    124,
    32,
    227,
    130,
    163,
    39,
    226,
    140,
    146,
    239,
    189,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    39,
    226,
    140,
    146,
    227,
    131,
    189,
    86,
    58,
    32,
    58,
    32,
    58,
    46,
    124,
    58,
    46,
    58,
    46,
    58,
    46,
    58,
    124,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    124,
    58,
    32,
    58,
    32,
    58,
    124,
    32,
    58,
    32,
    58,
    32,
    227,
    131,
    143,
    120,
    120,
    120,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    120,
    120,
    120,
    124,
    58,
    32,
    239,
    189,
    140,
    32,
    58,
    239,
    189,
    156,
    46,
    58,
    46,
    58,
    46,
    124,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    124,
    226,
    136,
    167,
    58,
    124,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    229,
    133,
    171,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    156,
    227,
    128,
    156,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    227,
    131,
    142,
    58,
    32,
    108,
    32,
    58,
    46,
    227,
    131,
    142,
    46,
    58,
    46,
    58,
    46,
    58,
    46,
    124,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    108,
    227,
    128,
    128,
    227,
    131,
    143,
    58,
    32,
    58,
    32,
    58,
    32,
    58,
    108,
    58,
    46,
    58,
    239,
    188,
    158,
    32,
    227,
    128,
    129,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    46,
    46,
    32,
    227,
    130,
    164,
    46,
    58,
    124,
    58,
    32,
    108,
    32,
    47,
    46,
    58,
    46,
    58,
    226,
    136,
    167,
    123,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    239,
    188,
    188,
    58,
    32,
    124,
    227,
    131,
    189,
    95,
    227,
    131,
    142,
    108,
    239,
    188,
    188,
    226,
    128,
    190,
    239,
    188,
    143,
    227,
    131,
    136,
    32,
    227,
    128,
    129,
    106,
    58,
    32,
    108,
    47,
    46,
    58,
    46,
    58,
    47,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    44,
    114,
    39,
    58,
    58,
    58,
    58,
    58,
    47,
    58,
    58,
    58,
    58,
    124,
    227,
    128,
    128,
    32,
    228,
    186,
    186,
    227,
    128,
    128,
    46,
    124,
    58,
    58,
    58,
    58,
    227,
    128,
    129,
    58,
    58,
    58,
    58,
    58,
    227,
    131,
    143,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    82,
    101,
    97,
    112,
    101,
    114,
    32,
    111,
    102,
    102,
    105,
    99,
    105,
    97,
    108,
    32,
    115,
    105,
    116,
    101,
    32,
    97,
    108,
    119,
    97,
    121,
    115,
    32,
    119,
    101,
    108,
    99,
    111,
    109,
    101,
    32,
    121,
    111,
    117,
    33,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    47,
    58,
    58,
    105,
    32,
    58,
    58,
    227,
    128,
    136,
    58,
    58,
    58,
    58,
    58,
    58,
    124,
    226,
    136,
    168,
    229,
    187,
    191,
    226,
    136,
    168,
    124,
    58,
    58,
    58,
    58,
    58,
    227,
    128,
    137,
    58,
    58,
    58,
    124,
    58,
    65,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    227,
    128,
    128,
    95,
    47,
    58,
    58,
    58,
    58,
    58,
    58,
    124,
    58,
    58,
    32,
    58,
    46,
    227,
    128,
    137,
    58,
    58,
    58,
    227,
    131,
    136,
    227,
    128,
    129,
    32,
    229,
    133,
    171,
    32,
    44,
    227,
    130,
    164,
    124,
    58,
    58,
    58,
    227,
    128,
    136,
    58,
    58,
    58,
    58,
    58,
    124,
    58,
    105,
    226,
    136,
    167,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    125,
    32,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    33,
    58,
    46,
    227,
    128,
    136,
    58,
    58,
    58,
    58,
    58,
    58,
    124,
    239,
    188,
    188,
    226,
    136,
    168,
    239,
    188,
    143,
    124,
    58,
    58,
    58,
    58,
    58,
    58,
    227,
    128,
    137,
    58,
    58,
    124,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    39,
    44,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    229,
    142,
    182,
    46,
    58,
    46,
    58,
    46,
    58,
    58,
    46,
    58,
    124,
    58,
    58,
    58,
    58,
    58,
    39,
    44,
    58,
    58,
    58,
    58,
    108,
    227,
    128,
    128,
    32,
    239,
    189,
    128,
    194,
    180,
    227,
    128,
    128,
    32,
    124,
    58,
    58,
    58,
    47,
    58,
    58,
    58,
    58,
    58,
    124,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    227,
    131,
    143,
    239,
    188,
    191,
    239,
    188,
    191,
    239,
    188,
    191,
    10,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    95,
    227,
    128,
    128,
    46,
    46,
    45,
    226,
    128,
    144,
    39,
    226,
    140,
    146,
    227,
    131,
    188,
    45,
    39,
    58,
    58,
    58,
    58,
    47,
    124,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    39,
    44,
    58,
    58,
    58,
    33,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    124,
    58,
    47,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    124,
    39,
    44,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    239,
    189,
    128,
    58,
    58,
    58,
    227,
    128,
    131,
    58,
    239,
    188,
    143,
    226,
    140,
    146,
    227,
    129,
    164,
    10,
    227,
    128,
    128,
    32,
    232,
    190,
    183,
    226,
    140,
    146,
    227,
    131,
    152,
    58,
    58,
    58,
    58,
    58,
    125,
    33,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    47,
    227,
    128,
    128,
    124,
    32,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    227,
    128,
    130,
    124,
    32,
    227,
    128,
    128,
    32,
    227,
    131,
    190,
    227,
    128,
    129,
    46,
    124,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    124,
    32,
    39,
    44,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    123,
    123,
    58,
    58,
    58,
    123,
    95,
    32,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    239,
    188,
    188,
    10,
    227,
    128,
    128,
    239,
    188,
    143,
    32,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    131,
    142,
    58,
    58,
    228,
    187,
    143,
    45,
    226,
    128,
    144,
    226,
    148,
    128,
    32,
    226,
    128,
    178,
    32,
    124,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    124,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    124,
    58,
    58,
    58,
    58,
    58,
    58,
    46,
    58,
    58,
    58,
    58,
    124,
    227,
    128,
    128,
    239,
    189,
    128,
    227,
    131,
    188,
    226,
    128,
    144,
    45,
    45,
    227,
    128,
    129,
    58,
    58,
    58,
    58,
    58,
    239,
    188,
    158,
    227,
    128,
    129,
    228,
    185,
    130,
    227,
    130,
    158,
    10,
    227,
    128,
    128,
    227,
    128,
    136,
    44,
    227,
    130,
    175,
    227,
    130,
    177,
    39,
    226,
    128,
    190,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    124,
    58,
    58,
    58,
    58,
    58,
    58,
    58,
    32,
    58,
    58,
    227,
    128,
    130,
    124,
    227,
    128,
    128,
    227,
    128,
    128,
    32,
    227,
    128,
    128,
    32,
    124,
    58,
    58,
    58,
    58,
    32,
    58,
    58,
    58,
    58,
    58,
    58,
    124,
    227,
    128,
    128,
    10
}
local m = {
    10,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    32,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    32,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    10,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    10,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    157,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    32,
    32,
    32,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    157,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    157,
    32,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    10,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    32,
    32,
    32,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    32,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    149,
    154,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    157,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    10,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    149,
    154,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    151,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    32,
    32,
    32,
    32,
    32,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    32,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    148,
    226,
    149,
    157,
    226,
    150,
    136,
    226,
    150,
    136,
    226,
    149,
    145,
    10,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    32,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    32,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    32,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    32,
    32,
    32,
    32,
    32,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    32,
    32,
    32,
    32,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    144,
    226,
    149,
    157,
    32,
    226,
    149,
    154,
    226,
    149,
    144,
    226,
    149,
    157,
    10,
    10
}
math.randomseed(reaper.time_precise() * os.time() / 1e3)
if (_DBG_ == true) then
else
    function DBG()
    end
end
function createStepTable(n)
    local e = {}
    e.currentIdx = 1
    e.tables = n or {}
    e._isLoop = true
    function e:getNext(e)
        return self:getAndForward(e)
    end
    function e:getPrev(e)
        return self:getAndBackWard(e)
    end
    function e:now()
        return self.tables[math.floor(self.currentIdx)]
    end
    function e:current()
        return self.tables[math.floor(self.currentIdx)]
    end
    function e:step(e)
        return self:getAndForward(e)
    end
    function e:back(e)
        return self:getAndBackWard(e)
    end
    function e:setTableElement(e)
        self.tables = deepcopy(e)
        self.currentIdx = 1
    end
    function e:addTableElement(e)
        for n, e in pairs(e) do
            table.insert(self.tables, e)
        end
    end
    function e:clearTableElement()
        self.tables = {}
    end
    function e:getAndForward(e)
        local n = self.tables[math.floor(self.currentIdx)]
        local e = e or 1
        self:_step(e)
        return n
    end
    function e:getAndBackWard(n)
        local e = self.tables[math.floor(self.currentIdx)]
        local n = n or -1
        self:_step(n)
        return e
    end
    function e:setLoop(e)
        self._isLoop = e
    end
    function e:toggleLoop()
        self:setLoop((self._isLoop == false))
    end
    function e:isLoop()
        return (self._isLoop)
    end
    function e:isStart()
        return (self.currentIdx == 1)
    end
    function e:isEnd()
        return (self.currentIdx == #self.tables)
    end
    function e:isEmpty()
        return (#self.tables < 1)
    end
    function e:_step(e)
        local e = self.currentIdx + e
        if (self:isLoop() == true) then
            e = self:_checkLength_circle(e, #self.tables, 1)
        end
        e = math.max(math.min(e, #self.tables), 1)
        self.currentIdx = math.floor(e)
    end
    function e:_checkLength_circle(e, a, n)
        local e = e
        local t = math.max(a, n)
        local n = math.min(a, n)
        if (e > t) then
            e = n
        end
        if (e < n) then
            e = t
        end
        return e
    end
    return e
end
function createDummyTimer()
    local n = reaper.time_precise
    local e = {}
    e._intervalTime = 1
    e._lastTime = n()
    e._callBackFuncTable = {}
    e._diffTime = 0
    e._isRunning = false
    function e:startTimer()
        self._isRunning = true
        self._lastTime = n() - self:getDiffTime()
    end
    function e:resetTimer()
        self._lastTime = n()
        self:_updateDiffTime()
        self._isRunning = false
    end
    function e:toggleTimer()
        if (self._isRunning == true) then
            self:stopTimer()
        else
            self:startTimer()
        end
    end
    function e:stopTimer()
        self._isRunning = false
    end
    function e:isRunning()
        return self._isRunning
    end
    function e:update()
        self:updateAndCheck()
    end
    function e:updateAndCheck()
        if (self:isRunning() == true) then
            self:_updateDiffTime()
            if (self:getDiffTime() >= self._intervalTime) then
                self._lastTime = n()
                self:_updateDiffTime()
                self:_timerCallBack()
            end
        end
    end
    function e:setTimerTime(e)
        self._intervalTime = e
    end
    function e:getTimerTime()
        return self._intervalTime
    end
    function e:getIntervalTime()
        return self:getTimerTime()
    end
    function e:addTimerCallBackFunction(e)
        if (table.doubleCheck(self._callBackFuncTable, e) == false) then
            table.insert(self._callBackFuncTable, e)
        end
    end
    function e:getDiffTime()
        return self._diffTime
    end
    function e:getDiffTimeV()
        return (self:getDiffTime() / self._intervalTime)
    end
    function e:timerCallBack()
    end
    function e:_timerCallBack()
        self:timerCallBack()
        for n, e in ipairs(self._callBackFuncTable) do
            if (type(e) == "function") then
                e()
            end
        end
    end
    function e:_updateDiffTime()
        local e = n()
        self._diffTime = (e - self._lastTime)
    end
    return e
end
function createCounter(n)
    local e = {}
    e.m_value = 0
    e.m_stepValue = 0
    e.m_frameNum = n or 60
    e.m_isLoopMode = false
    e._CLASS_TYPE = "Counter"
    function e:isLoopMode()
        return self.m_isLoopMode
    end
    function e:setLoopMode(e)
        self.m_isLoopMode = e
    end
    function e:setCounterFrame(e)
        self.m_frameNum = e
        self:_calcStepValue()
    end
    function e:setForward()
        self:_calcStepValue()
    end
    function e:setBackward()
        self:_calcStepValue()
        self:inverse()
    end
    function e:inverse()
        self.m_stepValue = self.m_stepValue * -1
    end
    function e:reset()
        self:_calcStepValue()
        self.m_value = 0
    end
    function e:isActive()
        if (self.m_value ~= 0 and self.m_value ~= 1) then
            return true
        end
        return false
    end
    function e:isStartTime()
        return (self:getValueWithOutStep() == 0)
    end
    function e:isFinished()
        if (self.m_stepValue > 0) then
            return (self.m_value >= 1)
        else
            return (self.m_value <= 0)
        end
    end
    function e:getValue()
        self:_step()
        return self:_inOutCubic(self.m_value)
    end
    function e:getValueNoEase()
        self:_step()
        return self.m_value
    end
    function e:getValueWithOutStep()
        return self.m_value
    end
    function e:_calcStepValue()
        self.m_stepValue = 1 / self.m_frameNum
    end
    function e:_step()
        if (self.m_value ~= 1 and self.m_stepValue > 0 or self.m_value ~= 0 and self.m_stepValue < 0) then
            self.m_value = self.m_value + self.m_stepValue
            if (self:isLoopMode() == true) then
                if (self.m_value >= 1 and self.m_stepValue > 0) then
                    self.m_value = 0
                end
                if (self.m_value <= 0 and self.m_stepValue < 0) then
                    self.m_value = 1
                end
            else
                self.m_value = math.min(math.max(self.m_value, 0), 1)
            end
        end
    end
    function e:_inOutCubic(n)
        n = n * 2
        if n < 1 then
            return .5 * n * n * n
        else
            n = n - 2
            return .5 * (n * n * n + 2)
        end
    end
    e:_calcStepValue()
    return e
end
function createCounterByDtTime(n)
    local e = createCounter()
    e._divNum = n or 1
    e._CLASS_TYPE = "CounterByDtTime"
    function e:setDivNum(e)
        self._divNum = e
    end
    function e:getValue(e)
        self:_step(e)
        return self:_inOutCubic(self.m_value)
    end
    function e:getValueNoEase(e)
        self:_step(e)
        return self.m_value
    end
    function e:getValueWithOutStep()
        return self.m_value
    end
    function e:_step(e)
        self.m_value = self.m_value + e / self._divNum
        if (self:isLoopMode()) then
            if (self.m_value >= 1) then
                self.m_value = 0
            end
        else
            if (self.m_value >= 1) then
                self.m_value = 1
            end
        end
    end
    return e
end
function createParticalSingle()
    local e = {}
    e._fadeInFrame_F = .1
    e._fadeOutFrame_F = .1
    e.lifeFrameNum = 60
    e.currentLifeFrame = 0
    e._lifeCounter = createCounter(e.lifeFrameNum)
    e.ox = 0
    e.oy = 0
    e.fx = 1
    e.fy = 1
    e._x = e.ox
    e._y = e.oy
    e._alpha = .5
    e.oRotAngle = 0
    e.fRotAngle = 0
    e.radius = 3
    function e:setAlpha(e)
        self._alpha = e
        return self
    end
    function e:setStartPoint(e, n)
        self._x = e
        self._y = n
        return self
    end
    function e:setOrigin(n, e)
        self.ox = n
        self.oy = e
        return self
    end
    function e:setForce(e, n)
        self.fx = e
        self.fy = n
        return self
    end
    function e:setRotAngleFromOrigin(e)
        self.oRotAngle = e
        return self
    end
    function e:setRotAngle(e)
        self.fRotAngle = e
        return self
    end
    function e:setLifeFrameNum(e)
        self._lifeCounter = {}
        self._lifeCounter = createCounter(e)
        self.lifeFrameNum = e
        return self
    end
    function e:setRadius(e)
        self.radius = e
        return self
    end
    function e:getAlpha()
        return self._alpha
    end
    function e:getOrigin()
        return self.ox, self.oy
    end
    function e:getForce()
        return self.fx, self.fy
    end
    function e:getRotAngleFromOrigin()
        return self.oRotAngle
    end
    function e:getRotAngle()
        return self.fRotAngle
    end
    function e:getLifeFrame()
        return self.lifeFrameNum
    end
    function e:getCurrentLifeFrame()
        local e = self._lifeCounter:getValueWithOutStep()
        self.currentLifeFrame = (e * self:getLifeFrame())
        return self.currentLifeFrame
    end
    function e:getRadius()
        return self.radius
    end
    function e:isFinished()
        local e = (self:getCurrentLifeFrame() >= self:getLifeFrame())
        return e
    end
    function e:updateAndDraw()
        self:_update()
        self:_draw()
    end
    function e:_init()
    end
    function e:_update()
        self.currentLifeFrame = self._lifeCounter:getValue()
        local e = self:_getFadeInOutTimeValue()
        self._x = self._x + self.fx * e
        self._y = self._y + self.fy * e
        local n, e = rotPoint(self.ox, self.oy, self._x, self._y, self.oRotAngle * e)
        self._x = n
        self._y = e
    end
    function e:_draw()
        gfx.set(1, 1, 1, self._alpha * self:_getFadeInOutTimeValue(), 1)
        local e = self.radius * self:_getFadeInOutTimeValue()
        gfx.circle(self._x - e / 2, self._y - e / 2, e, true, false)
    end
    function e:_getFadeInOutTimeValue()
        local t = self._lifeCounter:getValueWithOutStep()
        local n = 1
        if (t < self._fadeInFrame_F) then
            n = t / self._fadeInFrame_F
        elseif (t < (1 - self._fadeOutFrame_F)) then
            n = 1
        else
            local e = (t - (1 - self._fadeOutFrame_F))
            n = 1 - (e / self._fadeOutFrame_F)
            if (n < .001) then
                n = 0
            end
        end
        return n
    end
    e:_init()
    return e
end
function createParticleManager()
    local e = {}
    e._particals = {}
    e._maxPartiCalNum = 300
    e._lastAddTime = reaper.time_precise()
    e._safeAddIntervalTime = .02
    e._targetRadius = 8
    function e:setTargetRadiusSize(e)
        self._targetRadius = math.max(math.min(e, 100), 2)
    end
    function e:getTargetRadiusSize()
        return self._targetRadius
    end
    function e:getActiveParticalNum()
        return #self._particals
    end
    function e:setOriginePoint_A(e, n)
        for a, t in ipairs(self._particals) do
            t:setOrigin(e, n)
        end
    end
    function e:setMaxParticalNum(e)
        self._maxPartiCalNum = e
    end
    function e:addParticleType1(n, t, a, e, o, c)
        if (self:_checkSafeTime() == false) then
            return
        end
        local e = e or 9.75
        local r = e / 2
        local o = o or 30
        local i = o / 2
        local l = self._targetRadius
        local a = a or 5
        local c = c or 60
        for a = 1, a do
            local a = createParticalSingle()
            a:setStartPoint(n, t):setOrigin(n, t):setAlpha(.3 * math.random() + .5):setForce(
                math.random() * e - r,
                math.random() * e - r
            ):setRotAngleFromOrigin(math.rad(math.random() * o - i)):setLifeFrameNum(c * math.random() + 30):setRadius(
                l * math.random()
            )
            table.insert(self._particals, a)
        end
        self:_checkMaxParticalNum()
        self:_storeLastTime()
    end
    function e:updateAndDraw()
        for n, e in ipairs(self._particals) do
            e:updateAndDraw()
        end
        self:_checkPrticleLife()
    end
    function e:_checkPrticleLife()
        for n, e in ipairs(self._particals) do
            if (e:isFinished() == true or (e:_getFadeInOutTimeValue() <= 0 and e:getCurrentLifeFrame() > 0)) then
                table.remove(self._particals, n)
                break
            end
        end
    end
    function e:_checkMaxParticalNum()
        while (#self._particals > self._maxPartiCalNum) do
            table.remove(self._particals, 1)
        end
    end
    function e:_checkSafeTime()
        return (reaper.time_precise() - self._lastAddTime > self._safeAddIntervalTime)
    end
    function e:_storeLastTime()
        self._lastAddTime = reaper.time_precise()
    end
    return e
end
function createMatrix_4x4()
    local n = {}
    n.m = {}
    function n:translate(t, n, e)
        self:mul(self:_createTranslateMat(t, n, e))
    end
    function n:rotation(t, n, e)
        self:mul(self:_createRotationXMat(t))
        self:mul(self:_createRotationYMat(n))
        self:mul(self:_createRotationZMat(e))
    end
    function n:scale(t, n, e)
        self:mul(self:_createScaleMat(t, n, e))
    end
    function n:skew()
    end
    function n:mulMatrix(e)
        self:mul(e.m)
    end
    function n:mul(e)
        local n = self:_createIdentMat()
        n[1][1] = self.m[1][1] * e[1][1] + self.m[1][2] * e[2][1] + self.m[1][3] * e[3][1] + self.m[1][4] * e[4][1]
        n[1][2] = self.m[1][1] * e[1][2] + self.m[1][2] * e[2][2] + self.m[1][3] * e[3][2] + self.m[1][4] * e[4][2]
        n[1][3] = self.m[1][1] * e[1][3] + self.m[1][2] * e[2][3] + self.m[1][3] * e[3][3] + self.m[1][4] * e[4][3]
        n[1][4] = self.m[1][1] * e[1][4] + self.m[1][2] * e[2][4] + self.m[1][3] * e[3][4] + self.m[1][4] * e[4][4]
        n[2][1] = self.m[2][1] * e[1][1] + self.m[2][2] * e[2][1] + self.m[2][3] * e[3][1] + self.m[2][4] * e[4][1]
        n[2][2] = self.m[2][1] * e[1][2] + self.m[2][2] * e[2][2] + self.m[2][3] * e[3][2] + self.m[2][4] * e[4][2]
        n[2][3] = self.m[2][1] * e[1][3] + self.m[2][2] * e[2][3] + self.m[2][3] * e[3][3] + self.m[2][4] * e[4][3]
        n[2][4] = self.m[2][1] * e[1][4] + self.m[2][2] * e[2][4] + self.m[2][3] * e[3][4] + self.m[2][4] * e[4][4]
        n[3][1] = self.m[3][1] * e[1][1] + self.m[3][2] * e[3][1] + self.m[3][3] * e[3][1] + self.m[3][4] * e[4][1]
        n[3][2] = self.m[3][1] * e[1][2] + self.m[3][2] * e[3][2] + self.m[3][3] * e[3][2] + self.m[3][4] * e[4][2]
        n[3][3] = self.m[3][1] * e[1][3] + self.m[3][2] * e[3][3] + self.m[3][3] * e[3][3] + self.m[3][4] * e[4][3]
        n[3][4] = self.m[3][1] * e[1][4] + self.m[3][2] * e[3][4] + self.m[3][3] * e[3][4] + self.m[3][4] * e[4][4]
        n[4][1] = self.m[4][1] * e[1][1] + self.m[4][2] * e[4][1] + self.m[4][3] * e[4][1] + self.m[4][4] * e[4][1]
        n[4][2] = self.m[4][1] * e[1][2] + self.m[4][2] * e[4][2] + self.m[4][3] * e[4][2] + self.m[4][4] * e[4][2]
        n[4][3] = self.m[4][1] * e[1][3] + self.m[4][2] * e[4][3] + self.m[4][3] * e[4][3] + self.m[4][4] * e[4][3]
        n[4][4] = self.m[4][1] * e[1][4] + self.m[4][2] * e[4][4] + self.m[4][3] * e[4][4] + self.m[4][4] * e[4][4]
        self.m = n
    end
    function n:transform(t, n, e)
        local a, r, l, o
        a = self.m[1][1] * t + self.m[1][2] * n + self.m[1][3] * e + self.m[1][4]
        r = self.m[2][1] * t + self.m[2][2] * n + self.m[2][3] * e + self.m[2][4]
        l = self.m[3][1] * t + self.m[3][2] * n + self.m[3][3] * e + self.m[3][4]
        o = self.m[4][1] * t + self.m[4][2] * n + self.m[4][3] * e + self.m[4][4]
        return a, r, l, o
    end
    function n:toIdentMat()
        self.m = self:_createIdentMat()
    end
    function n:toLookAtMat(n, e, t)
        self.m = self:_createLookUpMat(n, e, t)
    end
    function n:toPerspectiveMat(r, o, t, a, n, e)
        self.m = self:_createPerspectiveMat(r, o, t, a, n, e)
    end
    function n:printMat()
        DBG(self.m[1][1], self.m[1][2], self.m[1][3], self.m[1][4])
        DBG(self.m[2][1], self.m[2][2], self.m[2][3], self.m[2][4])
        DBG(self.m[3][1], self.m[3][2], self.m[3][3], self.m[3][4])
        DBG(self.m[4][1], self.m[4][2], self.m[4][3], self.m[4][4])
    end
    function n:printMat2(e)
        DBG(e[1][1], e[1][2], e[1][3], e[1][4])
        DBG(e[2][1], e[2][2], e[2][3], e[2][4])
        DBG(e[3][1], e[3][2], e[3][3], e[3][4])
        DBG(e[4][1], e[4][2], e[4][3], e[4][4])
    end
    function n:getInvertMatrix()
        local l
        local e, e, e
        local o = 4
        local n = {table.unpack(self.m)}
        local t = self:_createIdentMat()
        local r
        for e = 1, o do
            r = 1 / n[e][e]
            for a = 1, o do
                n[e][a] = n[e][a] * r
                t[e][a] = t[e][a] * r
            end
            for a = 1, o do
                if (e ~= a) then
                    l = n[a][e]
                    for o = 1, o do
                        n[a][o] = n[a][o] - n[e][o] * l
                        t[a][o] = t[a][o] - t[e][o] * l
                    end
                end
            end
        end
        return t
    end
    function n:getInvertMatrix_C()
        local n = self:getInvertMatrix()
        local e = createMatrix_4x4()
        e:_matToMatrix_1(n)
        return e
    end
    function n:getGlMat()
        local e = {}
        e[1] = self.m[1][1]
        e[5] = self.m[1][2]
        e[9] = self.m[1][3]
        e[13] = self.m[1][4]
        e[2] = self.m[2][1]
        e[6] = self.m[2][2]
        e[10] = self.m[2][3]
        e[14] = self.m[2][4]
        e[3] = self.m[3][1]
        e[7] = self.m[3][2]
        e[11] = self.m[3][3]
        e[15] = self.m[3][4]
        e[4] = self.m[4][1]
        e[8] = self.m[4][2]
        e[12] = self.m[4][3]
        e[16] = self.m[4][4]
        return e
    end
    function n:fromGlMat(e)
        self.m = self:_createIdentMat()
        self.m[1][1] = e[1]
        self.m[1][2] = e[5]
        self.m[1][3] = e[9]
        self.m[1][4] = e[13]
        self.m[2][1] = e[2]
        self.m[2][2] = e[6]
        self.m[2][3] = e[10]
        self.m[2][4] = e[14]
        self.m[3][1] = e[3]
        self.m[3][2] = e[7]
        self.m[3][3] = e[11]
        self.m[3][4] = e[15]
        self.m[4][1] = e[4]
        self.m[4][2] = e[8]
        self.m[4][3] = e[12]
        self.m[4][4] = e[16]
        return self.m
    end
    function n:_init()
        self.m = self:_createIdentMat()
    end
    function n:_matToMatrix_1(e)
        self.m = {table.unpack(e)}
    end
    function n:_createIdentMat()
        return {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
    end
    function n:_createTranslateMat(n, t, e)
        return {{1, 0, 0, n}, {0, 1, 0, t}, {0, 0, 1, e}, {0, 0, 0, 1}}
    end
    function n:_createScaleMat(t, n, e)
        return {{t, 0, 0, 0}, {0, n, 0, 0}, {0, 0, e, 0}, {0, 0, 0, 1}}
    end
    function n:_createRotationXMat(e)
        return {{1, 0, 0, 0}, {0, math.cos(e), math.sin(e), 0}, {0, -math.sin(e), math.cos(e), 0}, {0, 0, 0, 1}}
    end
    function n:_createRotationYMat(e)
        return {{math.cos(e), 0, -math.sin(e), 0}, {0, 1, 0, 0}, {math.sin(e), 0, math.cos(e), 0}, {0, 0, 0, 1}}
    end
    function n:_createRotationZMat(e)
        return {{math.cos(e), math.sin(e), 0, 0}, {-math.sin(e), math.cos(e), 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}}
    end
    function n:_createLookUpMat(t, i, c)
        local function l(n, t)
            local e = {}
            e.x = n.x - t.x
            e.y = n.y - t.y
            e.z = n.z - t.z
            return e
        end
        local function o(e)
            return math.sqrt((e.x) * (e.x) + (e.y) * (e.y) + (e.z) * (e.z))
        end
        local function a(n)
            local e = {}
            local t = o(n)
            if (tostring(t) == "nan") then
                e.x = 0
                e.y = 0
                e.z = 0
            else
                e.x = n.x / t
                e.y = n.y / t
                e.z = n.z / t
            end
            return e
        end
        local function r(n, e)
            local t = {}
            t.x = (n.y) * (e.z) - (n.z) * (e.y)
            t.y = (n.z) * (e.x) - (n.x) * (e.z)
            t.z = (n.x) * (e.y) - (n.y) * (e.x)
            return t
        end
        local function o(n, e)
            return (n.x) * (e.x) + (n.y) * (e.y) + (n.z) * (e.z)
        end
        local e = l(i, t)
        local e = a(e)
        local n = r(c, e)
        local r = r(e, n)
        local n = a(n)
        local a = a(r)
        local r = self:_createIdentMat()
        r = {{-n.x, -n.y, -n.z, o(n, t)}, {a.x, a.y, a.z, -o(a, t)}, {-e.x, -e.y, -e.z, o(e, t)}, {0, 0, 0, 1}}
        return r
    end
    function n:_createPerspectiveMat(t, o, a, e, r, l)
        local t = 1 / math.tan(math.rad(t) / 2)
        local o = -o * t
        local i = t
        local t = e * (1 / (e - a))
        local e = e * (-a / (e - a))
        local e = {{o, 0, 0, r * t}, {0, i, 0, l * t}, {0, 0, t, 1}, {0, 0, e, 0}}
        return e
    end
    n:_init()
    return n
end
STATIC_Component_Indexer = nil
function drawString(e, t, n)
    gfx.y = t
    gfx.x = e
    gfx.drawstr(n)
end
function drawFillRectangle(e)
    gft.rect(e.x, e.y, e.w, e.h)
end
function getStringWidth(e)
    return gfx.measurestr(e)
end
function drawMultiLineText(n, a, e)
    local e = string.split(e, "\n")
    for t, e in ipairs(e) do
        local o = n + gfx.measurestr(e)
        local t = a + (t - 1) * gfx.texth * .9
        drawString(n, t, e)
    end
end
local l = 2
local a = 4
local e = 8
function drawFillGradRect(n, e, t, r)
    local o = 0
    local i = 0
    local c = 0
    local s = 0
    local _ = 0
    local d = 0
    local f = 0
    local u = 0
    if (bit32.band(r, a) == a) then
        o = (t[1] - e[1]) / n:getWidth()
        i = (t[2] - e[2]) / n:getWidth()
        c = (t[3] - e[3]) / n:getWidth()
        s = (t[4] - e[4]) / n:getWidth()
    end
    if (bit32.band(r, l) == l) then
        _ = (t[1] - e[1]) / n:getHeight()
        d = (t[2] - e[2]) / n:getHeight()
        f = (t[3] - e[3]) / n:getHeight()
        u = (t[4] - e[4]) / n:getHeight()
    end
    gfx.gradrect(n:getX(), n:getY(), n:getWidth(), n:getHeight(), e[1], e[2], e[3], e[4], o, i, c, s, _, d, f, u)
end
____currentApp___ = nil
function createApp(n, a, t)
    local e = {}
    e._lastTime = reaper.time_precise()
    e._lastMouseCap = nil
    e._lastMouseX = 0
    e._lastMouseY = 0
    e._lastMouseWheel = 0
    e.mouseWheelDt = 0
    e._childComponent = {}
    e._lastMouseLeftDown = false
    e._lastMouseRightDown = false
    e.width = a or 380
    e.height = t or 500
    e.title = n or "app"
    e.deltaTime = .1
    ____currentApp___ = e
    e._creditViewSiwtch = createSwitch()
    e._creditViewSiwtch:off()
    e._animateText_1 = createAnimateText()
    e._animateText_JA = createAnimateText()
    e._animateText_EN = createAnimateText()
    e._creditString = restorByteString(p)
    e._switchRotation = createSwitch()
    e._switchScaling = createSwitch()
    e._switchScaling:off()
    e._switchRotation:off()
    e._rotationRad = 0
    e._scaleValue = 1
    e._refleshRate = 60
    e._dtTimeForRefrleshRate = 0
    e._animCounter_Rot = createCounter(f)
    e._animCounter_Scale = createCounter(f)
    e._animCounter_Rot:setLoopMode(true)
    e._animCounter_Scale:setLoopMode(true)
    e._animValueFX_Rot = 0
    e._animValueFX_Scale = 0
    e._CLASS_TYPE = "App"
    function e:getRefreshRate()
        return self._refleshRate
    end
    function e:_getDtTimeForRefrleshRate()
        return self._dtTimeForRefrleshRate
    end
    function e:setRefreshRate(e)
        self._refleshRate = e
    end
    function e:_setDtTimeForRefrleshRate(e)
        self._dtTimeForRefrleshRate = e
    end
    function e:getAnimationMatrix()
        local t = self:getRotaionRad()
        local n = self:getScaleValue()
        local e = createMatrix_4x4()
        if (self._switchRotation:isOff() and self._switchScaling:isOff()) then
            return e
        end
        if (t == 0 and n == 1) then
            return e
        end
        e:translate(gfx.w / 2, gfx.h / 2, 0)
        e:scale(n, n, 1)
        e:rotation(0, 0, t)
        e:translate(-(gfx.w / 2), -(gfx.h / 2), 0)
        return e
    end
    function e:getRotaionRad()
        local e = 0
        if (self._switchRotation:isOn()) then
            e = self._rotationRad
        end
        return e
    end
    function e:getScaleValue()
        local e = 1
        if (self._switchScaling:isOn()) then
            e = self._scaleValue
        end
        return e
    end
    function e:getDeltaTime()
        return self.deltaTime
    end
    function e:addChildComponent(e)
        local n = table.doubleCheck(self._childComponent, e)
        if (n == false) then
            e:setBounds(0, 0, self.width, self.height)
            e:setTopLevelComponent()
            table.insert(self._childComponent, e)
        end
    end
    function e:resized()
        self.width = gfx.w
        self.height = gfx.h
        for n, e in ipairs(self._childComponent) do
            e:setBounds(0, 0, self.width, self.height)
        end
        self:_drawFillBackground()
        self:_setUpDefinedCanvas()
    end
    function e:onMouseMove(n, t)
        for a, e in ipairs(self._childComponent) do
            if (e._MouseMove ~= nil) then
                e:_MouseMove(n, t)
            end
        end
    end
    function e:onMousePress(n)
        self._creditViewSiwtch:off()
        for t, e in ipairs(self._childComponent) do
            if (e._MousePress ~= nil) then
                e:_MousePress(n)
            end
        end
    end
    function e:onMouseRelease(n)
        for t, e in ipairs(self._childComponent) do
            if (e._MouseRelease ~= nil) then
                e:_MouseRelease(n)
            end
        end
    end
    function e:onMouseWheel(n)
        for t, e in ipairs(self._childComponent) do
            if (e._MouseWheel ~= nil) then
                e:_MouseWheel(n)
            end
        end
    end
    function e:onDraw(e)
        local t = self:_getDtTimeForRefrleshRate()
        local n = self:getRefreshRate()
        self:_setDtTimeForRefrleshRate(t + e)
        if (self:_getDtTimeForRefrleshRate() >= 1 / n) then
            for t, n in ipairs(self._childComponent) do
                if (n._Draw ~= nil) then
                    n:_Draw(e)
                end
            end
            self:_setDtTimeForRefrleshRate(0)
            if (self:isCreaditVisibule() == true) then
                self:drawCreditView()
            end
        end
    end
    function e:onUpdate(n)
        for t, e in ipairs(self._childComponent) do
            if (e._Update ~= nil) then
                e:_Update(n)
            end
        end
    end
    function e:runLoop()
        self.deltaTime = reaper.time_precise() - self._lastTime
        gfx.update()
        if (self.width ~= gfx.w or self.height ~= gfx.h) then
            self:resized()
        end
        if (self._lastMouseX ~= gfx.mouse_x or self._lastMouseY ~= gfx.mouse_y) then
            self:onMouseMove(self._lastMouseX, self._lastMouseY)
        end
        gfx.set(1, 1, 1, 1)
        self:onUpdate(self.deltaTime)
        if (self._lastMouseCap ~= gfx.mouse_cap) then
            if
                (self._lastMouseCap < gfx.mouse_cap and
                    (bit32.band(gfx.mouse_cap, 1) == 1 or bit32.band(gfx.mouse_cap, 2) == 2 or
                        bit32.band(gfx.mouse_cap, 64) == 64))
             then
                self:onMousePress(gfx.mouse_cap)
            else
                self:onMouseRelease(gfx.mouse_cap)
            end
        end
        if (self._lastMouseWheel ~= gfx.mouse_wheel) then
            if (self._lastMouseWheel < gfx.mouse_wheel) then
                self.mouseWheelDt = 1
            else
                self.mouseWheelDt = -1
            end
            self:onMouseWheel(self.mouseWheelDt)
        else
            self.mouseWheelDt = 0
            gfx.mouse_wheel = 0
        end
        STATIC_Component_Indexer:drawAllOffScreen(self)
        local e = gfx.getchar()
        if (e >= 0) then
            reaper.defer(
                function()
                    self:runLoop()
                end
            )
            if (e == string.byte(C)) then
                self._creditViewSiwtch:toggle()
                if (self._creditViewSiwtch:isOn()) then
                    self._animateText_1:reset()
                    self._animateText_JA:reset()
                    self._animateText_EN:reset()
                end
            elseif (e == 27) then
                gfx.quit()
            elseif (e == string.byte(F)) then
                self._switchRotation:toggle()
                self._animCounter_Rot:reset()
            elseif (e == string.byte(P)) then
                self._switchScaling:toggle()
                self._animCounter_Scale:reset()
            end
        end
        self:_storeGfxInfo()
        if (self._switchRotation:isOn()) then
            self._animValueFX_Rot = self._animCounter_Rot:getValueNoEase()
            self._rotationRad = (math.pi * 2 * self._animValueFX_Rot)
        end
        if (self._switchScaling:isOn()) then
            self._animValueFX_Scale = self._animCounter_Scale:getValueNoEase()
            self._scaleValue = .5 + math.abs(1 * math.sin(math.rad(360 * self._animValueFX_Scale)))
        end
    end
    function e:toggleDock()
        if (gfx.dock(-1) == 1) then
            gfx.dock(0)
        else
            gfx.dock(1)
        end
    end
    function e:isDock()
        local e = false
        if (gfx.dock(-1) == 1) then
            e = true
        end
        return e
    end
    function e:changeWindowSize(e, n)
        self.width = e
        self.height = n
        gfx.quit()
        self:_init()
        self:resized()
        self:runLoop()
    end
    function e:isCreaditVisibule()
        return self._creditViewSiwtch:isOn()
    end
    function e:isDrawFxEnable()
        return (self._switchRotation:isOn() or self._switchScaling:isOn())
    end
    function e:_getCreditViewCanvasInfo()
        local e = self:_getCreditViewArea()
        e.x = 0
        e.y = 0
        return e
    end
    function e:_getCreditViewArea()
        local e = createRectangle(0, 0, gfx.w, gfx.h)
        e:reduce(e:getWidth() * .125, e:getHeight() * .125)
        return e
    end
    function e:drawCreditView()
        local e = self:getRefreshRate()
        local e = self:_getDtTimeForRefrleshRate()
        local n = self:_getCreditViewArea()
        local e = self:_getCreditViewCanvasInfo()
        gfx.setimgdim(i, e:getWidth(), e:getHeight())
        local t = gfx.dest
        gfx.dest = i
        self:_drawCreditView_To(e)
        gfx.x = n:getX()
        gfx.y = n:getY()
        gfx.dest = -1
        gfx.dest = t
        gfx.blit(i, 1, 0)
    end
    function e:_init()
        local e = {}
        e.settings = {}
        e.settings.font_size = 20
        e.settings.docker_id = 0
        gfx.init(self.title, self.width, self.height, e.settings.docker_id)
        gfx.setfont(1, "Arial", e.settings.font_size)
        gfx.clear = -1
        self:_storeGfxInfo()
        self:_drawFillBackground()
        self:_setCreditText()
        self:_setUpDefinedCanvas()
    end
    function e:_drawCreditView_To(e)
        e:fillAll({0, 0, 0, .5})
        e:reduce(3, 3)
        e:fillAll({1, 1, 1, .9})
        local e = e:getRectangle()
        e:reduce(7, 7)
        gfx.set(0, 0, 0, 1)
        gfx.setfont(10, "Calibri", 15)
        local t = self._animateText_1:getAnimedText()
        local n = self._animateText_1:getLineNum() * gfx.texth
        drawString(e:getX(), e:getY(), t)
        e:offset(0, n)
        gfx.setfont(1, "Courier New", 7)
        n = self._animateText_EN:getLineNum() * gfx.texth
        drawString(e:getX(), e:getY(), self._animateText_EN:getAnimedText())
        gfx.setfont(10, "MS PGothic", 10)
        local a, t = gfx.getfont()
        if (t ~= "Arial") then
            e:offset(0, n)
            e:offset(0, gfx.texth / 2)
            drawString(e:getX(), e:getY(), self._animateText_JA:getAnimedText())
        end
    end
    function e:_setCreditText()
        self._animateText_1:setText(self._creditString)
        self._animateText_JA:setText(restorByteString(g))
        self._animateText_EN:setText(restorByteString(m))
    end
    function e:_storeGfxInfo()
        self._lastMouseX = gfx.mouse_x
        self._lastMouseY = gfx.mouse_y
        self._lastMouseWheel = gfx.mouse_wheel
        self._lastTime = reaper.time_precise()
        self._lastMouseLeftDown = (bit32.band(gfx.mouse_cap, 1) == 1)
        self._lastMouseRightDown = (bit32.band(gfx.mouse_cap, 2) == 2)
        self._lastMouseCap = gfx.mouse_cap
        self.width = gfx.w
        self.height = gfx.h
    end
    function e:_drawFillBackground()
        gfx.dest = -1
        gfx.set(.2, .2, .2, 1)
        gfx.rect(0, 0, gfx.w, gfx.h, true)
    end
    function e:_checkLastMouseXYMoved(e, n)
        return (self._lastMouseX ~= (e or gfx.mouse_x) or self._lastMouseY ~= (n or gfx.mouse_y))
    end
    function e:_setUpDefinedCanvas()
        gfx.setimgdim(c, gfx.w, gfx.h)
        gfx.dest = c
        gfx.rect(0, 0, gfx.w, gfx.h, true)
        gfx.setimgdim(s, gfx.w, gfx.h)
        gfx.dest = s
        gfx.rect(0, 0, gfx.w, gfx.h, true)
    end
    e:_init()
    return e
end
function createAnimateText(n)
    local e = {}
    e._text = n
    e._dtCounter = createCounterByDtTime(1)
    e._dtCounter:setLoopMode(false)
    e._lastTime = 0
    e._isFirst = true
    function e:getLineNum()
        local e = string.split(self._text, "\n")
        return #e
    end
    function e:setText(e)
        self._text = e
    end
    function e:getText()
        return self._text
    end
    function e:reset()
        self._isFirst = true
        self._dtCounter:reset()
    end
    function e:getAnimedText()
        if (self._isFirst == true) then
            self._lastTime = reaper.time_precise()
            self._isFirst = false
        end
        local e = reaper.time_precise()
        local n = e - self._lastTime
        local e = getMbLengh(self._text)
        local e = math.floor(e * self._dtCounter:getValueNoEase(n * b))
        local e = mbStrSub(self._text, 0, e)
        self._lastTime = reaper.time_precise()
        return e
    end
    return e
end
function createSwitch()
    local e = {}
    e._switch_ON_OFF = true
    function e:on()
        self._switch_ON_OFF = true
    end
    function e:off()
        self._switch_ON_OFF = false
    end
    function e:toggle()
        self._switch_ON_OFF = (self._switch_ON_OFF == false) or false
    end
    function e:isOn()
        return (self._switch_ON_OFF == true)
    end
    function e:isOff()
        return (self._switch_ON_OFF == false)
    end
    function e:setSwitch(e)
        self._switch_ON_OFF = e
    end
    function e:setState(e)
        self._switch_ON_OFF = e
    end
    return e
end
function createRectangle(o, a, n, t)
    local e = {}
    e.x = o or 0
    e.y = a or 0
    e.w = n or 100
    e.h = t or 100
    e._xyTable = {}
    e._cpoint = {}
    e._lastColisionState = false
    e._distanceP1P3 = 0
    e._CLASS_TYPE = "Rectangle"
    function e:getX()
        return self.x
    end
    function e:getY()
        return self.y
    end
    function e:getX1()
        return self.x
    end
    function e:getY1()
        return self.y
    end
    function e:getX2()
        return self.x + self.w
    end
    function e:getY2()
        return self.y + self.h
    end
    function e:getWidth()
        return self.w
    end
    function e:getHeight()
        return self.h
    end
    function e:getCenterPoint()
        return self._cpoint
    end
    function e:getCX()
        return self._cpoint.x
    end
    function e:getCY()
        return self._cpoint.y
    end
    function e:getRectangle()
        return createRectangle(self.x, self.y, self.w, self.h)
    end
    function e:getXyTable()
        local e = {}
        table.insert(e, {x = self:getX1(), y = self:getY1()})
        table.insert(e, {x = self:getX2(), y = self:getY1()})
        table.insert(e, {x = self:getX2(), y = self:getY2()})
        table.insert(e, {x = self:getX1(), y = self:getY2()})
        return e
    end
    function e:setX(e)
        self.x = e
        self:_updateXyTable()
        return self
    end
    function e:setY(e)
        self.y = e
        self:_updateXyTable()
        return self
    end
    function e:setWidth(e)
        self.w = e
        self:_updateXyTable()
        return self
    end
    function e:setHeight(e)
        self.h = e
        self:_updateXyTable()
        return self
    end
    function e:setX2(e)
        self.w = e - self:getX1()
        self:_updateXyTable()
        return self
    end
    function e:setY2(e)
        self.h = e - self:getY1()
        self:_updateXyTable()
        return self
    end
    function e:setFromXYTable(e)
        self.x = e[1].x
        self.y = e[1].y
        self.w = e[3].x - self.x
        self.h = e[3].y - self.h
        self:_updateXyTable()
        return self
    end
    function e:getApplyAppMatrixPoint(n)
        if (____currentApp___ == nil) then
            return n
        end
        local a = ____currentApp___:getRotaionRad()
        local t = ____currentApp___:getScaleValue()
        if (____currentApp___._switchRotation:isOff() and ____currentApp___._switchScaling:isOff()) then
            return n
        end
        if (a == 0 and t == 1) then
            return n
        end
        local e = createMatrix_4x4()
        e:translate(gfx.w / 2, gfx.h / 2, 0)
        e:scale(1 / t, 1 / t, 1)
        e:rotation(0, 0, a)
        e:translate(-(gfx.w / 2), -(gfx.h / 2), 0)
        local n, e = e:transform(n.x, n.y, 0)
        return {x = n, y = e}
    end
    function e:setBounds(e, n, a, t)
        self.x = e
        self.y = n
        self.w = a
        self.h = t
        self:_updateXyTable()
        return self
    end
    function e:setBoundsFromRect(e)
        self.x = e.x
        self.y = e.y
        self.w = e.w
        self.h = e.h
        self:_updateXyTable()
        e:_updateXyTable()
        return self
    end
    function e:setBoundsFromRectangle(e)
        self:setBoundsFromRect(e)
    end
    function e:setBoundsFromCenterPoint(a, t, n, e)
        self.x = a - n / 2
        self.y = t - e / 2
        self.w = n or self:getWidth()
        self.h = e or self:getHeight()
        self:_updateXyTable()
        return self
    end
    function e:isContact(i, l)
        if (____currentApp___:_checkLastMouseXYMoved() == false) then
            return self._lastColisionState
        end
        local e = self:_getApplyAppDrawFXChood()
        if (e == nil) then
            e = self._xyTable
        end
        if (self:_checkDistanceColision(i, l, e) == false) then
            self._lastColisionState = false
            return false
        end
        local n = 0
        local a = nil
        local r = nil
        for t = 1, #e, 1 do
            local o = t + 1
            if (t + 1 > #e) then
                o = 1
            end
            local c = e[o].x - e[t].x
            local o = e[o].y - e[t].y
            local i = i - e[t].x
            local e = l - e[t].y
            if (c * e - i * o < 0) then
                n = n + 1
                a = 1
            else
                n = n - 1
                a = -1
            end
            if (r ~= nil and a ~= r) then
                self._lastColisionState = false
                break
            end
        end
        local t = false
        if (n <= -(#e) or n >= #e) then
            t = true
        end
        self._lastColisionState = t
        return t
    end
    function e:_getApplyAppDrawFXChood()
        if (____currentApp___ == nil) then
            return
        end
        local t = ____currentApp___:getRotaionRad()
        local n = ____currentApp___:getScaleValue()
        if (____currentApp___._switchRotation:isOff() and ____currentApp___._switchScaling:isOff()) then
            return nil
        end
        if (t == 0 and n == 1) then
            return nil
        end
        local e = createMatrix_4x4()
        e:translate(gfx.w / 2, gfx.h / 2, 0)
        e:scale(n, n, 1)
        e:rotation(0, 0, -t)
        e:translate(-(gfx.w / 2), -(gfx.h / 2), 0)
        local c, l = e:transform(self.x, self.y, 0)
        local i, r = e:transform(self.x + self.w, self.y, 0)
        local o, t = e:transform(self.x + self.w, self.y + self.h, 0)
        local n, a = e:transform(self.x, self.y + self.h, 0)
        local e = {}
        e[1] = {x = c, y = l}
        e[2] = {x = i, y = r}
        e[3] = {x = o, y = t}
        e[4] = {x = n, y = a}
        return e
    end
    function e:isColisionMouse()
        return self:isContact(gfx.mouse_x, gfx.mouse_y)
    end
    function e:isMouseColision()
        return self:isColisionMouse()
    end
    function e:reduce(n, e)
        self.x = (self.x + n)
        self.y = (self.y + e)
        self.w = (self.w - n * 2)
        self.h = (self.h - e * 2)
        self:_updateXyTable()
    end
    function e:reduce_2(n, t, e, a)
        self.x = (self.x + n)
        self.y = (self.y + e)
        self.w = (self.w - n - t)
        self.h = (self.h - e - a)
        self:_updateXyTable()
    end
    function e:reduce2(t, n, e, a)
        self:reduce_2(t, n, e, a)
    end
    function e:expand(e, n)
        self.x = self.x - e
        self.y = self.y - n
        self.w = self.w + e * 2
        self.h = self.h + n * 2
        self:_updateXyTable()
    end
    function e:resized()
    end
    function e:_updateDistance()
        self._distanceP1P3 = getManhattanDist(self.x, self.y, self.x + self.w, self.y + self.h)
        return self._distanceP1P3
    end
    function e:_updateXyTable()
        self._xyTable = {}
        local function e(e)
            e.x = math.floor(e.x + .25)
            e.y = math.floor(e.y + .25)
            e.w = math.floor(e.w + .25)
            e.h = math.floor(e.h + .25)
        end
        local function e(e)
            e.w = math.getNearOdd(e.w)
            e.h = math.getNearOdd(e.h)
        end
        self._xyTable[1] = {x = self.x, y = self.y}
        self._xyTable[2] = {x = self.x + self.w, y = self.y}
        self._xyTable[3] = {x = self.x + self.w, y = self.y + self.h}
        self._xyTable[4] = {x = self.x, y = self.y + self.h}
        self._cpoint = {x = self.x + self.w / 2, y = self.y + self.h / 2}
        self:_updateDistance()
        self:resized()
    end
    function e:_checkDistanceColision(a, o, e)
        local n = e[1].x
        local t = e[1].y
        local r = e[3].x
        local e = e[3].y
        local r = approx_distance(n, t, r, e)
        local n = approx_distance(n, t, a, o)
        local e = false
        if (n < r) then
            e = true
        end
        return e
    end
    function e:offset(n, e)
        self.x = self.x + n
        self.y = self.y + e
        self:_updateXyTable()
        return self
    end
    function e:removeFromLeft(e)
        self.x = self.x + e
        self.w = self.w - e
        self:_updateXyTable()
        return self
    end
    function e:removeFromRight(e)
        self.w = self.w - e
        self:_updateXyTable()
        return self
    end
    function e:removeFromTop(e)
        self.y = self.y + e
        self.h = self.h - e
        self:_updateXyTable()
        return self
    end
    function e:removeFromBottom(e)
        self.h = self.h - e
        self:_updateXyTable()
        return self
    end
    function e:cropFromLeft(e)
        self.x = self.x
        self.w = e
        self:_updateXyTable()
        return self
    end
    function e:cropFromRight(e)
        self.x = self:getX2() - e
        self.w = e
        self:_updateXyTable()
        return self
    end
    function e:cropFromTop(e)
        self.h = e
        self:_updateXyTable()
        return self
    end
    function e:cropFromBottom(e)
        self.y = self:getY2() - e
        self.h = e
        self:_updateXyTable()
        return self
    end
    function e:removeFromTopP(e)
        self:removeFromTop(self.h * e)
    end
    function e:removeFromBottomP(e)
        self:removeFromBottom(self.h * e)
    end
    function e:removeFromLeftP(e)
        self:removeFromLeft(self.w * relVal)
    end
    function e:removeFromRightP(e)
        self:removeFromRight(self.w * relVal)
    end
    function e:cropFromLeftP(e)
        self:cropFromLeft(self.w * e)
    end
    function e:cropFromRightP(e)
        self:cropFromRight(self.w * e)
    end
    function e:cropFromTopP(e)
        self:cropFromTop(self.h * e)
    end
    function e:cropFromBottomP(e)
        self:cropFromBottom(self.h * e)
    end
    function e:__compatibleDraw()
        gfx.rect(self.x, self.y, self.w, self.h)
    end
    function e:drawFillAll(e, a, r, i)
        local l = gfx.r
        local t = gfx.g
        local o = gfx.b
        local n = gfx.a
        if (type(e) == "table") then
            gfx.set(table.unpack(e))
        elseif (e == nil) then
            gfx.set(.1, .1, .1, 1)
        else
            gfx.set(e, a, r, i)
        end
        self:__compatibleDraw()
        gfx.set(l, t, o, n)
    end
    function e:testFill()
        local n = gfx.r
        local e = gfx.g
        local t = gfx.b
        local a = gfx.a
        gfx.set(1, 1, 1, .5)
        self:__compatibleDraw()
        gfx.set(n, e, t, a)
    end
    function e:fillAll(n, t, a, o)
        self:drawFillAll(n, t, a, o)
    end
    e:_updateXyTable()
    return e
end
function createComponentIndexer()
    local e = {}
    e.indexTable = {}
    e._CLASS_TYPE = "ComponentIndexer"
    function e:addComponent(e, n)
        if (e == nil) then
            return
        end
        if (table.doubleCheck(self.indexTable, e) == false) then
            self:_addComponentIndexerKeyString(e, n)
            e:setComponentIndexerId(#self.indexTable)
            table.insert(self.indexTable, e)
        end
    end
    function e:getComponentIndex(e)
        local n = nil
        for a, t in ipairs(self.indexTable) do
            if (t == e) then
                n = e:getComponentIndexerId()
            end
        end
        return n
    end
    function e:removeComponent(e)
        if (e == nil) then
            return
        end
        for t, n in ipairs(self.indexTable) do
            if (n == e) then
                table.remove(self.indexTable, t)
                break
            end
        end
    end
    function e:removeComponentContainCild(e)
        if (component == nil) then
            return
        end
        for n, e in ipairs(e._childComponentTable) do
            self:removeComponentContainCild(e)
        end
        self:removeComponent(component)
    end
    function e:reCreateAllOffScreen()
        for n, e in ipairs(self.indexTable) do
            e:recreateOffScreenImg()
        end
    end
    function e:drawAllOffScreen(e)
        if (DEFINE_COMPONENT_USE_OFFSCREEN) then
            gfx.x = 0
            gfx.y = 0
            gfx.setimgdim(r, gfx.w, gfx.h)
            gfx.dest = r
        else
            gfx.dest = -1
        end
        local n = e:getDeltaTime()
        e:onDraw(n)
        if (DEFINE_COMPONENT_USE_OFFSCREEN) then
            for n, e in ipairs(self.indexTable) do
                e:_blitOffsetScreenToFrameBuffer(r)
            end
            gfx.dest = -1
            gfx.set(1, 1, 1, 1)
            local n = e:getScaleValue()
            gfx.x = -(gfx.w / 2) * n + (gfx.w / 2)
            gfx.y = -(gfx.h / 2) * n + (gfx.h / 2)
            if (e:isDrawFxEnable() == true) then
                gfx.rect(0, 0, gfx.w, gfx.h, true)
                gfx.blit(c, e:getScaleValue(), e:getRotaionRad())
                gfx.blit(d, e:getScaleValue(), e:getRotaionRad())
            end
            gfx.x = -(gfx.w / 2) * n + (gfx.w / 2)
            gfx.y = -(gfx.h / 2) * n + (gfx.h / 2)
            gfx.blit(r, e:getScaleValue(), e:getRotaionRad())
            gfx.setimgdim(d, gfx.w, gfx.h)
            gfx.x = 0
            gfx.y = 0
            gfx.dest = d
            gfx.blit(r, 1, 0)
        else
        end
    end
    function e:clearFramBufferFill(e)
        gfx.dest = -1
        gfx.set(0, 0, 0, 1)
        gfx.rect(0, 0, gfx.w, gfx.h)
    end
    function e:_addComponentIndexerKeyString(n, e)
        local e = e or ""
        n._COMPONENT_INDEXER_KEYSTRING = e
    end
    function e:_checkComponentIndexerKeyString(e, n)
        return (e._COMPONENT_INDEXER_KEYSTRING == n or e._COMPONENT_INDEXER_KEYSTRING == "")
    end
    return e
end
STATIC_Component_Indexer = createComponentIndexer()
function createOffScreenInfo(n)
    local e = n:getRectangle()
    if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN) then
        e:setX(0)
        e:setY(0)
    end
    e._component_p = n
    e._CLASS_TYPE = "OffsetScreenInfo"
    function e:getComponent()
        return self._component_p
    end
    function e:getComponentX()
        return self._component_p:getX()
    end
    function e:getComponentY()
        return self._component_p:getY()
    end
    function e:getComponentX2()
        return self._component_p:getX2()
    end
    function e:getComponentY2()
        return self._component_p:getY2()
    end
    function e:getComponentCX()
        return self._component_p:getCX()
    end
    function e:getComponentCY()
        return self._component_p:getCY()
    end
    function e:getX_fromP()
        return self:getX_fromParrentComp()
    end
    function e:getY_fromP()
        return self:getY_fromParrentComp()
    end
    function e:getX_fromParrentComp()
        local e = self:_getValue_from_ParrentComp(self._component_p:getX(), false)
        if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN ~= true) then
            e = 0
        end
        return e
    end
    function e:getY_fromParrentComp()
        local e = self:_getValue_from_ParrentComp(self._component_p:getY(), true)
        if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN ~= true) then
            e = 0
        end
        return e
    end
    function e:getX2_fromParrentComp()
        local e = self:_getValue_from_ParrentComp(self._component_p:getX2(), false)
        return e
    end
    function e:getY2_fromParrentComp()
        local e = self:_getValue_from_ParrentComp(self._component_p:getY2(), true)
        return e
    end
    function e:getCX_fromParrentComp()
        local e = self:_getValue_from_ParrentComp(self._component_p:getCX(), false)
        if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN ~= true) then
            e = self._component_p:getCenterPoint().x
        end
        return e
    end
    function e:getCY_fromParrentComp()
        local e = self:_getValue_from_ParrentComp(self._component_p:getCY(), true)
        if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN ~= true) then
            e = self._component_p:getCenterPoint().y
        end
        return e
    end
    function e:getCP_fromParrentComp()
        local n = self:getCY_fromParrentComp()
        local e = self:getCX_fromParrentComp()
        return {x = e, y = n}
    end
    function e:drawFillAll(e, n, t, o)
        local a = gfx.r
        local l = gfx.g
        local r = gfx.b
        local i = gfx.a
        local c = self._component_p:getComponentAlpha()
        if (type(e) == "table") then
            gfx.set(table.unpack(e))
        elseif (e == nil) then
            gfx.set(.1, .1, .1, 1)
        else
            gfx.set(e, n, t, o)
        end
        self:__compatibleDraw()
        gfx.set(a, l, r, i * c)
    end
    function e:fillAll(t, a, n, e)
        self:drawFillAll(t, a, n, e)
    end
    function e:_getValue_from_ParrentComp(o, r)
        local e = self._component_p:getParrent()
        local a = 0
        local n = 0
        while (e ~= nil) do
            local t = e:getX()
            if (r) then
                t = e:getY()
            end
            n = n + t
            e = e:getParrent()
        end
        a = o - n
        return a
    end
    return e
end
function createComponent(n, e, t, a, o)
    local e = mergeClass(createRectangle(e, t, a, o), createSwitch())
    e.name = n or ""
    e._childComponentTable = {}
    e._parentComponent = nil
    e._isMousePressing = false
    e._fontName = "Courier New bold"
    e._fontSize = 20
    e.isMouseLeftDown = false
    e.isMouseRightDown = false
    e.isMouseMiddleDown = false
    e.isStartInMouseDown = false
    e.isControlKeyDown = false
    e.isShiftKeyDown = false
    e.isAltKeyDown = false
    e._isNeedRedraw = true
    e.componentIndexerId = -1
    e._storeDestImage = -1
    e._isTopLevelComponent = false
    e._isLastColisionMouse = false
    e._OffScreenCanvasRect = nil
    e._propertyTable = {}
    e._componentAlpha = 1
    e._colors = {}
    e._colors["background"] = {.2, .2, .2, 1}
    e._colors["white"] = {1, 1, 1, 1}
    e._colors["black"] = {0, 0, 0, 1}
    e._colors["blue"] = {0, 0, 1, 1}
    e._colors["red"] = {1, 0, 0, 1}
    e._colors["green"] = {0, 1, 0, 1}
    e._colors["yellow"] = {1, 1, 0, 1}
    e._colors["darkorchid"] = {153 / 255, 50 / 255, 204 / 255, 1}
    e._colors["darkred"] = {139 / 255, 0 / 255, 0 / 255, 1}
    e._colors["darksalmon"] = {233 / 255, 150 / 255, 122 / 255, 1}
    e._colors["darkseagreen"] = {143 / 255, 188 / 255, 143 / 255, 1}
    e._colors["darkslateblue"] = {72 / 255, 61 / 255, 139 / 255, 1}
    e._colors["darkslategray"] = {47 / 255, 79 / 255, 79 / 255, 1}
    e._colors["darkturquoise"] = {0 / 255, 206 / 255, 209 / 255, 1}
    e._colors["bisque"] = {255 / 255, 228 / 255, 196 / 255, 1}
    e._colors["maroon"] = {128 / 255, 0 / 255, 0 / 255, 1}
    e._CLASS_TYPE = "Component"
    function e:on()
        self:setActive(true)
    end
    function e:off()
        self:setActive(false)
    end
    function e:toggle()
        self:setActive((self:isOn() == false))
    end
    function e:setSwitch(e)
        self:setActive(e)
    end
    function e:getMousePoint()
        return self:getApplyAppMatrixPoint({x = gfx.mouse_x, y = gfx.mouse_y})
    end
    function e:setActive(e)
        self._switch_ON_OFF = e
        for t, n in ipairs(self._childComponentTable) do
            n:setActive(e)
        end
    end
    function e:isActive()
        return self:isOn()
    end
    function e:addProperty(e, n)
        self._propertyTable[e] = n
    end
    function e:getProperty(e)
        return self._propertyTable[e]
    end
    function e:setTopLevelComponent()
        self._isTopLevelComponent = true
    end
    function e:setComponentIndexerId(e)
        self.componentIndexerId = e
    end
    function e:isTopLevelComponent()
        return self._isTopLevelComponent
    end
    function e:getComponentIndexerId()
        return math.floor(self.componentIndexerId)
    end
    function e:setComponentAlpha(e)
        self._componentAlpha = e
    end
    function e:getComponentAlpha()
        local e = self._componentAlpha
        if (self:getParrent() ~= nil) then
            e = e * self:getParrent():getComponentAlpha()
        end
        return e
    end
    function e:storeColor(e, n)
        self._colors[e] = nil
        self._colors[e] = n
    end
    function e:getColor(e)
        local n = self:getComponentAlpha()
        if (self._colors[e] == nil) then
            return 1, 1, 1, 1 * n
        end
        local o = self._colors[e][1] or 1
        local a = self._colors[e][2] or 1
        local t = self._colors[e][3] or 1
        local e = self._colors[e][4] or 1
        e = e * n
        return o, a, t, e
    end
    function e:getColorAsTable(e)
        local e, a, t, n = self:getColor(e)
        return {e, a, t, n}
    end
    function e:setFont(e, n)
        if (e ~= "" and e ~= nil) then
            self._fontName = e
        end
        self._fontSize = n
    end
    function e:getName()
        return self.name
    end
    function e:setName(e)
        self.name = e
    end
    function e:getParrent()
        return self._parentComponent
    end
    function e:setParrent(e)
        self._parentComponent = e
    end
    function e:addChildComponent(e)
        if (e == nil) then
            return
        end
        local n = table.doubleCheck(self._childComponentTable, e)
        if (n == false) then
            e._parentComponent = self
            table.insert(self._childComponentTable, e)
            e:on()
            e:_createOffsetScreenCanvasRect()
            self:needRedraw(true, true)
        else
            DBG(self.name)
            DBG("cant add component." .. e.name .. "// check same component.")
        end
    end
    function e:removeChildComponent(n)
        if (n == nil) then
            return
        end
        for t, e in ipairs(self._childComponentTable) do
            if (e == n) then
                e:off()
                e._parentComponent = nil
                table.remove(self._childComponentTable, t)
                break
            end
        end
    end
    function e:getFitFontSize(e)
        local e = e or self.name
        local e = #e + 1
        local e = self.w / e * 1.8
        local e = math.max(math.min(e, self.h), 20)
        return e
    end
    function e:needRedraw(n, e)
        self._isNeedRedraw = true
        local n = n or false
        if ((e == true) or (self:isTopLevelComponent() == false and n == true)) then
            for t, n in ipairs(self._childComponentTable) do
                n:needRedraw(true, e)
            end
        end
    end
    function e:isNeedRedraw()
        if (DEFINE_COMPONENT_USE_OFFSCREEN ~= true) then
            return true
        else
            return ((DEFINE_COMPONENT_USE_EACH_OFFSCREEN ~= true) or
                (DEFINE_COMPONENT_USE_EACH_OFFSCREEN == true and self._isNeedRedraw == true))
        end
        return false
    end
    function e:resized()
        self:onResized()
        self:needRedraw(true)
        for n, e in ipairs(self._childComponentTable) do
            e:resized()
        end
        self:_checkOffsetScreenCanvasSize()
        if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN ~= true) then
            self:_createOffsetScreenCanvasRect()
        end
    end
    function e:_MouseMove(n, e)
        self:onMouseMove(n, e)
        local t = self:isColisionMouse()
        if (t == true) then
            self:needRedraw()
        end
        for a, t in ipairs(self._childComponentTable) do
            t:_MouseMove(n, e)
        end
        if (self._isLastColisionMouse ~= t) then
            if (t == true) then
                self:onMouseEnter(n, e)
                self:needRedraw()
            else
                self:onMouseLeave(n, e)
                self:needRedraw()
            end
        end
        self._isLastColisionMouse = t
    end
    function e:_MousePress(n)
        if (self:isColisionMouse()) then
            self._isMousePressing = true
            self.isMouseLeftDown = (bit32.band(gfx.mouse_cap, 1) == 1)
            self.isMouseRightDown = (bit32.band(gfx.mouse_cap, 2) == 2)
            self.isMouseMiddleDown = (bit32.band(gfx.mouse_cap, 64) == 64)
            self.isStartInMouseDown = true
            self.isControlKeyDown = (bit32.band(gfx.mouse_cap, 4) == 4)
            self.isShiftKeyDown = (bit32.band(gfx.mouse_cap, 8) == 8)
            self.isAltKeyDown = (bit32.band(gfx.mouse_cap, 16) == 16)
            self:needRedraw()
        end
        self:onMousePress(n)
        for t, e in ipairs(self._childComponentTable) do
            if (e:isColisionMouse()) then
                e._isMousePressing = true
            end
            e:_MousePress(n)
        end
    end
    function e:_MouseRelease(e)
        if
            (self._isMousePressing == true and (bit32.band(gfx.mouse_cap, 1) ~= 1) and
                (bit32.band(gfx.mouse_cap, 2) ~= 2))
         then
            self._isMousePressing = false
        end
        self:onMouseRelease(e)
        if (self.isStartInMouseDown == true) then
            self:needRedraw()
        end
        for t, n in ipairs(self._childComponentTable) do
            n:_MouseRelease(e)
        end
        self.isMouseLeftDown = (bit32.band(gfx.mouse_cap, 1) == 1)
        self.isMouseRightDown = (bit32.band(gfx.mouse_cap, 2) == 2)
        self.isMouseMiddleDown = (bit32.band(gfx.mouse_cap, 64) == 64)
        self.isStartInMouseDown = false
        self.isControlKeyDown = (bit32.band(gfx.mouse_cap, 4) == 4)
        self.isShiftKeyDown = (bit32.band(gfx.mouse_cap, 8) == 8)
        self.isAltKeyDown = (bit32.band(gfx.mouse_cap, 16) == 16)
    end
    function e:_MouseWheel(e)
        self:onMouseWheel(e)
        for t, n in ipairs(self._childComponentTable) do
            n:_MouseWheel(e)
        end
        if (self:isColisionMouse()) then
            self:needRedraw()
        end
    end
    function e:_Draw(n)
        if (self:isOff()) then
            return
        end
        if (self:isNeedRedraw() == true) then
            gfx.set(1, 1, 1, 1 * self._componentAlpha)
            gfx.setfont(1, self._fontName, self._fontSize)
            local e = self:getOffScreenCanvasRect()
            self:_enterOffScreenCanvas()
            self:onDraw(n, e)
            self:_leaveOffScreenCanvas()
        end
        for t, e in ipairs(self._childComponentTable) do
            gfx.set(1, 1, 1, 1 * self._componentAlpha)
            gfx.setfont(1, e._fontName, e._fontSize)
            e:_Draw(n)
        end
        if (self:isNeedRedraw() == true) then
            gfx.setfont(1, self._fontName, self._fontSize)
            local e = self:getOffScreenCanvasRect()
            self:_enterOffScreenCanvas()
            self:onDraw2(n, e)
            self:_leaveOffScreenCanvas()
            self._isNeedRedraw = false
        end
        gfx.set(1, 1, 1, 1 * self._componentAlpha)
    end
    function e:_Update(e)
        self:onUpdate(e)
        for t, n in ipairs(self._childComponentTable) do
            n:_Update(e)
        end
    end
    function e:_isMouseDragging()
        return self._isMousePressing
    end
    function e:onResized()
    end
    function e:onMouseEnter(e, e)
    end
    function e:onMouseMove(e, e)
    end
    function e:onMouseLeave(e, e)
    end
    function e:onMousePress(e)
    end
    function e:onMouseRelease(e)
    end
    function e:onMouseWheel(e)
    end
    function e:onUpdate(e)
    end
    function e:onDraw(e, e)
    end
    function e:onDraw2(e, e)
    end
    function e:onUpdate2(e)
    end
    function e:getOffScreenCanvasRect()
        return self._OffScreenCanvasRect
    end
    function e:getOffScreenCanvas()
        return self:getOffScreenCanvasRect()
    end
    function e:getOffScreenCanvasInfo()
        return self._OffScreenCanvasRect
    end
    function e:recreateOffScreenImg()
        gfx.setimgdim(self:_getOffScreenCanvasID(), 0, 0)
        gfx.setimgdim(self:_getOffScreenCanvasID(), self.w, self.h)
        self:_createOffsetScreenCanvasRect()
        self:needRedraw()
    end
    function e:_init_()
        STATIC_Component_Indexer:addComponent(self)
        self:_createOffsetScreenCanvasRect()
    end
    function e:_getOffScreenCanvasID()
        local e = -1
        if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN == true) then
            e = self:getComponentIndexerId()
        end
        return e
    end
    function e:_createOffsetScreenCanvasRect()
        self._OffScreenCanvasRect = {}
        self._OffScreenCanvasRect = createOffScreenInfo(self)
    end
    function e:_enterOffScreenCanvas()
        if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN == false) then
            return
        end
        self._storeDestImage = gfx.dest
        gfx.dest = self:_getOffScreenCanvasID()
        self:_checkOffsetScreenCanvasSize()
    end
    function e:_leaveOffScreenCanvas()
        if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN == false) then
            return
        end
        gfx.dest = self._storeDestImage
    end
    function e:_checkOffsetScreenCanvasSize()
        if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN == false) then
            return
        end
        local e, n = gfx.getimgdim(self:_getOffScreenCanvasID())
        if (e ~= self.w or n ~= self.h) then
            gfx.setimgdim(self:_getOffScreenCanvasID(), self.w, self.h)
            self._OffScreenCanvasRect:setWidth(self.w)
            self._OffScreenCanvasRect:setHeight(self.h)
        end
    end
    function e:_blitOffsetScreenToFrameBuffer(n)
        if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN == false) then
            return
        end
        local n = n or -1
        if (self:isOn() == true) then
            gfx.dest = n
            local e = self:getOffScreenCanvasRect()
            gfx.blit(self:_getOffScreenCanvasID(), 1, 0, 0, 0, e.w, e.h, self.x, self.y, self.w, self.h, 0, 0)
        end
    end
    e:_init_()
    return e
end
function createButton(n, e, a, o, t)
    local e = createComponent(n, e, a, o, t)
    e._mouseClickFuncTable = {}
    e._mouseWheelFuncTable = {}
    e._mouseEnterFuncTable = {}
    e._mouseLeaveFuncTable = {}
    e._isAutoFontSizeMode = false
    e:storeColor("text", {0, 0, 0, 1})
    e:storeColor("background_offMouse", {1, 1, 1, 1})
    e:storeColor("background_onMouse", {0, 1, 1, 1})
    e._CLASS_TYPE = "Button"
    function e:randomOnMouseColor()
        local e = math.floor(360 * math.random())
        local e, t, n = HSVToRGB(e, .65, 1)
        e, t, n = e / 255, t / 255, n / 255
        self:storeColor("background_onMouse", {e, t, n, 1})
    end
    function e:randomOffMouseColor()
        local e = math.floor(360 * math.random())
        local n, e, t = HSVToRGB(e, .65, 1)
        n, e, t = n / 255, e / 255, t / 255
        self:storeColor("background_offMouse", {n, e, t, 1})
    end
    function e:isAutoFontSizeMode()
        return self._isAutoFontSizeMode
    end
    function e:setAutoFontSizeMode(e)
        self._isAutoFontSizeMode = e
    end
    function e:addMouseReleaseFunction(e)
        if (type(e) ~= "function") then
            return
        end
        local n = table.doubleCheck(self._mouseClickFuncTable, e)
        if (n == false) then
            table.insert(self._mouseClickFuncTable, e)
        end
    end
    function e:addMouseWheelFunction(e)
        if (type(e) ~= "function") then
            return
        end
        local n = table.doubleCheck(self._mouseWheelFuncTable, e)
        if (n == false) then
            table.insert(self._mouseWheelFuncTable, e)
        end
    end
    function e:addMouseEnterFunction(e)
        if (type(e) ~= "function") then
            return
        end
        local n = table.doubleCheck(self._mouseEnterFuncTable, e)
        if (n == false) then
            table.insert(self._mouseEnterFuncTable, e)
        end
    end
    function e:addMouseLeaveFunction(e)
        if (type(e) ~= "function") then
            return
        end
        local n = table.doubleCheck(self._mouseLeaveFuncTable, e)
        if (n == false) then
            table.insert(self._mouseLeaveFuncTable, e)
        end
    end
    function e:onMouseLeave(t, n)
        for a, e in ipairs(self._mouseLeaveFuncTable) do
            if (type(e) == "function") then
                e(self, t, n)
            end
        end
    end
    function e:onMouseEnter(t, n)
        for a, e in ipairs(self._mouseEnterFuncTable) do
            if (type(e) == "function") then
                e(self, t, n)
            end
        end
    end
    function e:onMouseRelease(n)
        if (self:isColisionMouse() and self.isStartInMouseDown == true) then
            for t, e in ipairs(self._mouseClickFuncTable) do
                if (type(e) == "function") then
                    e(self, n)
                end
            end
        end
    end
    function e:onDraw(e, t)
        gfx.mode = 0
        if (self:isColisionMouse()) then
            gfx.set(self:getColor("background_onMouse"))
        else
            gfx.set(self:getColor("background_offMouse"))
        end
        local e = t
        gfx.rect(e.x, e.y, e.w, e.h, true)
        local a = e:getCenterPoint()
        local o = #self.name
        local n = self._fontSize
        if (self:isAutoFontSizeMode()) then
            local e = e.w / o
            n = math.min(e, self._fontSize)
        end
        gfx.set(self:getColor("text"))
        gfx.setfont(1, self._fontName, n)
        local n = gfx.measurestr(self.name)
        local e = self.name
        while (n > t.w) do
            e = string.sub(e, 1, #e - 1)
            n = gfx.measurestr(e)
        end
        gfx.x = a.x - n / 2
        gfx.y = a.y - gfx.texth / 2
        gfx.drawstr(e)
    end
    function e:onMouseWheel(n)
        if (self:isColisionMouse()) then
            for t, e in ipairs(self._mouseWheelFuncTable) do
                if (type(e) == "function") then
                    e(self, n)
                end
            end
        end
    end
    return e
end
function createTabComponent(e)
    local e = createComponent(e)
    e._nextComponentKey = ""
    e._currentComponentKey = ""
    e._components = {}
    e._childTabComponents = {}
    e._buttons = {}
    e._keyStringList = {}
    e._currentKeyStringIdx = 0
    e._menuButtonPosition = 0
    e:storeColor("currentTabButton_background", {.5, .5, 1, 1})
    e:storeColor("tabButton_backGround", {1, 1, 1, 1})
    e:storeColor("tabButton_backGround_onMouse", {0, 1, 1, 1})
    e._buttonArea = createRectangle()
    e._buttonMargin = {3, 3, 3, 3}
    e._isFadeMode = false
    e._animCounter = createCounter(15)
    e._buttonAreaMaxHeight = 50
    e._buttonAreaMinHeight = 10
    e._CLASS_TYPE = "TabComponent"
    function e:setMenuButtonPosition(e)
        self._menuButtonPosition = math.floor(e)
    end
    function e:getMenuButtonPosition()
        return self._menuButtonPosition
    end
    function e:setButtonAreaMaxMinHeight(n, e)
        self._buttonAreaMaxHeight = n
        self._buttonAreaMinHeight = e
    end
    function e:setFadeMode(e)
        self._isFadeMode = e
        for t, n in pairs(self._childTabComponents) do
            n._isFadeMode = e
        end
    end
    function e:setButtonMargin(a, t, e, n)
        self._buttonMargin = {a, t, e, n}
    end
    function e:getTabCount()
        local e = 0
        for n, n in pairs(self._components) do
            e = e + 1
        end
        return e
    end
    function e:getCurrentTabComponent()
        return self._components[self._nextComponentKey] or self._components[self._currentComponentKey]
    end
    function e:getTabComponentFromKeyString(e)
        return self._components[e]
    end
    function e:addTab(n, e)
        self._components[n] = e
        self:_addButton(n)
        self:_addKeyToKeyStringList(n)
        self:_resizeButtonComp()
        self:_resizeCompInTabed(e)
        if (e._CLASS_TYPE == "TabComponent") then
            local n = table.doubleCheck(self._childTabComponents, e)
            if (n == false) then
                table.insert(self._childTabComponents, e)
            end
        end
    end
    function e:removeTab(e)
        self._components[e] = nil
        self:_removeKeyFromKeyStringList(e)
        self:_removeButton(e)
        self:_resizeButtonComp()
        for n, t in ipairs(self._childTabComponents) do
            if (t._keyStr == e) then
                table.remove(self._childTabComponents, n)
                break
            end
        end
    end
    function e:changeTab(e)
        if
            ((self._animCounter:isFinished() == true or self._animCounter:isStartTime() == true) and
                self._nextComponentKey ~= e and
                self._currentComponentKey == self._nextComponentKey)
         then
            self._nextComponentKey = e
            self._animCounter:reset()
            self:_resizeCompInTabed(self._components[e])
            self:_buttonsRedraw()
        end
    end
    function e:onUpdate(e)
        if (self._isFadeMode == true) then
            self:_checkCurrentTabChangedWithFade()
        else
            self:_checkCurrentTabChanged()
        end
    end
    function e:onResized()
        self:_resizeButtonComp()
        self:_resizeCompInTabed(self._components[self._nextComponentKey])
        self:_resizeCompInTabed(self._components[self._currentComponentKey])
    end
    function e:onDraw(n, e)
        self:_syncButtonColor()
        local e = metaTableCopy(e)
        e:setBoundsFromRect(self._buttonArea)
        e:fillAll(self:getColor("background"))
    end
    function e:onMouseWheel(e)
        if (self._buttonArea:isColisionMouse()) then
            local e = self._currentKeyStringIdx + e
            if (e <= 0) then
                e = #self._keyStringList
            end
            if (e > #self._keyStringList) then
                e = 1
            end
            local e = self._keyStringList[e]
            self:changeTab(e)
        end
    end
    function e:_init()
    end
    function e:_checkCurrentTabChanged()
        if (self._currentComponentKey == self._nextComponentKey) then
            return
        end
        local n = self._components[self._currentComponentKey]
        local e = self._components[self._nextComponentKey]
        if (e == nil) then
            return
        end
        self:_syncButtonColor()
        self:removeChildComponent(n)
        self:addChildComponent(e)
        self:_resizeCompInTabed(e)
        self._currentComponentKey = self._nextComponentKey
        self._currentKeyStringIdx = self:_getIndexFromKeyStringIndex(self._nextComponentKey)
    end
    function e:_checkCurrentTabChangedWithFade()
        local n = self._components[self._currentComponentKey]
        local e = self._components[self._nextComponentKey]
        if (e == nil) then
            local e = self._animCounter:getValue()
            n:setComponentAlpha(e)
            return
        end
        if (self._currentComponentKey ~= self._nextComponentKey and self._animCounter:isStartTime() == true) then
            self:addChildComponent(e)
            self:_resizeCompInTabed(e)
        end
        self:needRedraw(true, true)
        if (self._animCounter:isFinished() == true and self._currentComponentKey ~= self._nextComponentKey) then
            self:removeChildComponent(n)
            self._currentKeyStringIdx = self:_getIndexFromKeyStringIndex(self._nextComponentKey)
            self._currentComponentKey = self._nextComponentKey
            return
        end
        if (self._animCounter:isFinished() == true) then
            return
        end
        local t = self._animCounter:getValue()
        if (n ~= nil) then
            e:setComponentAlpha(t)
        else
            e:setComponentAlpha(1)
            e:needRedraw(true, true)
        end
        self:_syncButtonColor()
    end
    function e:_buttonsRedraw()
        for n, e in pairs(self._buttons) do
            e:needRedraw(true, true)
        end
    end
    function e:_addButton(e)
        local n = createButton(e)
        n:addMouseReleaseFunction(
            function(n, n)
                self:changeTab(e)
            end
        )
        self._buttons[e] = n
        self:addChildComponent(self._buttons[e])
    end
    function e:_removeButton(e)
        self:removeChildComponent(self._buttons[e])
        self._buttons[e] = nil
    end
    function e:_getButtonAreaHeight()
        local n = self._buttonAreaMaxHeight
        local e = self._buttonAreaMinHeight
        return math.max(math.min(self.h / 10, n), e)
    end
    function e:_resizeCompInTabed(n)
        if (n == nil) then
            return
        end
        local t = self:_getButtonAreaHeight()
        local e = createRectangle()
        local a = self:getMenuButtonPosition()
        if (a == 0) then
            e.x = self.x
            e.y = self.y + t
            e.w = self.w
            e.h = self.h - t
        elseif (a == 1) then
            e.x = self.x
            e.y = self.y
            e.w = self.w
            e.h = self.h - t
        end
        local t = 3
        local t = 3
        n:setBoundsFromRect(e)
        n._parentComponent = self
    end
    function e:_resizeButtonComp()
        self._buttonArea = self:getRectangle()
        self._buttonArea:setHeight(self:_getButtonAreaHeight())
        local r = self._buttonMargin[1]
        local l = self._buttonMargin[2]
        local o = self._buttonMargin[3]
        local a = self._buttonMargin[4]
        local n = self:getTabCount()
        local e = createRectangle()
        local t = self:getMenuButtonPosition()
        if (t == 0) then
            self._buttonArea:setY(self.y)
            e.x = self.x
            e.y = self.y
            e.w = self.w / n
            e.h = self._buttonArea:getHeight()
        elseif (t == 1) then
            self._buttonArea:setY(self.y + self.h - self._buttonArea:getHeight())
            e.x = self.x
            e.y = self.y + self.h - self._buttonArea:getHeight()
            e.w = self.w / n
            e.h = self._buttonArea:getHeight()
        end
        for i, t in ipairs(self._keyStringList) do
            local t = self._buttons[t]
            t:setBoundsFromRect(e)
            if (n == i) then
                t:reduce_2(r, l, o, a)
            else
                t:reduce_2(r, 0, o, a)
            end
            e.x = e.x + e.w
        end
    end
    function e:_syncButtonColor()
        local t = self:getColorAsTable("currentTabButton_background")
        local o = self:getColorAsTable("tabButton_backGround")
        local a = self:getColorAsTable("tabButton_backGround_onMouse")
        local e = self._buttons[self._nextComponentKey]
        if (e ~= nil) then
            local n = self._buttons[self._currentComponentKey]
            if (n ~= nil) then
                n:storeColor("background_offMouse", o)
                n:storeColor("background_onMouse", a)
            end
            e:storeColor("background_offMouse", t)
            e:storeColor("background_onMouse", t)
        end
        self:needRedraw()
    end
    function e:_addKeyToKeyStringList(e)
        local n = table.doubleCheck(self._keyStringList, e)
        if (n == false) then
            table.insert(self._keyStringList, e)
        end
    end
    function e:_removeKeyFromKeyStringList(e)
        for n, t in ipairs(self._keyStringList) do
            if (t == e) then
                table.remove(self._keyStringList, n)
                break
            end
        end
    end
    function e:_getIndexFromKeyStringIndex(n)
        local e = 1
        for a, t in ipairs(self._keyStringList) do
            if (t == n) then
                e = a
                break
            end
        end
        return e
    end
    return e
end
function createSlider(n, a, o, e, t)
    local e = createComponent(n, a, o, e, t)
    e.value = .5
    e._valueChangeFuncTable = {}
    e.label = n .. ":"
    e._meterValueRect = createRectangle()
    e.maxValue = 1
    e.minValue = 0
    e:storeColor("text", {0, 0, 0, 1})
    e:storeColor("background", {1, 1, 1, 1})
    e:storeColor("background_onMouse", {0, 1, 1, 1})
    e:storeColor("meter_value", {1, .2, .2, 1})
    e._CLASS_TYPE = "Slider"
    e.meterType = 1
    function e:addOnValueChangeFunction(e)
        if (type(e) ~= "function") then
            return
        end
        local n = table.doubleCheck(self._valueChangeFuncTable, e)
        if (n == false) then
            table.insert(self._valueChangeFuncTable, e)
        end
    end
    function e:setMaxMinValue(e, n)
        self.maxValue = e
        self.minValue = n
    end
    function e:getValue()
        return self.value
    end
    function e:setValue(n, e)
        self.value = n
        local e = e or true
        if (self.value > self.maxValue) then
            self.value = self.maxValue
        end
        if (self.value < self.minValue) then
            self.value = self.minValue
        end
        if (e == true) then
            for n, e in ipairs(self._valueChangeFuncTable) do
                e(self)
            end
        end
        self:_updateMeterValueRect()
        self:needRedraw()
    end
    function e:setMeterType(e)
        self.meterType = e
    end
    function e:onResized()
        self:_updateMeterValueRect()
    end
    function e:onMouseMove(e, n)
        if (self:_isMouseDragging()) then
            local e = self:_xyToValue(e, n)
            self:setValue(e)
        end
    end
    function e:onMouseWheel(a)
        if (self:isColisionMouse()) then
            local t = self:_xyToValue(gfx.mouse_x, gfx.mouse_y)
            local e = self:getValue()
            local n = 1
            if (t < e) then
                n = -1
            end
            e = e + (t - e) / 40 * a * n
            self:setValue(e)
        end
    end
    function e:onDraw(n, e)
        self:_updateMeterValueRect()
        self:_drawBackGround(e)
        if (self:isHorizontaleMeter()) then
            self:_drawHorizontalMeter(e)
        elseif (self:isHorizontalCenterMeter(e)) then
            self:_drawHorizontalCenterMeter(e)
        end
        self:_drawValueText(e)
    end
    function e:valueToText()
        return string.format("%0.2f", self.value)
    end
    function e:setLabel(e)
        self.label = e
        self:needRedraw()
    end
    function e:isHorizontaleMeter()
        return (bit32.band(self.meterType, 1) ~= 0)
    end
    function e:isHorizontalCenterMeter()
        return (bit32.band(self.meterType, 2) ~= 0)
    end
    function e:_updateMeterValueRect()
        self._meterValueRect = metaTableCopy(self:getOffScreenCanvasRect())
        self._meterValueRect:reduce(2, 2)
        if (self:isHorizontaleMeter()) then
            self._meterValueRect.w = self._meterValueRect.w * self.value
        elseif (self:isHorizontalCenterMeter()) then
            local e = 10
            local n = self._meterValueRect.w * self.value
            self._meterValueRect:setX(n - 1)
            self._meterValueRect:setWidth(e)
            if (self._meterValueRect:getX() < self:getX()) then
                self._meterValueRect:setX(self.x + 2)
            end
            if (self._meterValueRect:getX2() > self:getX2() - 4) then
                self._meterValueRect:setX(self._meterValueRect:getX() - 4)
            end
        end
        self._meterValueRect:_updateXyTable()
        self:needRedraw()
    end
    function e:_drawBackGround(e)
        if (self:isColisionMouse()) then
            gfx.set(self:getColor("background_onMouse"))
        else
            gfx.set(self:getColor("background"))
        end
        gfx.rect(e.x, e.y, e.w, e.h, true)
    end
    function e:_drawValueText(e)
        gfx.set(self:getColor("text"))
        local t = e:getCenterPoint()
        local n = gfx.texth
        local e = self.label .. self:valueToText()
        local a = #e
        gfx.x = t.x - (n / 2) * (a / 2)
        gfx.y = t.y - n / 2
        gfx.drawstr(e)
    end
    function e:_drawHorizontalMeter(e)
        gfx.set(self:getColor("meter_value"))
        gfx.setfont(1, self._fontName, self._fontSize)
        local e = self._meterValueRect
        gfx.rect(e.x, e.y, e.w, e.h, true)
    end
    function e:_drawHorizontalCenterMeter(e)
        gfx.set(self:getColor("meter_value"))
        gfx.setfont(1, self._fontName, self._fontSize)
        local n = self._meterValueRect
        gfx.rect(n.x, n.y, n.w, n.h, true)
        local n = e:getCenterPoint()
        gfx.set(self:getColor("black"))
        gfx.line(n.x - 1, e.y, n.x - 1, e:getY2())
        self:_drawValueText(e)
    end
    function e:_xyToValue(n, e)
        local e = 0
        if (self:isHorizontaleMeter()) then
            local n = n - self.x
            local n = n / self.w
            e = n * self.maxValue
        end
        if (self:isHorizontalCenterMeter()) then
            local n = n - self.x
            local n = n / self.w
            e = n * self.maxValue
        end
        return e
    end
    return e
end
function createTextPanel(e)
    local e = createComponent(e, x, y, w, h)
    e.offsetY = 0
    e.drawTexts = {}
    e:storeColor("text", {0, 0, 0, 1})
    e:storeColor("background", {1, 1, 1, 1})
    e._marginX = 10
    e._marginY = 10
    e._CLASS_TYPE = "TextPanel"
    e._AlIGN_CENTOR_ = false
    function e:setTextMargin(n, e)
        self._marginX = n
        self._marginY = e
        self:needRedraw()
    end
    function e:setDrawTextsAsCopy(e)
        self.drawTexts = deepcopy(e)
        self:needRedraw()
    end
    function e:setTextOffsetLine(e)
        self.offsetY = e
        if (self.offsetY < 0) then
            self.offsetY = 0
        end
        if (self.offsetY > #self.drawTexts - 1) then
            self.offsetY = #self.drawTexts - 1
        end
        self:needRedraw()
    end
    function e:tryTextShown(n)
        if (self:_checkNeedOffsetOption()) then
            for t, e in ipairs(self.drawTexts) do
                if (e == n) then
                    self:setTextOffsetLine(t - 1)
                    break
                end
            end
        else
            self:setTextOffsetLine(0)
        end
        self:needRedraw()
    end
    function e:setDrawTexts(e)
        self.drawTexts = e
        self:needRedraw()
    end
    function e:setCentorizeText(e)
        self._AlIGN_CENTOR_ = e
        self:needRedraw()
    end
    function e:onMouseWheel(e)
        if (self:isColisionMouse()) then
            if (self:_checkNeedOffsetOption()) then
                self:setTextOffsetLine(self.offsetY - e)
            else
                self:setTextOffsetLine(0)
            end
        end
    end
    function e:onDraw(n, e)
        e:drawFillAll(self:getColor("background"))
        gfx.setfont(1, self._fontName, self._fontSize)
        gfx.set(self:getColor("text"))
        local t = self._marginX
        local o = self._marginY
        for n = self.offsetY + 1, #self.drawTexts do
            local a = e.x + t
            local t = e.y + gfx.texth * (n - self.offsetY - 1) + o
            if (self._AlIGN_CENTOR_ == true) then
                local o = #self.drawTexts[n]
                local o = gfx.texth / 2 * o
                a = (e.x + e.w / 2) - o / 2
                t = (e.y + e.h / 2) - gfx.texth / 2
                local n = self.drawTexts[n]
                local e = self:_checkDrawStrSize(n, e)
                self:setFont("", e)
            end
            if (t > e:getY2() - o) then
                break
            end
            gfx.x = a
            gfx.y = t
            gfx.drawstr(self.drawTexts[n])
        end
    end
    function e:_checkNeedOffsetOption()
        local e = (self.h - self._marginY) / self._fontSize
        return (e < #self.drawTexts)
    end
    function e:_checkDrawStrSize(n, e)
        local n = #n + 1
        local n = e.w / n * 1.8
        local e = math.max(math.min(n, e.h), 20)
        return e
    end
    return e
end
function createCursolRect(e)
    local e = createComponent(e, x, y, w, h)
    e.movingArea = createRectangle(0, 0, gfx.w, gfx.h)
    e:storeColor("background", {1, 0, 0, 1})
    e:storeColor("centerCircle_out", {0, 0, 0, 1})
    e:storeColor("centerCircle", {1, 1, 1, 1})
    e._rectSize = 20
    e._onMovedFunction = {}
    e._CLASS_TYPE = "CursolRect"
    function e:addOnMovedFunction(e)
        if (type(e) ~= "function") then
            return
        end
        local n = table.doubleCheck(self._onMovedFunction, e)
        if (n == false) then
            table.insert(self._onMovedFunction, e)
        end
    end
    function e:setMovingArea(e)
        self.movingArea = e
    end
    function e:setRectSize(e)
        self._rectSize = e
        self:setWidth(self._rectSize)
        self:setHeight(self._rectSize)
        self:onResized()
    end
    function e:onDraw(e, n)
        local e = n:getCenterPoint()
        local t = n.w / 2 * .9
        gfx.set(self:getColor("centerCircle_out"))
        gfx.circle(e.x, e.y - 1, t, true)
        t = n.w / 2 * .7
        gfx.set(self:getColor("centerCircle"))
        gfx.circle(e.x, e.y - 1, t, true)
    end
    function e:onMouseMove(n, e)
        if (self:_isMouseDragging()) then
            self:setX(n - self.w / 2)
            self:setY(e - self.h / 2)
            self:_checkMovingArea()
            for n, e in ipairs(self._onMovedFunction) do
                e(self)
            end
        end
    end
    function e:_checkMovingArea()
        local e = self.movingArea:getX()
        local n = self.movingArea:getX2() - self._rectSize
        local t = self.movingArea:getY()
        local a = self.movingArea:getY2() - self._rectSize
        if (self.x > n) then
            self:setX(n)
        end
        if (self.x < e) then
            self:setX(e)
        end
        if (self.y > a) then
            self:setY(a)
        end
        if (self.y < t) then
            self:setY(t)
        end
    end
    return e
end
function createXYSlider(e)
    local e = createComponent(e, x, y, w, h)
    e._editCursolRect = nil
    e._editCursolSize = 26
    e._gridDiv = 4
    e._labelTable = {"A", "B", "C", "D"}
    e._labelFontSize = 24
    e._lastXValue = .5
    e._lastYValue = .5
    e:storeColor("background", {1, 1, 1, 1})
    e:storeColor("background_grid", {0, 0, 0, 1})
    e:storeColor("background_grid2", {0, 0, 0, .3})
    e:storeColor("cursolRectColor", {1, 0, 0, 1})
    e:storeColor("text", {0, 0, 0, 1})
    e._onValueChangedFunction = {}
    e._CLASS_TYPE = "XYSlider"
    function e:addOnValueChangeFunction(e)
        if (type(e) ~= "function") then
            return
        end
        local n = table.doubleCheck(self._onValueChangedFunction, e)
        if (n == false) then
            table.insert(self._onValueChangedFunction, e)
        end
    end
    function e:setLabelTable(e)
        self._labelTable = e
    end
    function e:getXValue()
        local n = self._editCursolRect:getCenterPoint()
        local e = self:getRectangle()
        e:reduce(self._editCursolSize / 2, self._editCursolSize / 2)
        local e = (n.x - e.x) / e.w
        return e
    end
    function e:getYValue()
        local n = self._editCursolRect:getCenterPoint()
        local e = self:getRectangle()
        e:reduce(self._editCursolSize / 2, self._editCursolSize / 2)
        local e = (n.y - e.y) / e.h
        return e
    end
    function e:setCursolColor(e)
        self._editCursolRect:storeColor("centerCircle", e)
    end
    function e:onResized()
        self:_updateEditoCursolRect()
    end
    function e:onUpdate(e)
        self:needRedraw(true)
    end
    function e:onDraw(n, e)
        self:_drawBackGround(e)
        self:_drawBackgroundGrid(e)
        self:_drawEditCursolRectBorder(e)
    end
    function e:onDraw2(n, e)
        self:_drawValueInfo(e)
        self:_drawLabels(e)
        self._lastXValue = self:getXValue()
        self._lastYValue = self:getYValue()
    end
    function e:_init()
        self._editCursolRect = createCursolRect("editCursolRect")
        self._editCursolRect:setRectSize(self._editCursolSize)
        self:addChildComponent(self._editCursolRect)
        self._editCursolRect:addOnMovedFunction(
            function(e)
                self:_valueChanged()
            end
        )
    end
    function e:_updateEditoCursolRect()
        local e = self:getRectangle()
        e:reduce(self._editCursolSize / 2, self._editCursolSize / 2)
        local n = e.x + (e.w * self._lastXValue)
        local e = e.y + (e.h * self._lastYValue)
        n = n - self._editCursolRect.w / 2
        e = e - self._editCursolRect.h / 2
        self._editCursolRect:setX(n)
        self._editCursolRect:setY(e)
        self._editCursolRect:setMovingArea(self:getRectangle())
    end
    function e:_drawBackGround(e)
        gfx.set(self:getColor("background"))
        gfx.rect(e.x, e.y, e.w, e.h)
    end
    function e:_drawBackgroundGrid(e)
        gfx.set(self:getColor("background_grid"))
        local n = e:getCenterPoint()
        gfx.line(e.x, n.y, e:getX2(), n.y)
        gfx.line(n.x, e.y, n.x, self:getY2())
        local t = self._gridDiv
        local a = e.w / t
        local o = e.h / t
        gfx.set(self:getColor("background_grid2"))
        for t = 1, t do
            local n = e.x + a * t
            local t = e.y + o * t
            gfx.line(n, e.y, n, e:getY2())
            gfx.line(e.x, t, e:getX2(), t)
        end
        gfx.set(self:getColor("black"))
        gfx.circle(n.x - 1, n.y, 3, true)
    end
    function e:_drawEditCursolRectBorder(t)
        local n = self._editCursolRect:getCenterPoint()
        gfx.set(self:getColor("background_grid"))
        local e = metaTableCopy(self._editCursolRect:getOffScreenCanvasRect())
        local o = n.x
        local a = n.y
        local r = e:getComponentX()
        local r = e:getComponentY()
        local r = e:getX_fromParrentComp()
        local e = e:getY_fromParrentComp()
        if (DEFINE_COMPONENT_USE_EACH_OFFSCREEN) then
            o = n.x - self.x
            a = n.y - self.y
        end
        gfx.line(o, t.y, o, t:getY2())
        gfx.line(t.x, a, t:getX2(), a)
    end
    function e:_drawValueInfo(t)
        gfx.set(self:getColor("text"))
        gfx.setfont(1, self._fontName, self._fontSize)
        local n = self:getXValue()
        local e = self:getYValue()
        local n = string.format("X %1.2f \nY %1.2f", n, e)
        local e = t:getCenterPoint()
        gfx.x = e.x + gfx.texth / 2
        gfx.y = e.y + gfx.texth / 2
        gfx.drawstr(n)
    end
    function e:_drawLabels(e)
        gfx.set(self:getColor("text"))
        gfx.setfont(1, self._fontName, self._labelFontSize)
        gfx.x = e.x + gfx.texth / 2 / 2
        gfx.y = e.y
        gfx.drawstr(self._labelTable[1])
        gfx.x = e:getX2() - gfx.texth * .5 - gfx.texth * #self._labelTable[2] / 2
        gfx.y = e.y
        gfx.drawstr(self._labelTable[2])
        gfx.x = e:getX2() - gfx.texth * .5 - gfx.texth * #self._labelTable[3] / 2
        gfx.y = e:getY2() - gfx.texth
        gfx.drawstr(self._labelTable[3])
        gfx.x = e.x + gfx.texth / 2 / 2
        gfx.y = e:getY2() - gfx.texth
        gfx.drawstr(self._labelTable[4])
        gfx.setfont(1, self._fontName, self._fontSize)
    end
    function e:_valueChanged()
        for n, e in ipairs(self._onValueChangedFunction) do
            e(self)
        end
        self:needRedraw()
    end
    e:_init()
    return e
end
_INCLUDE_MODE_ = true
_INCLUDE_MODE_2 = true
local _ = 60
local f = 60
local s = 1
local d = 1
local u = 5
local o = 1
local g = false
local m = false
local h = false
local l = 5
local r = 5
local p = 5
local c = 1
local n = {
    "",
    "bypass",
    "wet",
    "volume",
    "master",
    "master level",
    "makeup",
    "make up",
    "gain",
    "output",
    "output gain",
    "level",
    "program",
    "preset"
}
math.randomseed(reaper.time_precise() * os.time() / 1e3)
local i = "kawa_MAIN_RANDMIZE"
local a = "lastFxParameter"
if (package.config:sub(1, 1) == "\\") then
else
end
local t = 0
local function x()
    local e = {}
    e._check = nil
    e.randomWidth = .6
    e.exclusiveNames = deepcopy(n)
    e.matchedParameterName = {}
    e.lastTrackID = nil
    e.lastFxID = nil
    e.lastFxParamID = nil
    e.targetTrack = nil
    e.lastFxName = ""
    e.lastFxParamName = ""
    e.lastFxParam_value = {}
    function e:setRandomWidth(e)
        self.randomWidth = e
        if (self.randomWidth < 0) then
            self.randomWidth = 0
        end
        if (self.randomWidth > 1) then
            self.randomWidth = 1
        end
    end
    function e:storeBasePreset()
        self._check = self:_storeLastFxInfo()
        if (self._check == true) then
            self:_storeFxParamValue()
            self:_saveState()
        else
            self.lastFxParam_value = {}
            self:_saveState()
        end
    end
    function e:randomize()
        self.matchedParameterName = {}
        self._check = self:_storeLastFxInfo()
        if (self._check == false) then
            return
        end
        local e = self.randomWidth * o
        self:_loadState()
        if (self:_isSameTrackFx() == false) then
            self._check = self:_storeLastFxInfo()
            if (self._check == false) then
                return
            end
            self:_storeFxParamValue()
            self:_saveState()
        end
        for t, n in ipairs(self.lastFxParam_value) do
            if (self:_isExclusiveParam(n.fxPramName) == false) then
                local e = n.fxPramValue + (e * math.random()) - (e / 2)
                if (e > 1) then
                    e = 1
                end
                if (e < 0) then
                    e = 0
                end
                reaper.TrackFX_SetParamNormalized(self.targetTrack, n.trackFxID, n.fxPramID, e)
            else
                table.insert(self.matchedParameterName, n.fxPramName)
            end
        end
    end
    function e:addExclusivParam(n)
        local e = false
        for a, t in ipairs(self.exclusiveNames) do
            if (t == n) then
                e = true
                break
            end
        end
        if (e == false) then
            table.insert(self.exclusiveNames, 1, n)
        end
    end
    function e:removeExclusivParam(n)
        for e, t in ipairs(self.exclusiveNames) do
            if (t == n) then
                table.remove(self.exclusiveNames, e)
                break
            end
        end
    end
    function e:_init()
        self._check = self:_storeLastFxInfo()
    end
    function e:_storeLastFxInfo()
        local e = false
        local n = false
        local a = false
        e, self.lastTrackID, self.lastFxID, self.lastFxParamID = reaper.GetLastTouchedFX()
        local o = nil
        if (m == false) then
            e, self.lastTrackID, o, self.lastFxID = reaper.GetFocusedFX()
        end
        if (self.lastTrackID == 0) then
            self.targetTrack = reaper.GetMasterTrack(t)
        else
            self.targetTrack = reaper.GetTrack(t, self.lastTrackID - 1)
        end
        if (e and self.targetTrack ~= nil) then
            n, self.lastFxName = reaper.TrackFX_GetFXName(self.targetTrack, self.lastFxID, "")
            a, self.lastFxParamName =
                reaper.TrackFX_GetParamName(self.targetTrack, self.lastFxID, self.lastFxParamID, "")
            self.lastFxName = string.lower(self.lastFxName)
            self.lastFxParamName = string.lower(self.lastFxParamName)
        end
        local e = (e ~= false and n ~= false)
        if (e == false) then
            self.lastFxName = ""
            self.lastFxParamName = ""
        end
        return e
    end
    function e:_isExclusiveParam(e)
        local n = string.lower(e)
        local e = false
        for a, t in ipairs(self.exclusiveNames) do
            if (n == string.lower(t)) then
                e = true
                break
            end
        end
        return e
    end
    function e:_storeFxParamValue()
        self.lastFxParam_value = {}
        if (self._check ~= true) then
            return
        end
        local e = reaper.TrackFX_GetNumParams(self.targetTrack, self.lastFxID)
        for n = 0, e - 1 do
            local e, t = reaper.TrackFX_GetParamName(self.targetTrack, self.lastFxID, n, "")
            if (e == true) then
                local e = {}
                e.trackID = self.lastTrackID
                e.trackFxID = self.lastFxID
                e.fxName = self.lastFxName
                e.fxPramID = n
                e.fxPramName = string.lower(t)
                e.fxPramValue = reaper.TrackFX_GetParamNormalized(self.targetTrack, self.lastFxID, n)
                table.insert(self.lastFxParam_value, e)
            end
        end
    end
    function e:_saveState()
        reaper.SetExtState(i, a, table.toString(self.lastFxParam_value), false)
    end
    function e:_loadState()
        local e = reaper.GetExtState(i, a)
        if (e ~= "") then
            self.lastFxParam_value = table.fromString(e)
        else
            self.lastFxParam_value = {}
        end
    end
    function e:_isSameTrackFx()
        local n = false
        for t, e in ipairs(self.lastFxParam_value) do
            if (self.lastTrackID == e.trackID and self.lastFxID == e.trackFxID and self.lastFxName == e.fxName) then
                n = true
                break
            end
        end
        return n
    end
    e:_init()
    return e
end
local function m(t, e)
    local n = createTextPanel(e)
    n._fxRandomiza_P = t
    n._lastFxParamName_ = ""
    n:storeColor("text", {0, 0, 0, 1})
    n:storeColor("background", {1, 1, 1, 1})
    n:storeColor("lockedparameter", {1, 0, 0, 1})
    n:storeColor("matchedparameter", {0, .5, 1, 1})
    function n:onDraw(n, e)
        local i = self._fxRandomiza_P.matchedParameterName
        if (self._lastFxParamName_ ~= self._fxRandomiza_P.lastFxParamName) then
            self._lastFxParamName_ = self._fxRandomiza_P.lastFxParamName
            self:tryTextShown(self._lastFxParamName_)
        end
        gfx.set(self:getColor("background"))
        gfx.rect(e.x, e.y, e.w, e.h, true)
        gfx.setfont(1, self._fontName, self._fontSize)
        gfx.set(self:getColor("text"))
        local a = l
        local t = r
        local o = "LOCKED PARAMETER NAME"
        local n = "---------------------"
        gfx.x = e.x + a
        gfx.y = e.y + t
        gfx.printf(o .. "\n" .. n .. "\n")
        local r = 0 + a / 2
        local o = gfx.y + t * 2
        for n = self.offsetY + 1, #self.drawTexts do
            local r = r + a
            local a = o + gfx.texth * (n - self.offsetY - 1) + t
            if (a > e.y + e.h - t * 2) then
                break
            end
            gfx.set(self:getColor("text"))
            if (g) then
                for t, e in ipairs(i) do
                    if (e == self.drawTexts[n]) then
                        gfx.set(self:getColor("matchedparameter"))
                    end
                end
            end
            local e = self._fxRandomiza_P.lastFxParamName or ""
            if (string.lower(self.drawTexts[n]) == string.lower(e)) then
                gfx.set(self:getColor("lockedparameter"))
            end
            local e = tostring(n) .. ":"
            gfx.x = r
            gfx.y = a
            gfx.drawstr(e .. self.drawTexts[n])
        end
    end
    return n
end
local function i(e)
    local e = createSlider(e)
    function e:valueToText()
        return string.format("%3.0f%%(+-%2.0f%%)", self.value * o * 100, self.value * o * 100 / 2)
    end
    return e
end
function createFxRandomizaComponent(e)
    local e = createComponent(e)
    e.fxRandomiza = x()
    e.bt_Random = nil
    e.bt_addExclusivParam = nil
    e.bt_removeExclusivParam = nil
    e.bt_storeBasePreset = nil
    e.sl_randWidth = nil
    e.text_exclusiveList = nil
    e._lastFx_Name = ""
    e._lastTrackID = nil
    e._lastFxID = nil
    e._hueOffset = 0
    function e:onResized()
        local n = 4
        local t = 90
        local e = createRectangle()
        e.x = self.x
        e.y = self.y + 45
        e.w = (self.w / n)
        e.h = t / 2
        self.bt_Random:setBoundsFromRect(e)
        e.x = e.x + e.w
        self.bt_storeBasePreset:setBoundsFromRect(e)
        e.x = e.x + e.w
        self.bt_addExclusivParam:setBoundsFromRect(e)
        e.x = e.x + e.w
        self.bt_removeExclusivParam:setBoundsFromRect(e)
        local n = createRectangle()
        n.x = self.x
        n.y = e:getY2()
        n.w = self.w
        n.h = t / 2
        self.sl_randWidth:setBoundsFromRect(n)
        local e = createRectangle()
        e.x = self.x
        e.y = n:getY2()
        e.w = self.w
        e.h = self:getY2() - n:getY2()
        self.text_exclusiveList:setBoundsFromRect(e)
        local e = r
        local n = l
        self.bt_Random:reduce_2(e, 0, n, 0)
        self.bt_storeBasePreset:reduce_2(e, 0, n, 0)
        self.bt_addExclusivParam:reduce_2(e, 0, n, 0)
        self.bt_removeExclusivParam:reduce_2(e, e, n, 0)
        self.sl_randWidth:reduce_2(e, e, n, 0)
        self.text_exclusiveList:reduce(e, n)
    end
    function e:onUpdate(e)
        self:_checkLastFx()
        self:_checklastFx_info()
        self:needRedraw(true)
        self.text_exclusiveList:needRedraw(true)
    end
    function e:onDraw(n, e)
        e:fillAll(self:getColor("black"))
        self:_drawlastTrackFxInfo(e)
        self:_drawBorder(e)
    end
    function e:_init()
        self:_createButton()
        self:_createSlider()
        self:_createTextPanel()
        self:storeColor("background", {.2, .2, .2, 1})
    end
    function e:_checkLastFx()
        self.fxRandomiza:_storeLastFxInfo()
    end
    function e:_createButton()
        self.bt_Random = createButton("RANDOM")
        self.bt_addExclusivParam = createButton("LOCK")
        self.bt_removeExclusivParam = createButton("UNLOCK")
        self.bt_storeBasePreset = createButton("SET")
        self:addChildComponent(self.bt_Random)
        self:addChildComponent(self.bt_addExclusivParam)
        self:addChildComponent(self.bt_removeExclusivParam)
        self:addChildComponent(self.bt_storeBasePreset)
        self.bt_Random:storeColor("background_offMouse", {.9, .9, .9, 1})
        self.bt_addExclusivParam:storeColor("background_offMouse", {.9, .9, .9, 1})
        self.bt_removeExclusivParam:storeColor("background_offMouse", {.9, .9, .9, 1})
        self.bt_storeBasePreset:storeColor("background_offMouse", {.9, .9, .9, 1})
        self.bt_Random:setFont("", 17)
        self.bt_addExclusivParam:setFont("", 17)
        self.bt_removeExclusivParam:setFont("", 17)
        self.bt_storeBasePreset:setFont("", 17)
        local e = self
        local function n(a)
            local e = math.floor(360 * math.random())
            local t, n, e = HSVToRGB(e, .65, 1)
            t, n, e = t / 255, n / 255, e / 255
            a:storeColor("background_offMouse", {t, n, e, 1})
            a:storeColor("background_onMouse", {t, n, e, 1})
        end
        self.bt_Random:addMouseReleaseFunction(
            function(t, a)
                e.fxRandomiza:randomize()
                n(t)
            end
        )
        self.bt_Random:addMouseWheelFunction(
            function(t, a)
                e.fxRandomiza:randomize()
                n(t)
            end
        )
        self.bt_addExclusivParam:addMouseReleaseFunction(
            function(a, t)
                local t = e.fxRandomiza.lastFxParamName
                e.fxRandomiza:addExclusivParam(t)
                e.text_exclusiveList:tryTextShown(t)
                n(a)
            end
        )
        self.bt_removeExclusivParam:addMouseReleaseFunction(
            function(a, t)
                local t = e.fxRandomiza.lastFxParamName
                e.fxRandomiza:removeExclusivParam(t)
                e.text_exclusiveList:setTextOffsetLine(0)
                n(a)
            end
        )
        self.bt_storeBasePreset:addMouseReleaseFunction(
            function(t, a)
                e.fxRandomiza:storeBasePreset()
                n(t)
            end
        )
    end
    function e:_createSlider()
        self.sl_randWidth = i("Random Width")
        self.sl_randWidth:storeColor("background", {.9, .9, .9, 1})
        self:addChildComponent(self.sl_randWidth)
        local n = self
        self.sl_randWidth:addOnValueChangeFunction(
            function(e)
                n.fxRandomiza:setRandomWidth(e:getValue())
            end
        )
        self.sl_randWidth:setFont("", 18)
    end
    function e:_createTextPanel()
        self.text_exclusiveList = m(self.fxRandomiza, "list")
        self:addChildComponent(self.text_exclusiveList)
        self.text_exclusiveList:storeColor("background", {.9, .9, .9, 1})
        self.text_exclusiveList:setDrawTexts(self.fxRandomiza.exclusiveNames)
        self.text_exclusiveList:setFont("", 16.5)
    end
    function e:_drawlastTrackFxInfo(e)
        local n = createRectangle(e.x, e.y, e:getWidth(), 45)
        n:fillAll(self:getColor("background"))
        local n = tostring(self.fxRandomiza.lastTrackID)
        local t = tostring(self.fxRandomiza.lastFxID)
        local o = tostring(self.fxRandomiza.lastFxName)
        local a = tostring(self.fxRandomiza.lastFxParamName)
        local n = n .. ":" .. t .. ":" .. o
        local t = "Parameter:" .. a
        gfx.setfont(1, self._fontName, 15)
        gfx.set(self:getColor("white"))
        gfx.x = e.x + 10
        gfx.y = e.y + 12
        gfx.drawstr(n)
        gfx.y = gfx.y + gfx.texth
        gfx.x = e.x + 10
        gfx.drawstr(t)
    end
    function e:_checklastFx_info()
        if
            (self._lastFx_Name ~= self.fxRandomiza.lastFxName or self._lastTrackID ~= self.fxRandomiza.lastTrackID or
                self._lastFxID ~= self.fxRandomiza.lastFxID)
         then
            self._hueOffset = math.random() * 360
            self._lastFx_Name = self.fxRandomiza.lastFxName
            self._lastTrackID = self.fxRandomiza.lastTrackID
            self._lastFxID = self.fxRandomiza.lastFxID
            self:needRedraw()
        end
    end
    function e:_drawBorder(a)
        local t = u
        local n = a.w / t
        local o = 1 / t
        for e = 1, t do
            local o, r, t = HSVToRGB(_ + self._hueOffset + f * (e / t), d, s)
            gfx.set(o / 255, r / 255, t / 255, 1 * self._componentAlpha)
            gfx.rect(n * (e - 1) - 1, a.y, n + 5, p, true)
            gfx.rect(n * (e - 1) - 1, a:getY2() - c, n + 5, c, true)
        end
    end
    e:_init()
    return e
end
local function r()
    local e = createApp("Fx Randomiza", 400, 280)
    local n = createFxRandomizaComponent("random")
    e:addChildComponent(n)
    if (h) then
        e:toggleDock()
    end
    e:runLoop()
end
if (_INCLUDE_MODE_ ~= true) then
    r()
end
local x = false
local g = false
local l = 5
local h = 5
local i = 5
local _ = 60
local m = 60
local u = 1
local f = 1
local c = 5
local o = 40914
local e = 40111
local e = 40112
local d = 40869
local s = 40875
if (package.config:sub(1, 1) == "\\") then
else
end
local n = 0
function createFxParams()
    local e = {}
    e._check = nil
    e.storeTrackID = nil
    e.storeFxID = nil
    e.storeFxParamID = nil
    e.targetTrack = nil
    e.storeFxName = ""
    e.lastFxParamName = ""
    e.storeFxParam_value = {}
    function e:checkActive()
        return (self._check == true and self:isExistTrackFx() == true)
    end
    function e:storeBasePreset()
        self._check = self:_storeLastFxInfo()
        if (self._check == true) then
            self:_storeFxParamValue()
        else
            self.storeFxParam_value = {}
        end
    end
    function e:clearStorePreset()
        self.storeTrackID = nil
        self.storeFxID = nil
        self.storeFxParamID = nil
        self.targetTrack = nil
        self.storeFxName = ""
        self.lastFxParamName = ""
        self.storeFxParam_value = {}
    end
    function e:isSameFx(e)
        local t = false
        if
            (e.storeTrackID == self.storeTrackID and e.storeFxID == self.storeFxID and e.storeFxName == self.storeFxName and
                #e.storeFxParam_value == #self.storeFxParam_value)
         then
            for a, n in ipairs(self.storeFxParam_value) do
                local e = e.storeFxParam_value[a]
                if (n.trackID == e.trackID and n.trackFxID == e.trackFxID and n.fxName == e.fxName) then
                    t = true
                    break
                end
            end
        end
        return t
    end
    function e:getStorePresetTable()
        return self.storeFxParam_value
    end
    function e:isExistTrackFx()
        if (self.targetTrack == nil) then
            return false
        end
        local e = nil
        if (self.storeTrackID == 0) then
            e = reaper.GetMasterTrack(n)
        else
            e = reaper.GetTrack(n, self.storeTrackID - 1)
        end
        if (self.targetTrack ~= e) then
            return
        end
        local e = false
        local t = false
        local n = ""
        t, n = reaper.TrackFX_GetFXName(self.targetTrack, self.storeFxID, "")
        if (t and string.lower(n) == self.storeFxName) then
            e = true
        end
        return e
    end
    function e:presetToReaper()
        if (self:checkActive() == false) then
            return
        end
        for n, e in ipairs(self.storeFxParam_value) do
            reaper.TrackFX_SetParamNormalized(self.targetTrack, e.trackFxID, e.fxPramID, e.fxPramValue)
        end
    end
    function e:presetToEnvelope()
        if (self:checkActive() == false) then
            return
        end
        if (self:_check_SWS_Function() == false) then
            return
        end
        local t = reaper.GetCursorPosition()
        for n, e in ipairs(self.storeFxParam_value) do
            if (e.fxPramName ~= "bypass") then
                local o, n, a, o = reaper.TrackFX_GetParamEx(self.targetTrack, e.trackFxID, e.fxPramID)
                local a = a - n
                local n = n + a * e.fxPramValue
                local e = reaper.GetFXEnvelope(self.targetTrack, e.trackFxID, e.fxPramID, true)
                reaper.PreventUIRefresh(2)
                reaper.InsertEnvelopePoint(e, t, n, 0, 0, false, false)
                reaper.Envelope_SortPoints(e)
                reaper.PreventUIRefresh(-1)
            end
        end
        reaper.TrackList_UpdateAllExternalSurfaces()
        reaper.UpdateArrange()
        reaper.UpdateTimeline()
    end
    function e:presetEnvTimeSelectionClear()
        if (self:checkActive() == false) then
            return
        end
        if (self:_check_SWS_Function() == false) then
            return
        end
        local o, a = reaper.GetSet_LoopTimeRange2(n, false, false, 0, 0, false)
        for n, e in ipairs(self.storeFxParam_value) do
            local e = reaper.GetFXEnvelope(self.targetTrack, e.trackFxID, e.fxPramID, false)
            if (e ~= nil) then
                local n = reaper.BR_EnvAlloc(e, false)
                local r, t, r, r, r, r, r, r, r, r, r = reaper.BR_EnvGetProperties(n)
                if (t == true) then
                    reaper.PreventUIRefresh(1)
                    reaper.DeleteEnvelopePointRange(e, o, a)
                    reaper.PreventUIRefresh(-1)
                end
                reaper.PreventUIRefresh(2)
                reaper.BR_EnvFree(n, true)
                reaper.Envelope_SortPoints(e)
                reaper.PreventUIRefresh(-1)
            end
        end
        reaper.UpdateArrange()
        reaper.UpdateTimeline()
    end
    function e:toggleAllEnvVisible()
        if (self:checkActive() == false) then
            return
        end
        if (self:_check_SWS_Function() == false) then
            return
        end
        local n = nil
        for t, e in ipairs(self.storeFxParam_value) do
            local t = reaper.GetFXEnvelope(self.targetTrack, e.trackFxID, e.fxPramID, false)
            if (t ~= nil) then
                local e = reaper.BR_EnvAlloc(t, true)
                local o, a, r, l, c, i, s, s, s, s, d = reaper.BR_EnvGetProperties(e)
                if (n == nil) then
                    n = (a == false)
                end
                reaper.PreventUIRefresh(3)
                reaper.BR_EnvSetProperties(e, o, n, r, l, c, i, d)
                reaper.BR_EnvFree(e, true)
                reaper.Envelope_SortPoints(t)
                reaper.PreventUIRefresh(-1)
            end
        end
        reaper.UpdateArrange()
        reaper.UpdateTimeline()
    end
    function e:toggleAllEnvBypass()
        if (self:checkActive() == false) then
            return
        end
        if (self:_check_SWS_Function() == false) then
            return
        end
        local t = nil
        for n, e in ipairs(self.storeFxParam_value) do
            local n = reaper.GetFXEnvelope(self.targetTrack, e.trackFxID, e.fxPramID, false)
            if (n ~= nil) then
                local e = reaper.BR_EnvAlloc(n, false)
                local c, d, i, r, o, a, s, s, s, s, l = reaper.BR_EnvGetProperties(e)
                if (t == nil) then
                    t = (c == false)
                end
                reaper.PreventUIRefresh(3)
                reaper.BR_EnvSetProperties(e, t, d, i, r, o, a, l)
                reaper.BR_EnvFree(e, true)
                reaper.Envelope_SortPoints(n)
                reaper.PreventUIRefresh(-1)
            end
        end
        reaper.UpdateArrange()
        reaper.UpdateTimeline()
    end
    function e:IsAllEnvActive()
        if (self:checkActive() == false) then
            return
        end
        if (self:_check_SWS_Function() == false) then
            return
        end
        local e = false
        for t, n in ipairs(self.storeFxParam_value) do
            local n = reaper.GetFXEnvelope(self.targetTrack, n.trackFxID, n.fxPramID, false)
            if (n ~= nil) then
                local n = reaper.BR_EnvAlloc(n, false)
                local n, t, t, t, t, t, t, t, t, t, t = reaper.BR_EnvGetProperties(n)
                if (n == true) then
                    e = true
                    break
                end
            end
        end
        reaper.UpdateArrange()
        reaper.UpdateTimeline()
        reaper.TrackList_UpdateAllExternalSurfaces()
        return e
    end
    function e:setToAllEnvEnable()
        if (self:checkActive() == false) then
            return
        end
        if (self:_check_SWS_Function() == false) then
            return
        end
        for n, e in ipairs(self.storeFxParam_value) do
            local e = reaper.GetFXEnvelope(self.targetTrack, e.trackFxID, e.fxPramID, false)
            if (e ~= nil) then
                local n = reaper.BR_EnvAlloc(e, false)
                local i, t, i, a, o, l, i, i, i, i, r = reaper.BR_EnvGetProperties(n)
                reaper.PreventUIRefresh(3)
                reaper.BR_EnvSetProperties(n, true, t, true, a, o, l, r)
                reaper.BR_EnvFree(n, true)
                reaper.Envelope_SortPoints(e)
                reaper.PreventUIRefresh(-1)
            end
        end
        reaper.UpdateArrange()
        reaper.UpdateTimeline()
        reaper.TrackList_UpdateAllExternalSurfaces()
    end
    function e:setToAllEnvBypass()
        if (self:checkActive() == false) then
            return
        end
        if (self:_check_SWS_Function() == false) then
            return
        end
        for n, e in ipairs(self.storeFxParam_value) do
            local n = reaper.GetFXEnvelope(self.targetTrack, e.trackFxID, e.fxPramID, false)
            if (n ~= nil) then
                local e = reaper.BR_EnvAlloc(n, false)
                local i, l, i, r, o, a, i, i, i, i, t = reaper.BR_EnvGetProperties(e)
                reaper.PreventUIRefresh(3)
                reaper.BR_EnvSetProperties(e, false, l, false, r, o, a, t)
                reaper.BR_EnvFree(e, true)
                reaper.Envelope_SortPoints(n)
                reaper.PreventUIRefresh(-1)
            end
        end
        reaper.UpdateArrange()
        reaper.UpdateTimeline()
    end
    function e:toggleAllEnvInLane()
        if (self:checkActive() == false) then
            return
        end
        if (self:_check_SWS_Function() == false) then
            return
        end
        local t = nil
        for n, e in ipairs(self.storeFxParam_value) do
            local n = reaper.GetFXEnvelope(self.targetTrack, e.trackFxID, e.fxPramID, false)
            if (n ~= nil) then
                local e = reaper.BR_EnvAlloc(n, false)
                local d, i, c, l, r, o, s, s, s, s, a = reaper.BR_EnvGetProperties(e)
                if (t == nil) then
                    t = (l == false)
                end
                reaper.PreventUIRefresh(3)
                reaper.BR_EnvSetProperties(e, d, i, c, t, r, o, a)
                reaper.BR_EnvFree(e, true)
                reaper.Envelope_SortPoints(n)
                reaper.PreventUIRefresh(-1)
            end
        end
        reaper.UpdateArrange()
        reaper.UpdateTimeline()
        reaper.Main_OnCommand(o, 0)
    end
    function e:_check_SWS_Function(n)
        local e = false
        for n, t in pairs(reaper) do
            if (tostring(n) == "BR_EnvAlloc") then
                e = true
            end
        end
        if (e == false and n ~= true) then
            reaper.ShowMessageBox("this Options need SWS extensions ", "stop", 0)
        end
        return e
    end
    function e:_init()
        self._check = self:_storeLastFxInfo()
    end
    function e:_storeLastFxInfo()
        local e = false
        local t = false
        local o = false
        e, self.storeTrackID, self.storeFxID, self.storeFxParamID = reaper.GetLastTouchedFX()
        local a = nil
        if (g == false) then
            e, self.storeTrackID, a, self.storeFxID = reaper.GetFocusedFX()
        end
        if (self.storeTrackID == 0) then
            self.targetTrack = reaper.GetMasterTrack(n)
        else
            self.targetTrack = reaper.GetTrack(n, self.storeTrackID - 1)
        end
        if (e and self.targetTrack ~= nil) then
            t, self.storeFxName = reaper.TrackFX_GetFXName(self.targetTrack, self.storeFxID, "")
            o, self.lastFxParamName =
                reaper.TrackFX_GetParamName(self.targetTrack, self.storeFxID, self.storeFxParamID, "")
            self.storeFxName = string.lower(self.storeFxName)
            self.lastFxParamName = string.lower(self.lastFxParamName)
        end
        local e = (e ~= false and t ~= false)
        if (e == false) then
            self.storeFxName = ""
            self.lastFxParamName = ""
        end
        return e
    end
    function e:_storeFxParamValue()
        self.storeFxParam_value = {}
        if (self._check ~= true) then
            return
        end
        local e = reaper.TrackFX_GetNumParams(self.targetTrack, self.storeFxID)
        for n = 0, e - 1 do
            local e, t = reaper.TrackFX_GetParamName(self.targetTrack, self.storeFxID, n, "")
            if (e == true) then
                local e = {}
                e.targetTrack = self.targetTrack
                e.trackID = self.storeTrackID
                e.trackFxID = self.storeFxID
                e.fxName = self.storeFxName
                e.fxPramID = n
                e.fxPramName = string.lower(t)
                e.fxPramValue = reaper.TrackFX_GetParamNormalized(self.targetTrack, self.storeFxID, n)
                table.insert(self.storeFxParam_value, e)
            end
        end
    end
    function e:_sendChangeTrackNotify()
        reaper.PreventUIRefresh(2)
        reaper.Main_OnCommand(d, 0)
        reaper.Main_OnCommand(s, 0)
        reaper.PreventUIRefresh(-1)
    end
    e:_init()
    return e
end
function createPresetPanel(e, n)
    local e = createComponent(e)
    e.fxPreset = createFxParams()
    e.bt_set = nil
    e.text_info = nil
    e._buttonName = n
    e:storeColor("topborder", {1, 1, 1, .5})
    e._onChangeFunction = {}
    function e:addOnChangeFunction(e)
        if (type(e) ~= "function") then
            return
        end
        local n = false
        for a, t in ipairs(self._onChangeFunction) do
            if (t == e) then
                n = true
            end
        end
        if (n == false) then
            table.insert(self._onChangeFunction, e)
        end
    end
    function e:getStorePresetTable()
        return self.fxPreset:getStorePresetTable()
    end
    function e:getFxParams()
        return self.fxPreset
    end
    function e:onResized()
        local e = createRectangle()
        e.x = self.x
        e.y = self.y
        e.w = (self.w / 4)
        e.h = self.h
        self.bt_set:setBoundsFromRect(e)
        local n = createRectangle()
        n.x = e:getX2()
        n.y = self.y
        n.w = math.ceil((self.w / 4) * 3)
        n.h = math.ceil(self.h)
        self.text_info:setBoundsFromRect(n)
        self.bt_set:reduce_2(0, 0, 0, 0)
        self.text_info:reduce_2(l, 0, 0, 0)
    end
    function e:onUpdate(e)
        if (self.fxPreset:checkActive() == false) then
            self.bt_set:storeColor("background_offMouse", {1, 1, 1, 1})
            self.bt_set:storeColor("background_onMouse", {1, 1, 1, 1})
        end
    end
    function e:onDraw(e, e)
    end
    function e:onDraw2(e, e)
    end
    function e:_init()
        self:_createButton()
        self:_createTextPanel()
    end
    function e:_createButton()
        self.bt_set = createButton(self._buttonName)
        self:addChildComponent(self.bt_set)
        local e = self
        self.bt_set:addMouseReleaseFunction(
            function(n, n)
                if (self.isMouseLeftDown) then
                    e.fxPreset:storeBasePreset()
                    if (e.fxPreset:checkActive()) then
                        local n = math.floor(360 * math.random())
                        local a, t, n = HSVToRGB(n, .8, 1)
                        a, t, n = a / 255, t / 255, n / 255
                        e.bt_set:storeColor("background_offMouse", {a, t, n, 1})
                        e.bt_set:storeColor("background_onMouse", {a, t, n, 1})
                        e:_updatePresetInfo()
                        for n, e in ipairs(self._onChangeFunction) do
                            e(self)
                        end
                    end
                elseif (self.isMouseMiddleDown) then
                elseif (self.isMouseRightDown) then
                    e.fxPreset:clearStorePreset()
                    e:_updatePresetInfo()
                    e.bt_set:storeColor("background_offMouse", {1, 1, 1, 1})
                    e.bt_set:storeColor("background_onMouse", {1, 1, 1, 1})
                    for n, e in ipairs(self._onChangeFunction) do
                        e(self)
                    end
                end
                self.text_info:needRedraw()
            end
        )
    end
    function e:_createTextPanel()
        self.text_info = createTextPanel("info_" .. self._buttonName)
        self:addChildComponent(self.text_info)
        local e = "Track Number: " .. "UnSet"
        local n = "FX Name: ---"
        self.text_info:setDrawTexts({e, n})
        self.text_info:storeColor("text", {1, 1, 1, 1})
        self.text_info:storeColor("background", {.2, .2, .2, 1})
        self.text_info:setFont("", 15)
        self.text_info:setTextMargin(3, 3)
    end
    function e:_updatePresetInfo()
        local e = self.fxPreset.storeTrackID or 0
        local n = self.fxPreset.storeFxID
        local o = tostring(self.fxPreset.storeFxName)
        local t = ""
        local a = ""
        if (e ~= nil and n ~= nil) then
            e = tostring(e)
            n = tostring(n)
            t = "Track Number: " .. e .. ":" .. n .. ":"
            a = "FX Name: " .. o
        else
            t = "Track Number: " .. "UnSet"
            a = "FX Name: ---"
        end
        self.text_info:setDrawTexts({t, a})
    end
    function e:_drawTopBorder(n)
        gfx.set(self:getColor("topborder"))
        local n = self.text_info:getOffScreenCanvas()
        gfx.line(self.text_info.x, 0, self.text_info.x + self.text_info.w, 0, false)
    end
    e:_init()
    return e
end
function createCustomSlider(e, t, n)
    local e = createSlider(e)
    e.parrentCustomComp = n
    e:setLabel(t)
    e._mouseReleaseFunc = {}
    e._mousePressFunc = {}
    function e:valueToText()
        local n = self:getValue()
        local e = ""
        if (self:_checkCanMorphing()) then
            e = string.format("A:%3.0f%%|%3.0f%%:B", (1 - n) * 100, n * 100)
        else
            e = "- - - -"
        end
        return e
    end
    function e:addMouseReleaseFunc(e)
        local n = table.doubleCheck(self._mouseReleaseFunc, e)
        if (n == false) then
            table.insert(self._mouseReleaseFunc, e)
        end
    end
    function e:addMousePressFunc(e)
        local n = table.doubleCheck(self._mousePressFunc, e)
        if (n == false) then
            table.insert(self._mousePressFunc, e)
        end
    end
    function e:onMousePress(e)
        for n, e in ipairs(self._mousePressFunc) do
            e(self)
        end
    end
    function e:onMouseRelease(e)
        if (self.isStartInMouseDown == true) then
            for n, e in ipairs(self._mouseReleaseFunc) do
                e(self)
            end
        end
    end
    function e:_checkCanMorphing()
        return self.parrentCustomComp:canMorphing()
    end
    return e
end
function createFxMorph_2(e)
    local e = createComponent(e)
    e.focusCheckFx = createFxParams()
    e.focusInfoPanel = nil
    e.fxPanel_A = nil
    e.fxPanel_B = nil
    e.sl_morph_X = nil
    e.bt_toEnvelop = nil
    e.bt_toggleVisible = nil
    e.bt_clearTimeSelection = nil
    e.bt_toggleBypassEnv = nil
    e.bt_toggleInlaneEnv = nil
    e._lastFx_Name = nil
    e._lastTrackID = nil
    e._lastFxID = nil
    e._hueOffset = 0
    e._unMatchedParameters = {}
    e._storeIsEnvActive = false
    function e:canMorphing()
        local e = self.fxPanel_A.fxPreset
        local n = self.fxPanel_B.fxPreset
        local n = (e:isSameFx(n) == true)
        local e = e:isExistTrackFx()
        return (n == true and e == true)
    end
    function e:onResized()
        local t = 4
        local e = 50
        local n = createRectangle()
        n.x = self.x
        n.y = self.y + i
        n.w = (self.w)
        n.h = e
        self.focusInfoPanel:setBoundsFromRect(n)
        local o = (self:getY2() - n:getY2()) / t
        local e = createRectangle()
        e.x = self.x
        e.y = n:getY2()
        e.w = (self.w)
        e.h = o
        self.fxPanel_A:setBoundsFromRect(e)
        e.y = e:getY2()
        self.fxPanel_B:setBoundsFromRect(e)
        local n = h
        local t = l
        self.focusInfoPanel:reduce_2(n, n, t, t)
        self.fxPanel_A:reduce_2(n, n, 0, t)
        self.fxPanel_B:reduce_2(n, n, 0, t)
        local a = createRectangle()
        a.x = self.x
        a.y = self.fxPanel_B:getY2()
        a.w = self.w
        a.h = o
        self.sl_morph_X:setBoundsFromRect(a)
        self.sl_morph_X:reduce_2(n, n, t, 0)
        local e = createRectangle()
        e.x = self.x
        e.y = a:getY2()
        e.w = self.w / 5
        e.h = o
        self.bt_toEnvelop:setBoundsFromRect(e)
        e.x = e:getX2()
        self.bt_toggleBypassEnv:setBoundsFromRect(e)
        e.x = e:getX2()
        self.bt_toggleInlaneEnv:setBoundsFromRect(e)
        e.x = e:getX2()
        self.bt_toggleVisible:setBoundsFromRect(e)
        e.x = e:getX2()
        self.bt_clearTimeSelectionEnv:setBoundsFromRect(e)
        self.bt_toEnvelop:reduce_2(n, n, t, 0)
        self.bt_toggleInlaneEnv:reduce_2(0, n, t, 0)
        self.bt_toggleBypassEnv:reduce_2(0, n, t, 0)
        self.bt_clearTimeSelectionEnv:reduce_2(0, n, t, 0)
        self.bt_toggleVisible:reduce_2(0, n, t, 0)
    end
    function e:onUpdate(e)
    end
    function e:onDraw(n, e)
        e:fillAll(self:getColor("black"))
        self:_checkFocusFxInfo(e)
        self:_drawBorder(e)
    end
    function e:_init()
        self:_createSlider()
        self:_createFxPanel()
        self:_createFocusInfo()
        self:_createButton()
    end
    function e:_createButton()
        self.bt_toEnvelop = createButton("toEnvelope")
        self.bt_toggleVisible = createButton("visible(A)")
        self.bt_clearTimeSelectionEnv = createButton("clearSel(A)")
        self.bt_toggleBypassEnv = createButton("bypass(A)")
        self.bt_toggleInlaneEnv = createButton("inLane(A)")
        self:addChildComponent(self.bt_toEnvelop)
        self:addChildComponent(self.bt_toggleVisible)
        self:addChildComponent(self.bt_clearTimeSelectionEnv)
        self:addChildComponent(self.bt_toggleBypassEnv)
        self:addChildComponent(self.bt_toggleInlaneEnv)
        self.bt_toEnvelop:setFont("", 14)
        self.bt_toggleVisible:setFont("", 14)
        self.bt_clearTimeSelectionEnv:setFont("", 14)
        self.bt_toggleBypassEnv:setFont("", 14)
        self.bt_toggleInlaneEnv:setFont("", 14)
        self.bt_toggleInlaneEnv:addMouseReleaseFunction(
            function(e, e)
                self.fxPanel_A.fxPreset:toggleAllEnvInLane()
                self:_updateAllArrange()
            end
        )
        self.bt_toggleBypassEnv:addMouseReleaseFunction(
            function(e, e)
                self.fxPanel_A.fxPreset:toggleAllEnvBypass()
                self:_updateAllArrange()
            end
        )
        self.bt_toEnvelop:addMouseReleaseFunction(
            function(e, e)
                if (self:canMorphing() == true) then
                    local e = self.fxPanel_A.fxPreset
                    local n = e:_check_SWS_Function(true)
                    if (n == true) then
                        self._storeIsEnvActive = self.fxPanel_A.fxPreset:IsAllEnvActive()
                    end
                    self:_toMorphParamToEnvelope()
                    self:_morphParameter(self.sl_morph_X:getValue())
                    e:_sendChangeTrackNotify()
                    if (self:_checkIsOverWriteAutoMation() == false) then
                        if (n == true and self._storeIsEnvActive == true) then
                            e:setToAllEnvEnable()
                        end
                    end
                end
                self:_updateAllArrange()
            end
        )
        self.bt_toggleVisible:addMouseReleaseFunction(
            function(e, e)
                self.fxPanel_A.fxPreset:toggleAllEnvVisible()
                self:_updateAllArrange()
            end
        )
        self.bt_clearTimeSelectionEnv:addMouseReleaseFunction(
            function(e, e)
                self.fxPanel_A.fxPreset:presetEnvTimeSelectionClear()
                self:_updateAllArrange()
            end
        )
    end
    function e:_createFxPanel()
        self.fxPanel_A = createPresetPanel("presetPanel_A", "A")
        self.fxPanel_B = createPresetPanel("presetPanel_B", "B")
        self:addChildComponent(self.fxPanel_A)
        self:addChildComponent(self.fxPanel_B)
        local e = self
        self.fxPanel_A:addOnChangeFunction(
            function(n)
                e:_checkUnMatchedParameter()
            end
        )
        self.fxPanel_B:addOnChangeFunction(
            function(n)
                e:_checkUnMatchedParameter()
            end
        )
    end
    function e:_createSlider()
        self.sl_morph_X = createCustomSlider("Morph Width", "", self)
        self:addChildComponent(self.sl_morph_X)
        local e = self
        self.sl_morph_X:addOnValueChangeFunction(
            function(n)
                if (e:canMorphing() == true) then
                    e:_morphParameter(n:getValue())
                end
            end
        )
        self.sl_morph_X:addMousePressFunc(
            function(n)
                local n = e.fxPanel_A.fxPreset
                if (n:_check_SWS_Function(true) == true) then
                    e._storeIsEnvActive = e.fxPanel_A.fxPreset:IsAllEnvActive()
                end
            end
        )
        self.sl_morph_X:addMouseReleaseFunc(
            function(n)
                local n = e.fxPanel_A.fxPreset
                if (e:canMorphing() == true and e:_checkIsOverWriteAutoMation() == false) then
                    if (n:_check_SWS_Function(true) == true and e._storeIsEnvActive == true) then
                        n:setToAllEnvEnable()
                    end
                end
            end
        )
    end
    function e:_createFocusInfo()
        self.focusInfoPanel = createTextPanel()
        self:addChildComponent(self.focusInfoPanel)
        self.focusInfoPanel:setTextMargin(5, 5)
        self.focusInfoPanel:storeColor("text", {1, 1, 1, 1})
        self.focusInfoPanel:storeColor("background", {.2, .2, .2, 1})
    end
    function e:_checkIsOverWriteAutoMation()
        local t = false
        local n = self.fxPanel_A:getFxParams()
        local e = reaper.GetGlobalAutomationOverride()
        local n = reaper.GetMediaTrackInfo_Value(n.targetTrack, "I_AUTOMODE")
        local a = reaper.GetAllProjectPlayStates(0)
        if
            ((a == 1 or a == 4) and e == 2 or e == 3 or e == 4 or (e == -1 and n == 2) or (e == -1 and n == 3) or
                (e == -1 and n == 4))
         then
            t = true
        end
        return t
    end
    function e:_morphParameter(a)
        local n = self.fxPanel_A:getStorePresetTable()
        local r = self.fxPanel_B:getStorePresetTable()
        local e = self.fxPanel_A.fxPreset
        local t = self.fxPanel_B.fxPreset
        if (e:isSameFx(t) == false) then
            return
        end
        n = self:_getUnMatchedParameter()
        if (self:_checkIsOverWriteAutoMation() == true) then
            if (e:_check_SWS_Function(true)) then
                e:setToAllEnvEnable()
            end
        else
            if (e:_check_SWS_Function(true)) then
                e:setToAllEnvBypass()
            end
        end
        for n, t in ipairs(n) do
            local o = t.fxPramValue
            local n = r[t.fxPramID + 1].fxPramValue
            local n = o * (1 - a) + n * (a)
            if (n > 1) then
                n = 1
            end
            if (n < 0) then
                n = 0
            end
            reaper.TrackFX_SetParamNormalized(e.targetTrack, t.trackFxID, t.fxPramID, n)
        end
    end
    function e:_checkFocusFxInfo(e)
        self.focusCheckFx:storeBasePreset()
        local n = tostring(self.focusCheckFx.storeTrackID)
        local e = tostring(self.focusCheckFx.storeFxID)
        local t = tostring(self.focusCheckFx.storeFxName)
        local n = "Track Number: " .. n .. ":" .. e .. ":"
        local e = "FX Name: " .. t
        self.focusInfoPanel:setFont("", 15)
        self.focusInfoPanel:setDrawTexts({n, e})
    end
    function e:_drawBorder(n)
        if
            (self._lastFx_Name ~= self.focusCheckFx.storeFxName or self._lastTrackID ~= self.focusCheckFx.storeTrackID or
                self._lastFxID ~= self.focusCheckFx.storeFxID)
         then
            self._hueOffset = self._hueOffset + 60
            if (self._hueOffset > 360) then
                self._hueOffset = 0
            end
            self._lastFx_Name = self.focusCheckFx.storeFxName
            self._lastTrackID = self.focusCheckFx.storeTrackID
            self._lastFxID = self.focusCheckFx.storeFxID
        end
        local e = c
        local a = n.w / e
        local t = 1 / e
        for t = 1, e do
            local r, o, e = HSVToRGB(_ + self._hueOffset + m * (t / e), f, u)
            gfx.set(r / 255, o / 255, e / 255, 1 * self._componentAlpha)
            gfx.rect(n.x + a * (t - 1) - 1, n.y, a + 5, i, true)
        end
    end
    function e:_toMorphParamToEnvelope()
        local e = self.fxPanel_A:getStorePresetTable()
        local t = self.fxPanel_B:getStorePresetTable()
        local n = self.fxPanel_A.fxPreset
        local a = self.fxPanel_B.fxPreset
        if (n:isSameFx(a) == false) then
            return
        end
        e = self:_getUnMatchedParameter()
        local n = self.sl_morph_X:getValue()
        local o = reaper.GetCursorPosition()
        for a, e in ipairs(e) do
            if (e.fxPramName ~= "bypass") then
                local a = e.fxPramValue
                local t = t[e.fxPramID + 1].fxPramValue
                local n = a * (1 - n) + t * (n)
                if (n > 1) then
                    n = 1
                end
                if (n < 0) then
                    n = 0
                end
                local r, t, a, r = reaper.TrackFX_GetParamEx(e.targetTrack, e.trackFxID, e.fxPramID)
                local a = a - t
                local n = t + a * n
                local e = reaper.GetFXEnvelope(e.targetTrack, e.trackFxID, e.fxPramID, true)
                reaper.PreventUIRefresh(2)
                reaper.InsertEnvelopePoint(e, o, n, 0, 1, false, false)
                reaper.Envelope_SortPoints(e)
                reaper.PreventUIRefresh(-1)
            end
        end
        self:_updateAllArrange()
    end
    function e:_updateAllArrange()
        reaper.UpdateArrange()
        reaper.UpdateTimeline()
        reaper.TrackList_UpdateAllExternalSurfaces()
    end
    function e:_getUnMatchedParameter()
        return self._unMatchedParameters
    end
    function e:_checkUnMatchedParameter()
        self._unMatchedParameters = {}
        local o = self.fxPanel_A:getStorePresetTable()
        local a = self.fxPanel_B:getStorePresetTable()
        local n = self.fxPanel_A.fxPreset
        local t = self.fxPanel_B.fxPreset
        if (n:isSameFx(t) == false) then
            return
        end
        for n, e in ipairs(o) do
            if (e.fxPramName ~= "bypass" and e.fxPramValue ~= a[n].fxPramValue) then
                table.insert(self._unMatchedParameters, e)
            end
        end
    end
    e:_init()
    return e
end
function r()
    local e = createApp("Fx Morph Type 2", 480, 250)
    local n = createFxMorph_2(e, "panel")
    e:addChildComponent(n)
    if (x) then
        e:toggleDock()
    end
    e:runLoop()
end
if (_INCLUDE_MODE_ ~= true) then
    r()
end
_INCLUDE_MODE_ = true
if (package.config:sub(1, 1) == "\\") then
else
end
local c = false
local e = false
local o = 5
local t = 5
local i = 5
local d = 60
local f = 60
local s = 1
local u = 1
local _ = 5
o = 4
t = 4
function createCustomXYSlider()
    local e = createXYSlider()
    e._mouseReleaseFunc = {}
    e._mousePressFunc = {}
    function e:addMouseReleaseFunc(e)
        local n = table.doubleCheck(self._mouseReleaseFunc, e)
        if (n == false) then
            table.insert(self._mouseReleaseFunc, e)
        end
    end
    function e:addMousePressFunc(e)
        local n = table.doubleCheck(self._mousePressFunc, e)
        if (n == false) then
            table.insert(self._mousePressFunc, e)
        end
    end
    function e:onMousePress(e)
        for n, e in ipairs(self._mousePressFunc) do
            e(self)
        end
    end
    function e:onMouseRelease(e)
        if (self.isStartInMouseDown == true) then
            for n, e in ipairs(self._mouseReleaseFunc) do
                e(self)
            end
        end
    end
    return e
end
function createFxMorph_4(e)
    local e = createComponent(e)
    e.focusCheckFx = createFxParams()
    e.focusInfoPanel = nil
    e.fxPanel_A = nil
    e.fxPanel_B = nil
    e.fxPanel_C = nil
    e.fxPanel_D = nil
    e.xySlider = nil
    e._lastFx_Name = nil
    e._lastTrackID = nil
    e._lastFxID = nil
    e._hueOffset = 0
    e._unMatchedParameters = {}
    e.bt_toEnvelop = nil
    e.bt_toggleVisible = nil
    e.bt_clearTimeSelection = nil
    e.bt_toggleBypassEnv = nil
    e.bt_toggleInlaneEnv = nil
    function e:canMorphing()
        local e = self.fxPanel_A.fxPreset
        local n = self.fxPanel_B.fxPreset
        local a = self.fxPanel_C.fxPreset
        local t = self.fxPanel_D.fxPreset
        local o = (e:isSameFx(n) == true and e:isSameFx(a) == true and e:isSameFx(t) == true)
        local e =
            (e:isExistTrackFx() == true and n:isExistTrackFx() == true and a:isExistTrackFx() == true and
            t:isExistTrackFx() == true)
        return (o == true and e == true)
    end
    function e:onResized()
        local n = 5
        local e = 50
        local a = createRectangle()
        a.x = self.x
        a.y = self.y + i
        a.w = (self.w)
        a.h = e
        self.focusInfoPanel:setBoundsFromRect(a)
        local r = ((self:getY2() - a:getY2()) / 2) / n
        local n = createRectangle()
        n.x = self.x
        n.y = a:getY2()
        n.w = (self.w)
        n.h = r
        self.fxPanel_A:setBoundsFromRect(n)
        n.y = n:getY2()
        self.fxPanel_B:setBoundsFromRect(n)
        n.y = n:getY2()
        self.fxPanel_C:setBoundsFromRect(n)
        n.y = n:getY2()
        self.fxPanel_D:setBoundsFromRect(n)
        local e = o
        local t = t
        self.focusInfoPanel:reduce_2(e, e, t, t)
        self.fxPanel_A:reduce_2(e, e, 0, t)
        self.fxPanel_B:reduce_2(e, e, 0, t)
        self.fxPanel_C:reduce_2(e, e, 0, t)
        self.fxPanel_D:reduce_2(e, e, 0, t)
        local o = createRectangle()
        local a = (self:getY2() - a:getY2()) / 2
        o.x = self.x
        o.y = n:getY2()
        o.w = self.w
        o.h = a
        self.xySlider:setBoundsFromRect(o)
        self.xySlider:reduce_2(e, e, 0, t)
        local n = createRectangle()
        n.x = self.x
        n.y = o:getY2()
        n.w = self.w / 5
        n.h = r
        self.bt_toEnvelop:setBoundsFromRect(n)
        n.x = n:getX2()
        self.bt_toggleBypassEnv:setBoundsFromRect(n)
        n.x = n:getX2()
        self.bt_toggleInlaneEnv:setBoundsFromRect(n)
        n.x = n:getX2()
        self.bt_toggleVisible:setBoundsFromRect(n)
        n.x = n:getX2()
        self.bt_clearTimeSelectionEnv:setBoundsFromRect(n)
        self.bt_toEnvelop:reduce_2(e, e, 0, t)
        self.bt_toggleInlaneEnv:reduce_2(0, e, 0, t)
        self.bt_toggleBypassEnv:reduce_2(0, e, 0, t)
        self.bt_clearTimeSelectionEnv:reduce_2(0, e, 0, t)
        self.bt_toggleVisible:reduce_2(0, e, 0, t)
    end
    function e:onDraw(n, e)
        e:fillAll(self:getColor("black"))
        self:_checkFocusFxInfo()
        self:_drawBorder(e)
    end
    function e:_init()
        self:_createSlider()
        self:_createButton()
        self:_createFxPanel()
        self:_createFocusInfo()
        self:needRedraw(true)
    end
    function e:_createButton()
        self.bt_toEnvelop = createButton("toEnvelope")
        self.bt_toggleVisible = createButton("visible(A)")
        self.bt_clearTimeSelectionEnv = createButton("clearSel(A)")
        self.bt_toggleBypassEnv = createButton("Bypass(A)")
        self.bt_toggleInlaneEnv = createButton("inLane(A)")
        self:addChildComponent(self.bt_toEnvelop)
        self:addChildComponent(self.bt_toggleVisible)
        self:addChildComponent(self.bt_clearTimeSelectionEnv)
        self:addChildComponent(self.bt_toggleBypassEnv)
        self:addChildComponent(self.bt_toggleInlaneEnv)
        self.bt_toEnvelop:setFont("", 14)
        self.bt_toggleVisible:setFont("", 14)
        self.bt_clearTimeSelectionEnv:setFont("", 14)
        self.bt_toggleBypassEnv:setFont("", 14)
        self.bt_toggleInlaneEnv:setFont("", 14)
        self.bt_toggleInlaneEnv:addMouseReleaseFunction(
            function(e, e)
                self.fxPanel_A.fxPreset:toggleAllEnvInLane()
                self:_updateAllArrange()
            end
        )
        self.bt_toggleBypassEnv:addMouseReleaseFunction(
            function(e, e)
                self.fxPanel_A.fxPreset:toggleAllEnvBypass()
                self:_updateAllArrange()
            end
        )
        self.bt_toEnvelop:addMouseReleaseFunction(
            function(e, e)
                if (self:canMorphing() == true) then
                    local e = self.fxPanel_A.fxPreset
                    local n = e:_check_SWS_Function(true)
                    if (n == true) then
                        self._storeIsEnvActive = self.fxPanel_A.fxPreset:IsAllEnvActive()
                    end
                    self:_toMorphParamToEnvelope()
                    self:_morphParameter()
                    e:_sendChangeTrackNotify()
                    if (self:_checkIsOverWriteAutoMation() == false) then
                        if (n == true and self._storeIsEnvActive == true) then
                            e:setToAllEnvEnable()
                        end
                    end
                end
                self:_updateAllArrange()
            end
        )
        self.bt_toggleVisible:addMouseReleaseFunction(
            function(e, e)
                self.fxPanel_A.fxPreset:toggleAllEnvVisible()
                self:_updateAllArrange()
            end
        )
        self.bt_clearTimeSelectionEnv:addMouseReleaseFunction(
            function(e, e)
                self.fxPanel_A.fxPreset:presetEnvTimeSelectionClear()
                self:_updateAllArrange()
            end
        )
    end
    function e:_createFxPanel()
        self.fxPanel_A = createPresetPanel("presetPanel_A", "A")
        self.fxPanel_B = createPresetPanel("presetPanel_B", "B")
        self.fxPanel_C = createPresetPanel("presetPanel_C", "C")
        self.fxPanel_D = createPresetPanel("presetPanel_D", "D")
        self:addChildComponent(self.fxPanel_A)
        self:addChildComponent(self.fxPanel_B)
        self:addChildComponent(self.fxPanel_C)
        self:addChildComponent(self.fxPanel_D)
        local e = self
        local e = function(n)
            e:_callback_CheckFx(n)
        end
        self.fxPanel_A:addOnChangeFunction(e)
        self.fxPanel_B:addOnChangeFunction(e)
        self.fxPanel_C:addOnChangeFunction(e)
        self.fxPanel_D:addOnChangeFunction(e)
    end
    function e:_createSlider()
        self.xySlider = createCustomXYSlider("xySlider")
        self:addChildComponent(self.xySlider)
        local e = self
        self.xySlider:addOnValueChangeFunction(
            function(n)
                if (e:canMorphing() == true) then
                    e:_morphParameter()
                    e.xySlider:setLabelTable(self:_calcSliderLabel())
                end
            end
        )
        self.xySlider:addMousePressFunc(
            function(n)
                local n = e.fxPanel_A.fxPreset
                if (n:_check_SWS_Function(true) == true) then
                    e._storeIsEnvActive = e.fxPanel_A.fxPreset:IsAllEnvActive()
                end
            end
        )
        self.xySlider:addMouseReleaseFunc(
            function(n)
                local n = e.fxPanel_A.fxPreset
                if (e:canMorphing() == true and e:_checkIsOverWriteAutoMation() == false) then
                    if (n:_check_SWS_Function(true) and e._storeIsEnvActive == true) then
                        n:setToAllEnvEnable()
                    end
                end
            end
        )
        self.xySlider:setLabelTable({"---", "---", "---", "---"})
    end
    function e:_createFocusInfo()
        self.focusInfoPanel = createTextPanel()
        self:addChildComponent(self.focusInfoPanel)
        self.focusInfoPanel:setTextMargin(5, 5)
        self.focusInfoPanel:storeColor("text", {1, 1, 1, 1})
        self.focusInfoPanel:storeColor("background", {.2, .2, .2, 1})
    end
    function e:_checkIsOverWriteAutoMation()
        local a = false
        local n = self.fxPanel_A:getFxParams()
        local e = reaper.GetGlobalAutomationOverride()
        local n = reaper.GetMediaTrackInfo_Value(n.targetTrack, "I_AUTOMODE")
        local t = reaper.GetAllProjectPlayStates(0)
        if
            ((t == 1 or t == 4) and e == 2 or e == 3 or e == 4 or (e == -1 and n == 2) or (e == -1 and n == 3) or
                (e == -1 and n == 4))
         then
            a = true
        end
        return a
    end
    function e:_morphParameter()
        local e = self.fxPanel_A:getFxParams()
        if (e:checkActive() == false) then
            return
        end
        local n = self.fxPanel_A:getStorePresetTable()
        local o = self.fxPanel_B:getStorePresetTable()
        local i = self.fxPanel_C:getStorePresetTable()
        local c = self.fxPanel_D:getStorePresetTable()
        local t = self.xySlider:getXValue()
        local l = self.xySlider:getYValue()
        n = self:_getUnMatchedParameter()
        local a = e:_check_SWS_Function(true)
        if (self:_checkIsOverWriteAutoMation() == true) then
            if (a == true) then
                e:setToAllEnvEnable()
            end
        else
            if (a == true) then
                e:setToAllEnvBypass()
            end
        end
        for a, n in ipairs(n) do
            local a = n.fxPramID + 1
            local r = n.fxPramValue
            local o = o[a].fxPramValue
            local i = i[a].fxPramValue
            local c = c[a].fxPramValue
            local a = o - r
            local a = r * (1 - t) + o * t
            local t = c * (1 - t) + i * t
            newValue = a * (1 - l) + t * l
            if (newValue > 1) then
                newValue = 1
            end
            if (newValue < 0) then
                newValue = 0
            end
            reaper.TrackFX_SetParamNormalized(e.targetTrack, n.trackFxID, n.fxPramID, newValue)
        end
    end
    function e:_toMorphParamToEnvelope()
        local e = self.fxPanel_A:getFxParams()
        if (e:checkActive() == false) then
            return
        end
        local e = self.fxPanel_A:getStorePresetTable()
        local r = self.fxPanel_B:getStorePresetTable()
        local i = self.fxPanel_C:getStorePresetTable()
        local l = self.fxPanel_D:getStorePresetTable()
        local n = self.xySlider:getXValue()
        local a = self.xySlider:getYValue()
        e = self:_getUnMatchedParameter()
        local c = reaper.GetCursorPosition()
        for t, e in ipairs(e) do
            if (e.fxPramName ~= "bypass") then
                local t = e.fxPramID + 1
                local o = e.fxPramValue
                local r = r[t].fxPramValue
                local i = i[t].fxPramValue
                local t = l[t].fxPramValue
                local l = r - o
                local o = o * (1 - n) + r * n
                local n = t * (1 - n) + i * n
                newValue = o * (1 - a) + n * a
                if (newValue > 1) then
                    newValue = 1
                end
                if (newValue < 0) then
                    newValue = 0
                end
                local a, n, t, a = reaper.TrackFX_GetParamEx(e.targetTrack, e.trackFxID, e.fxPramID)
                local t = t - n
                local n = n + t * newValue
                local e = reaper.GetFXEnvelope(e.targetTrack, e.trackFxID, e.fxPramID, true)
                reaper.PreventUIRefresh(2)
                reaper.InsertEnvelopePoint(e, c, n, 0, 1, false, false)
                reaper.Envelope_SortPoints(e)
                reaper.PreventUIRefresh(-1)
                local function n()
                    local t, n = reaper.GetEnvelopeStateChunk(e, "", false)
                    local n = string.split(n, "\n")
                    for t, e in ipairs(n) do
                        if (string.match(e, "VIS")) then
                            n[t] = "VIS 1 1 0 "
                        end
                    end
                    local function t(n)
                        local e = ""
                        for t, n in ipairs(n) do
                            e = e .. n .. " \n"
                        end
                        return e
                    end
                    local n = t(n)
                    reaper.SetEnvelopeStateChunk(e, n, false)
                end
            end
        end
        reaper.UpdateArrange()
        reaper.UpdateTimeline()
    end
    function e:_checkFocusFxInfo()
        self.focusCheckFx:storeBasePreset()
        local e = tostring(self.focusCheckFx.storeTrackID)
        local n = tostring(self.focusCheckFx.storeFxID)
        local t = tostring(self.focusCheckFx.storeFxName)
        local e = "Track Number: " .. e .. ":" .. n .. ":"
        local n = "FX Name: " .. t
        self.focusInfoPanel:setFont("", 15)
        self.focusInfoPanel:setDrawTexts({e, n})
    end
    function e:_drawBorder(a)
        if
            (self._lastFx_Name ~= self.focusCheckFx.lastFxName or self._lastTrackID ~= self.focusCheckFx.lastTrackID or
                self._lastFxID ~= self.focusCheckFx.lastFxID)
         then
            self._hueOffset = math.random() * 360
            self._lastFx_Name = self.focusCheckFx.lastFxName
            self._lastTrackID = self.focusCheckFx.lastTrackID
            self._lastFxID = self.focusCheckFx.lastFxID
        end
        local e = _
        local t = a.w / e
        local n = 1 / e
        for n = 1, e do
            local e, r, o = HSVToRGB(d + self._hueOffset + f * (n / e), u, s)
            gfx.set(e / 255, r / 255, o / 255, 1 * self._componentAlpha)
            gfx.rect(t * (n - 1) - 1, a.y, t + 5, i, true)
        end
    end
    function e:_callback_CheckFx(e)
        if (self:canMorphing() == false) then
            self.xySlider:setLabelTable({"---", "---", "---", "---"})
            self.xySlider:setCursolColor({1, 1, 1, 1})
        else
            self.xySlider:setLabelTable(self:_calcSliderLabel())
            local e = math.floor(360 * math.random())
            local e, t, n = HSVToRGB(e, .8, 1)
            e, t, n = e / 255, t / 255, n / 255
            self.xySlider:setCursolColor({e, t, n, 1})
            self:_checkUnMatchedParameter()
        end
    end
    function e:_calcSliderLabel()
        local e = self.xySlider:getXValue()
        local n = self.xySlider:getYValue()
        local o = (1 - e)
        local a = (e)
        local t = (e)
        local e = (1 - e)
        o = o * (1 - n) * 100
        a = a * (1 - n) * 100
        t = t * (n) * 100
        e = e * (n) * 100
        return {
            "A:" .. string.format("%3.0f%%", o),
            "B:" .. string.format("%3.0f%%", a),
            "C:" .. string.format("%3.0f%%", t),
            "D:" .. string.format("%3.0f%%", e)
        }
    end
    function e:_getUnMatchedParameter()
        return self._unMatchedParameters
    end
    function e:_checkUnMatchedParameter()
        self._unMatchedParameters = {}
        if (self.fxPanel_A.fxPreset:checkActive() == false) then
            return
        end
        local e = self.fxPanel_A:getStorePresetTable()
        local t = self.fxPanel_B:getStorePresetTable()
        local a = self.fxPanel_C:getStorePresetTable()
        local o = self.fxPanel_D:getStorePresetTable()
        for e, n in ipairs(e) do
            if (n.fxPramName ~= "bypass") then
                local e =
                    (n.fxPramValue == t[e].fxPramValue and t[e].fxPramValue == a[e].fxPramValue and
                    a[e].fxPramValue == o[e].fxPramValue)
                if (e == false) then
                    table.insert(self._unMatchedParameters, n)
                end
            end
        end
    end
    function e:_updateAllArrange()
        reaper.UpdateArrange()
        reaper.UpdateTimeline()
        reaper.TrackList_UpdateAllExternalSurfaces()
    end
    e:_init()
    return e
end
function r()
    local e = createApp("Fx Morph Type 4", 500, 550)
    local n = createFxMorph_4(e, "panel")
    e:addChildComponent(n)
    if (c) then
        e:toggleDock()
    end
    e:runLoop()
end
if (_INCLUDE_MODE_2 ~= true) then
    r()
end
local n = createApp("FxToolSet", 651, 580)
local e = createTabComponent("top Tab Component")
e:addTab("FxRandomiza", createFxRandomizaComponent())
e:addTab("FxMorph2", createFxMorph_2())
e:addTab("FxMorph4", createFxMorph_4())
e:changeTab("FxMorph4")
e:setButtonMargin(3, 3, 3, 4)
n:addChildComponent(e)
n:runLoop()
