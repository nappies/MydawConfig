--[[ 
* ReaScript Name: kawa_MIDI_GenerateRandomArp. 
* Version: 2017/02/09 
* Author: kawa_ 
* Author URI: http://forum.cockos.com/member.php?u=105939 
* link: https://bitbucket.org/kawaCat/reascript-m2bpack/ 
--]]
if (package.config:sub(1, 1) == "\\") then
end
math.randomseed(reaper.time_precise() * os.time() / 1e3)
local n = 40815
local i = 40659
function deepcopy(t)
    local n = type(t)
    local e
    if n == "table" then
        e = {}
        for n, t in next, t, nil do
            e[deepcopy(n)] = deepcopy(t)
        end
        setmetatable(e, deepcopy(getmetatable(t)))
    else
        e = t
    end
    return e
end
function createMIDIFunc3(m)
    local e = {}
    e.allNotes = {}
    e.selectedNotes = {}
    e._editingNotes_Original = {}
    e.editingNotes = {}
    e.editorHwnd = nil
    e.take = nil
    e.mediaItem = nil
    e.mediaTrack = nil
    e._limitMaxCount = 1e3
    e._isSafeLimit = true
    function e:_showLimitNoteMsg()
        reaper.ShowMessageBox("over " .. tostring(self._limitMaxCount) .. " clip num .\nstop process", "stop.", 0)
    end
    function e:getMidiNotes()
        reaper.PreventUIRefresh(2)
        reaper.MIDIEditor_OnCommand(self.editorHwnd, n)
        reaper.MIDIEditor_OnCommand(self.editorHwnd, i)
        reaper.PreventUIRefresh(-1)
        local r = {}
        local o = {}
        local p, a, c, t, n, s, i, d = reaper.MIDI_GetNote(self.take, 0)
        local e = 0
        while p do
            t = reaper.MIDI_GetProjQNFromPPQPos(self.take, t)
            n = reaper.MIDI_GetProjQNFromPPQPos(self.take, n)
            local l = {
                selection = a,
                mute = c,
                startQn = t,
                endQn = n,
                chan = s,
                pitch = i,
                vel = d,
                take = self.take,
                idx = e,
                length = n - t
            }
            table.insert(r, l)
            if (a == true) then
                table.insert(o, l)
            end
            e = e + 1
            p, a, c, t, n, s, i, d = reaper.MIDI_GetNote(self.take, e)
            if (e > self._limitMaxCount) then
                r = {}
                o = {}
                self:_showLimitNoteMsg()
                self._isSafeLimit = false
                break
            end
        end
        self.m_existMaxNoteIdx = e
        return r, o
    end
    function e:detectTargetNote()
        if (self._isSafeLimit == false) then
            return {}
        end
        if (#self.selectedNotes >= 1) then
            self._editingNotes_Original = deepcopy(self.selectedNotes)
            self.editingNotes = deepcopy(self.selectedNotes)
            return self.editingNotes
        else
            self._editingNotes_Original = deepcopy(self.allNotes)
            self.editingNotes = deepcopy(self.allNotes)
            return self.editingNotes
        end
    end
    function e:correctOverWrap()
        reaper.MIDIEditor_OnCommand(self.editorHwnd, i)
    end
    function e:flush(t, e)
        self:_deleteAllOriginalNote()
        self:_editingNoteToMediaItem(t)
        self:correctOverWrap()
        if (e == true) then
            reaper.MIDI_Sort(self.take)
        end
    end
    function e:insertNoteFromC(e)
        e.idx = self.m_existMaxNoteIdx + 1
        self.m_existMaxNoteIdx = self.m_existMaxNoteIdx + 1
        table.insert(self.editingNotes, e)
        return e
    end
    function e:insertNotesFromC(e)
        for t, e in ipairs(e) do
            self:insertNoteFromC(e)
        end
        return e
    end
    function e:insertMidiNote(o, n, t, e, a, r, i)
        local t = t
        local e = e
        local n = n
        local a = a or false
        local i = i or false
        local r = r or 1
        local o = o
        local l = self.m_existMaxNoteIdx + 1
        self.m_existMaxNoteIdx = self.m_existMaxNoteIdx + 1
        local e = {
            selection = a,
            mute = i,
            startQn = t,
            endQn = e,
            chan = r,
            pitch = o,
            vel = n,
            take = self.take,
            idx = l,
            length = e - t
        }
        table.insert(self.editingNotes, e)
    end
    function e:deleteNote(n)
        for t, e in ipairs(self.editingNotes) do
            if (e.idx == n.idx) then
                table.remove(self.editingNotes, t)
                break
            end
        end
    end
    function e:deleteNotes(e)
        if (e == self.editingNotes) then
            self.editingNotes = {}
            return
        end
        for t, e in ipairs(e) do
            self:deleteNote(e)
        end
    end
    function e:_init(e)
        self.editorHwnd = reaper.MIDIEditor_GetActive()
        self.take = e or reaper.MIDIEditor_GetTake(self.editorHwnd)
        if (self.take == nil) then
            return
        end
        self.allNotes, self.selectedNotes = self:getMidiNotes()
        self.mediaItem = reaper.GetMediaItemTake_Item(self.take)
        self.mediaTrack = reaper.GetMediaItemTrack(self.mediaItem)
    end
    function e:_deleteAllOriginalNote(e)
        local e = e or self._editingNotes_Original
        while (#e > 0) do
            local t = #e
            reaper.MIDI_DeleteNote(e[t].take, e[t].idx)
            table.remove(e, #e)
        end
    end
    function e:_insertNoteToMediaItem(e, n)
        local t = self.take
        if t == nil then
            return
        end
        local c = e.selection or false
        local s = e.mute
        local l = reaper.MIDI_GetPPQPosFromProjQN(t, e.startQn)
        local d = reaper.MIDI_GetPPQPosFromProjQN(t, e.endQn)
        local i = e.chan
        local r = e.pitch
        local a = e.vel
        local e = 0
        if (n == true) then
            local n = .9
            local o = reaper.MIDI_GetProjQNFromPPQPos(t, n)
            local t = reaper.MIDI_GetProjQNFromPPQPos(t, n * 2)
            e = t - o
        end
        reaper.MIDI_InsertNote(t, c, s, l, d - e, i, r, a, true)
    end
    function e:_editingNoteToMediaItem(t)
        for n, e in ipairs(self.editingNotes) do
            self:_insertNoteToMediaItem(e, t)
        end
    end
    e:_init(m)
    return e
end
if (package.config:sub(1, 1) == "\\") then
end
local l = "kawa MIDI Generate Random Arp"
if (l == reaper.Undo_CanUndo2(0)) then
    reaper.PreventUIRefresh(30)
    reaper.Undo_DoUndo2(0)
    reaper.UpdateArrange()
    reaper.PreventUIRefresh(-1)
end
local function o(t)
    local e = 0
    for n, t in ipairs(t) do
        e = math.max(e or t.length, t.length)
    end
    return e
end
local function r(t)
    local e = {}
    for t, n in ipairs(t) do
        local t = n.startQn
        if (e[t] == nil) then
            e[t] = {}
            e[t].startQn = startpos
            e[t].notes = {}
        end
        table.insert(e[t].notes, n)
    end
    return e
end
local function p()
    local a = createMIDIFunc3()
    local t = a:detectTargetNote()
    if (#t < 1 or a.take == nil) then
        return
    end
    local e, n, n = reaper.MIDI_GetGrid(a.take)
    local c = {}
    local d = {}
    local t = r(t)
    for t, n in pairs(t) do
        local t = #n.notes
        if (t >= 1 and e < o(n.notes)) then
            local o = o(n.notes)
            local s = math.floor(o / e)
            local a = n.notes[1].startQn
            local r = e * .99999
            local o = 1
            local function l()
                o = o + 1
                if (o > t) then
                    o = 1
                end
            end
            table.sort(
                n.notes,
                function(e, t)
                    return (e.pitch < t.pitch)
                end
            )
            local i = o
            for e = 1, s, 1 do
                local e = math.floor(math.random(1, t))
                e = math.max(math.min(e, t), 1)
                while (i == e and t > 2) do
                    e = math.floor(math.random() * t)
                    e = math.max(math.min(e, t), 1)
                end
                i = e
                o = e
                local e = deepcopy(n.notes[o])
                e.length = r
                e.startQn = a
                e.endQn = e.startQn + e.length
                a = a + r
                table.insert(c, e)
                l()
            end
            for t, e in ipairs(n.notes) do
                table.insert(d, e)
            end
        end
    end
    a:deleteNotes(d)
    a:insertNotesFromC(c)
    a:flush(true, true)
    reaper.Undo_OnStateChange2(0, l)
end
p()

