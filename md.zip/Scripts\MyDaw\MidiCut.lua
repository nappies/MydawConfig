function m(s)
  reaper.ShowConsoleMsg(tostring(s) .. "\n")
end


function IsEventsInTs()
notes_ints=0
cc_ints=0
local x_ts, y_ts = reaper.GetSet_LoopTimeRange(0, 0, 0, 0, 0)
if x_ts and y_ts and x_ts ~= y_ts then
  local editor = reaper.MIDIEditor_GetActive()
  local take = reaper.MIDIEditor_GetTake(reaper.MIDIEditor_GetActive())
  if take then
    local  _,notes,ccs,_ = reaper.MIDI_CountEvts(take)  
    local x_ts = reaper.MIDI_GetPPQPosFromProjTime(take, x_ts)
    local y_ts =reaper.MIDI_GetPPQPosFromProjTime(take, y_ts)
    if notes > 0 then
              for n = notes-1, 0, -1 do
        local _, _, _, x, y = reaper.MIDI_GetNote(take, n)
        if (x < y_ts and x > x_ts) or (y > x_ts and y < y_ts) or (x <= x_ts and y >= y_ts) then
          notes_ints=1
        end
      end     
    end
   if ccs > 0 then
        for c = ccs-1, 0, -1 do
        local _, _, _, x, y = reaper.MIDI_GetCC(take, c)
        if (x < y_ts and x > x_ts) or (y > x_ts and y < y_ts) or (x <= x_ts and y >= y_ts) then
          cc_ints=1
        end
      end
    end      
  end
end
return notes_ints,cc_ints   
end


function IsEventsSel()
selnote = 0 
selcc = 0

  take = reaper.MIDIEditor_GetTake(reaper.MIDIEditor_GetActive())                     
  if take == nil then return end                                                    
  retval,count_notes,ccs,sysex = reaper.MIDI_CountEvts(take)                            
  for i = 0,count_notes do                                                                
  local _, snote, _, _, _, _, _, _ = reaper.MIDI_GetNote(take,i-1)
    if snote then selnote = 1   break                                           
    end
  end
  for i = 0,ccs do                                                                
  local  _, scc, _, _, _, _, _, _ = reaper.MIDI_GetCC( take, i-1 )
    if scc  then selcc = 1   break                                           
    end
  end
return selnote, selcc 
end



function jsUnselectNotInTime()
local s_unpack = string.unpack
local s_pack   = string.pack

timeSelStart, timeSelEnd = reaper.GetSet_LoopTimeRange2(0, false, false, 0, 0, false)

numItems = reaper.CountMediaItems(0)
for i=0, numItems-1 do 

    curItem = reaper.GetMediaItem(0, i)
    if reaper.ValidatePtr2(0, curItem, "MediaItem*") then 
    
        local itemStartTime = reaper.GetMediaItemInfo_Value(curItem, "D_POSITION")
        local itemEndTime   = itemStartTime + reaper.GetMediaItemInfo_Value(curItem, "D_LENGTH")
    
        numTakes = reaper.CountTakes(curItem)  
        for t=0, numTakes-1 do 
        
            curTake = reaper.GetTake(curItem, t)    
            if reaper.ValidatePtr2(0, curTake, "MediaItem_Take*") and reaper.TakeIsMIDI(curTake) then 
            
                if itemStartTime >= timeSelEnd or itemEndTime <= timeSelStart then
                    reaper.MIDI_SelectAll(curTake, false)
                    
                else
                    local gotAllOK, MIDIstring = reaper.MIDI_GetAllEvts(curTake, "")
                    if not gotAllOK then
                        local trackName, _ = reaper.GetTrackState(reaper.GetMediaItemTake_Track(curTake))
                        reaper.ShowMessageBox("The script could not load the raw MIDI data of the following take:"
                                              .. reaper.GetTakeName(curTake)
                                              .. "'\nin the track: \n  '"
                                              .. trackName
                                              , "ERROR", 0)
                        reaper.Undo_EndBlock2(0, "INCOMPLETE: Deselect all MIDI events outside time selection (from all tracks)", -1)
                        return false
                    else                 
    
                        local timeSelStartPPQinTake = reaper.MIDI_GetPPQPosFromProjTime(curTake, timeSelStart)
                        local timeSelEndPPQinTake = reaper.MIDI_GetPPQPosFromProjTime(curTake, timeSelEnd) 
                               
                        local tableEvents = {} -- All events will be stored in this table until they are concatened again
                        local t = 0 -- Count index in table.  It is faster to use tableEvents[t] = ... than table.insert(...
                        
                        local countDeselects = 0
                        
                        -- Notes are problematic, since the decision whether to deselect a note-on can only be made once the position of
                        --    the matching note-off is known.  Similarly, the decision whether to deselect a note-off depends on the 
                        --    position of the preceding note-on.
                        -- This table will be used to store the decision of whether the note-on has been deselected, for each channel and pitch.
                        --    If true, then the next matching note-off must also be deselected.
                        --    If false, then remain selected.
                        --    If nil, then there is no running note (i.e. no preceding note-on that has ot already been matched to a note-off).
                        local tableDeselectNextNoteOff = {} 
                        for flags = 0, 3 do
                            tableDeselectNextNoteOff[flags] = {}
                            for chan = 0, 15 do
                                tableDeselectNextNoteOff[flags][chan] = {}
                            end
                        end
                                     
                        -- The script will speed up execution by not inserting each event individually into tableEvents as they are parsed.
                        --    Instead, only changed (i.e. deselected) events will be re-packed and inserted individually, while unchanged events
                        --    will be inserted as bulk blocks of unchanged sub-strings.
                        local nextPos, prevPos, unchangedPos = 1, 1, 1 -- unchangedPos is starting position of block of unchanged MIDI.
                        local runningPPQpos = 0
                        
                        -- This script should make as little change as possible to the take, so no sorting will be done.
                        -- The script must therefore itarate through all evennts, and cannot quit as soon as an event 
                        --    with PPQ position > timeSelEndPPQinTake is reached.
                        local MIDIlen = MIDIstring:len()
                        while nextPos < MIDIlen do
                        
                            local mustDeselect = false
                            local offset, flags, msg
                            
                            prevPos = nextPos
                            offset, flags, msg, nextPos = s_unpack("i4Bs4", MIDIstring, prevPos)
                            if offset < 0 then
                                local trackName, _ = reaper.GetTrackState(reaper.GetMediaItemTake_Track(curTake))
                                reaper.ShowMessageBox('The script encountered improperly sorted MIDI data at the following position:\n   '
                                                      .. reaper.format_timestr_pos(reaper.MIDI_GetProjTimeFromPPQPos(curTake, runningPPQpos), "", 1)
                                                      .. '\nin the take:\n   "'
                                                      .. reaper.GetTakeName(curTake)
                                                      .. '"\nin the track:\n   "'
                                                      .. trackName
                                                      .. '"\n\nUsually, making any edit to the take in the MIDI editor, even simply selecting a note, will induce the editor to re-sort the MIDI data - '
                                                      .. 'but look out for inadvertent changes to overlapping notes.'
                                                      , "ERROR", 0)
                                reaper.Undo_EndBlock2(0, "INCOMPLETE: Deselect all MIDI events outside time selection (from all tracks)", -1)
                                return false
                            end
                            
                            runningPPQpos = runningPPQpos + offset
                            
                            if flags&1 == 1 then -- First bit in flags is selection status

                                local eventType = msg:byte(1)>>4
                                                                    
                                -- Note-offs
                                if eventType == 8 or (msg:byte(3) == 0 and eventType == 9) then
                                    local channel = msg:byte(1)&0x0F
                                    local pitch   = msg:byte(2)
                                    -- Was there a deselected note-on on this channel and pitch?
                                    if tableDeselectNextNoteOff[flags][channel][pitch] then
                                        mustDeselect = true
                                    end
                                    -- Delete record, so that next note-on doesn't think it is an overlap.
                                    tableDeselectNextNoteOff[flags][channel][pitch] = nil
                                    
                                -- Note-ons
                                elseif eventType == 9 then -- and msg:byte(3) > 0
                                    local channel = msg:byte(1)&0x0F
                                    local pitch   = msg:byte(2)
                                    
                                    -- Check for note overlaps.  nil implies that no running note on this channel and pitch
                                    if tableDeselectNextNoteOff[flags][channel][pitch] ~= nil then
                                        local trackName, _ = reaper.GetTrackState(reaper.GetMediaItemTake_Track(curTake))
                                        reaper.ShowMessageBox('There appears to be overlapping notes among the selected notes. The lengths of such notes cannot be unambiguously determined by the script.'
                                                              .. '\n\nIn particular, at position:\n   '
                                                              .. reaper.format_timestr_pos(reaper.MIDI_GetProjTimeFromPPQPos(curTake, runningPPQpos), "", 1)
                                                              .. '\nin the take: \n   "'
                                                              .. reaper.GetTakeName(curTake)
                                                              .. '"\nin the track: \n   "'
                                                              .. trackName
                                                              .. '"\n\nThe action "Correct overlapping notes" can be used to correct overlapping notes in the MIDI editor.'
                                                              , "ERROR", 0)
                                        reaper.Undo_EndBlock2(0, "INCOMPLETE: Deselect all MIDI events outside time selection (from all tracks)", -1)
                                        return false
                                    end
                                    
                                    -- False means that the next matching selected note-off should not be deselected
                                    tableDeselectNextNoteOff[flags][channel][pitch] = false -- Temporary - must still search ahead
                                    
                                    -- Now check whether this note should be deselected
                                    if runningPPQpos >= timeSelEndPPQinTake then
                                        mustDeselect = true
                                        tableDeselectNextNoteOff[flags][channel][pitch] = true
                                        
                                    elseif runningPPQpos < timeSelStartPPQinTake then
                                        -- Search ahead in MIDI data, looking for a matching note-off so that note length can be determined.
                                        local matchChannelPitchNoteOff = string.char(0x80 | channel, pitch) 
                                        local matchChannelPitchNoteOn  = msg:sub(1,2)
                                        local evPos = nextPos -- Start search at position of next event in MIDI string
                                        local evPPQpos = runningPPQpos
                                        local evOffset, evFlags, evMsg
                                        
                                        repeat
                                            evOffset, evFlags, evMsg, evPos = s_unpack("i4Bs4", MIDIstring, evPos)
                                            -- Don't mind negative offsets of overlapping notes here - the other parts of the script will eventually detect them
                                            evPPQpos = evPPQpos + evOffset
                                            if evFlags == flags
                                            and (evMsg:sub(1,2) == matchChannelPitchNoteOff or (evMsg:sub(1,2) == matchChannelPitchNoteOn and evMsg:byte(3) == 0))
                                            then
                                                if evPPQpos <= timeSelStartPPQinTake then
                                                    mustDeselect = true
                                                    tableDeselectNextNoteOff[flags][channel][pitch] = true
                                                end
                                                
                                                -- If reached Note-off, whether mustDeselect or not, break out of loop
                                                break
                                            end
                                        until evPos >= MIDIlen-12 -- If reached MIDIlen, then the note is an extended, infinite note                                                                      
                                    end                            
                                                                        
                                -- All other event types
                                else
                                    if runningPPQpos < timeSelStartPPQinTake or runningPPQpos >= timeSelEndPPQinTake then
                                        mustDeselect = true
                                    end
                                end                                
                                
                            end -- if flags&1 == 1
                            
                            -- Now write the parsed events to tableEvents
                            if mustDeselect then
                                countDeselects = countDeselects + 1
                                if unchangedPos < prevPos then
                                    t = t + 1
                                    tableEvents[t] = MIDIstring:sub(unchangedPos, prevPos-1)
                                end
                                t = t + 1
                                tableEvents[t] = s_pack("i4Bs4", offset, flags&0xFE, msg)
                                unchangedPos = nextPos
                            end  
                            
                        end -- while nextPos < MIDIlen               
                        
                        -- Iteration complete.  Write the last block of remaining events to table.
                        t = t + 1
                        tableEvents[t] = MIDIstring:sub(unchangedPos)
                        
                        -------------------------------------
                        -- And write edited MIDI data to take
                        if countDeselects > 0 then
                            local newMIDIstring = table.concat(tableEvents)
                            if newMIDIstring:len() == MIDIlen then
                                reaper.MIDI_SetAllEvts(curTake, newMIDIstring)
                            else
                                local trackName, _ = reaper.GetTrackState(reaper.GetMediaItemTake_Track(curTake))
                                reaper.ShowMessageBox('Undefined error parsing the raw MIDI data of the following take:\n   "'
                                                      .. reaper.GetTakeName(curTake)
                                                      .. '"\nin the track:\n   "'
                                                      .. trackName .. '"'
                                                      , "ERROR", 0)
                                reaper.Undo_EndBlock2(0, "INCOMPLETE: Deselect all MIDI events outside time selection (from all tracks)", -1)
                                return false
                            end     
                        end
                        
                    end -- if gotAllOK
                end -- if itemStartTime >= timeSelEnd or itemEndTime <= timeSelStart
            end -- if reaper.ValidatePtr2(0, curItem, "MediaItem_Take*") and reaper.TakeIsMIDI(curTake)
        end -- for t=0, numTakes-1
    end -- if reaper.ValidatePtr2(0, curItem, "MediaItem*")
end -- for i=0, numItems-1



end



function SnapCurMidiGrid(f)
local ME = reaper.MIDIEditor_GetActive()
  if not ME then return end
  local take = reaper.MIDIEditor_GetTake(ME)
local _, arrange_division, _, _ = reaper.GetSetProjectGrid(0, 0)
local SyncArrangeMidi = 41022
local SyncArrangeMidi_State = reaper.GetToggleCommandStateEx(32060,SyncArrangeMidi)
if (SyncArrangeMidi_State == 0) then reaper.MIDIEditor_OnCommand(ME, SyncArrangeMidi) end
if f==0 then  newcurpos = reaper.SnapToGrid( 0,  reaper.GetCursorPosition()) elseif f==1 then 
newcurpos =  reaper.BR_GetNextGridDivision( reaper.GetCursorPosition()) end
reaper.SetEditCurPos2( 0, newcurpos, 0, 0)
local _, midi_division, _, _ = reaper.GetSetProjectGrid(0, 0)
reaper.MIDIEditor_OnCommand(ME, SyncArrangeMidi)
reaper.SetProjectGrid(0, arrange_division)
end


function SelAllInTsDuplicate()
midieditor = reaper.MIDIEditor_GetActive()
reaper.Undo_BeginBlock(); reaper.PreventUIRefresh(1)
reaper.MIDIEditor_OnCommand(midieditor, 40875)  ---Edit: Select all events in time selection
jsUnselectNotInTime()
reaper.MIDIEditor_OnCommand(midieditor, 40734) --Edit: Copy events within project time selection, if any (smart cut)
reaper.PreventUIRefresh(-1); reaper.Undo_EndBlock('Duplicate', -1)
end


function DuplicateEventsOnly()
reaper.Undo_BeginBlock(); reaper.PreventUIRefresh(1)
midieditor = reaper.MIDIEditor_GetActive()
reaper.MIDIEditor_OnCommand(midieditor, 40440) --Navigate: Move edit cursor to end of selected events
reaper.Main_OnCommand(40625, 0)---Start Point of TS 
reaper.MIDIEditor_OnCommand(midieditor, 40639) -- Navigate: Move edit cursor to end of selected events
reaper.Main_OnCommand(40626, 0)---End Point of TS
reaper.MIDIEditor_OnCommand(midieditor, 40734) --Edit: Copy events within project time selection, if any (smart cut)
reaper.Main_OnCommand(40635, 0) -- Remove time selection
reaper.PreventUIRefresh(-1); reaper.Undo_EndBlock('Duplicate', -1)
end

function DuplicateTS()
reaper.Undo_BeginBlock(); reaper.PreventUIRefresh(1)
midieditor = reaper.MIDIEditor_GetActive()
jsUnselectNotInTime()
reaper.MIDIEditor_OnCommand(midieditor, 40734) --Edit: Copy events within project time selection, if any (smart cut)
reaper.PreventUIRefresh(-1); reaper.Undo_EndBlock('Duplicate', -1)
end






notes_ints,cc_ints = IsEventsInTs()
selnote,selcc=IsEventsSel()
if notes_ints==0 and cc_ints==0 then reaper.Main_OnCommand(40635, 0) end -- Remove time selection

startOut, endOut = reaper.GetSet_LoopTimeRange2( 0, 0, 0, 0, 0, 0 ) --  Даем переменную "Time selection"
if endOut == 0  and (selnote ==1 or selcc ==1) then DuplicateEventsOnly()
elseif endOut > 0 and (selnote ==1 or selcc ==1) then  DuplicateTS() 
elseif endOut > 0 and selnote ==0  and selcc ==0  then  SelAllInTsDuplicate()
 
end 


