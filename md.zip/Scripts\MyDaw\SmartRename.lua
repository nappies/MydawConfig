focus = reaper.GetCursorContext() --  Даем переменную значения где сейчас фокус?


if focus == 0 then
reaper.Undo_BeginBlock(); reaper.PreventUIRefresh(1)

tracks_count =  reaper.CountSelectedTracks(0)
    if tracks_count > 1 then
         reaper.Main_OnCommand(reaper.NamedCommandLookup('_XENAKIOS_RENAMETRAXDLG'), 0) -- rename selected tracks
        else
        reaper.Main_OnCommand(40696, 0) -- rename selected track
    end

reaper.PreventUIRefresh(-1); reaper.Undo_EndBlock('Rename', -1)

elseif  focus == 1 then

reaper.Undo_BeginBlock(); reaper.PreventUIRefresh(1)

  item_count =  reaper.CountSelectedMediaItems(0)
    if item_count == 0 then return end
      if item_count > 1 then
          reaper.Main_OnCommand(reaper.NamedCommandLookup('_XENAKIOS_RENMTAKEALL'), 0) -- group rename selected items
          else
          reaper.Main_OnCommand(reaper.NamedCommandLookup('_XENAKIOS_RENMTAKE'), 0) -- rename selected item   
     end


reaper.PreventUIRefresh(-1); reaper.Undo_EndBlock('Rename', -1)
elseif  focus == 2 then
reaper.Undo_BeginBlock(); reaper.PreventUIRefresh(1)

reaper.Main_OnCommand(42091, 0) 

reaper.PreventUIRefresh(-1); reaper.Undo_EndBlock('Rename', -1)
end
