reaper.Main_OnCommand(40514 , 0) --Move  Cursor         

