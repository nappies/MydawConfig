

reaper.PreventUIRefresh(1)

reaper.Main_OnCommand(40289 , 0) --unselect all items   
reaper.Main_OnCommand(40331 , 0) ---unselect all envel




reaper.PreventUIRefresh(-1)








