local script_id = "MyToggleScript_" .. script_name      -- Unique ID for extstate

-- Check current state from extstate
local is_running = reaper.GetExtState(script_id, "running") == "true"

if not is_running then
    -- TURNING ON: Enable auto-terminate, restart, and set toggle ON
    reaper.set_action_options(1 | 2 | 4)  -- 1+2+4 = 7
    reaper.SetExtState(script_id, "running", "true", true)
    
    -- Start deferred loop with cleanup
    local function loop()
        --reaper.Beep(500, 100)  -- Example action (500Hz beep for 100ms)
        reaper.defer(loop)
    end
    
    reaper.atexit(function()
        reaper.SetExtState(script_id, "running", "false", true)
    end)
    
    loop() -- Start the loop
else
    -- TURNING OFF: Enable auto-terminate, restart, and set toggle OFF
    reaper.set_action_options(1 | 2 | 8)  -- 1+2+8 = 11
    reaper.SetExtState(script_id, "running", "false", true)
    -- (Previous instance auto-terminates via flag 1|2)
end
