function m(n,v)
  reaper.ShowConsoleMsg(n.." "..tostring(v) .. "\n")
end

local match = string.match
function literalize(str)
    return str:gsub("[%(%)%.%%%+%-%*%?%[%]%^%$]", function(c) return "%" .. c end)
end






function GetEnvelopePointsInRange(env_track, areaStart, areaEnd)
local env_points = {}

for i = 1, reaper.CountEnvelopePoints(env_track) do
    local retval, time, value, shape, tension, selected = reaper.GetEnvelopePoint(env_track, i - 1)

    if time >= areaStart and time <= areaEnd then
    env_points[#env_points + 1] = {
        id = i-1 ,
        retval = retval,
        time = time,
        value = value,
        shape = shape,
        tension = tension,
        selected = selected
    }
    end
end

return env_points
end



function GetRazorEdits()
    local trackCount = reaper.CountTracks(0)
    local areaMap = {}
    for i = 0, trackCount - 1 do
        local track = reaper.GetTrack(0, i)
        local ret, area = reaper.GetSetMediaTrackInfo_String(track, 'P_RAZOREDITS', '', false)
        if area ~= '' then
            --PARSE STRING
            local str = {}
            for j in string.gmatch(area, "%S+") do
                table.insert(str, j)
            end
        
            --FILL AREA DATA
            local j = 1
            while j <= #str do
                --area data
                local areaStart = tonumber(str[j])
                local areaEnd = tonumber(str[j+1])
                local GUID = str[j+2]
                local isEnvelope = GUID ~= '""'

                --get item data
                local items = {}
                local env_name, env
                local env_points = isEnvelope and {} or nil
                if not isEnvelope then
                   env = AddVolume(track)
                         
        env_name  = reaper.GetEnvelopeName(env )
        env_points = GetEnvelopePointsInRange(env, areaStart, areaEnd)
          
          
                
        
        
        --m("str",str[j])
        --m("str",str[j+1])
        --m("str",str[j+2])
               
        --if GUID == '""' then
          
        
  
        
        --m("areaStart", areaStart)
        --m("areaStart", areaEnd)
          

         local areaData = {
                    areaStart = areaStart,
                    areaEnd = areaEnd,
                    track = track,
                    items = items,
                    isEnvelope = isEnvelope,
                    env_name = env_name,
                    env = env,
                    env_points = env_points,
                    GUID = GUID:sub(2, -2)
                }

                table.insert(areaMap, areaData)

        --end
        end



         j = j + 3
            end
        end
    end

    return areaMap
end



function check_point(env, areaStart, areaEnd)
    local pt1 = reaper.GetEnvelopePointByTime(env, areaStart)
    local pt2 = reaper.GetEnvelopePointByTime(env, areaEnd)

    local retval, Atime, value, shape, tension, selected = reaper.GetEnvelopePoint(env, pt1)
    local retval, Btime, value, shape, tension, selected = reaper.GetEnvelopePoint(env, pt2)

    if Atime ~= areaStart - 0.001 and Btime ~= areaEnd + 0.001 then -- there are no previous edge points
        return false
    end
    return true
end




function AddEnvelope(seltr,utility_index, act)

       env = reaper.GetFXEnvelope( seltr, utility_index, 7, act )
   if  env then 
      
       
	   
	   
	   reaper.Envelope_SortPoints(env);
	  
	  
      end
end


function AddVolume(seltr)

utility = reaper.TrackFX_AddByName( seltr, "Volume Utility", false, 0 )


if utility == -1 then ----------------------------------------------------------IF NOT ADD
utility_index = reaper.TrackFX_GetByName( seltr, "Volume Utility", 1 )
reaper.TrackFX_AddByName( seltr, "Volume Utility", false, 1 )   
    
utility_index = reaper.TrackFX_GetByName( seltr, "Volume Utility", 1 )

reaper.TrackFX_SetOpen( seltr, utility_index, false );


-----------------------------------------------------------
if seltr==reaper.GetMasterTrack(0)   then

while utility_index  > 0  do

reaper.SNM_MoveOrRemoveTrackFX( seltr, utility_index , -1 )
utility_index = reaper.TrackFX_GetByName( seltr, "Volume Utility", 1 )

end
end
-----------------------------------------------------------

AddEnvelope(seltr,utility_index,true)




elseif utility > -1 then ----------------------------------------------------------IF ALREADY ADD 
utility_index = reaper.TrackFX_GetByName( seltr, "Volume Utility", 1 )
env = reaper.GetFXEnvelope( seltr, utility_index, 7, false )
if  env and reaper.ValidatePtr(env, "TrackEnvelope*") then 
      
        local BR_env = reaper.BR_EnvAlloc( env, false )
        local active, visible, armed, inLane, laneHeight, defaultShape, _, _, _, _, faderScaling = reaper.BR_EnvGetProperties( BR_env )
if visible==false then
        reaper.BR_EnvSetProperties( BR_env, true, true, true, inLane, laneHeight, defaultShape, faderScaling )
        reaper.BR_EnvFree( BR_env, true )
end

else 
AddEnvelope(seltr,utility_index,true)

end
end
return env
end


function AddPoints(env,seltr)
  br_env = reaper.BR_EnvAlloc(env, false)
  active, visible, armed, inLane, laneHeight, defaultShape, minValue, maxValue, centerValue, type, faderScaling = reaper.BR_EnvGetProperties(br_env, true, true, true, true, 0, 0, 0, 0, 0, 0, true)

if visible == true and armed == true then
   env_points_count = reaper.CountEnvelopePoints(env)
if env_points_count > 0 then
      for k = 0, env_points_count+1 do
        reaper.SetEnvelopePoint(env, k, timeInOptional, valueInOptional, shapeInOptional, tensionInOptional, false, true)
      end
    end

first_start_val, last_start_val, first_end_val, last_end_val = GetDeleteTimeLoopPoints(env, env_points_count, start_time, end_time)



if last_start_val <= -10  then return 
else
move=-1
end 



    reaper.InsertEnvelopePoint(env, start_time, first_start_val, 0, 0, true, true) -- INSERT startLoop point

   reaper.InsertEnvelopePoint(env, start_time, last_start_val+move, 0, 0, true, true)
   reaper.InsertEnvelopePoint(env, end_time, first_end_val+move, 0, 0, true, true)

    reaper.InsertEnvelopePoint(env, end_time, last_end_val, 0, 0, true, true) -- INSERT EndLoop point
    reaper.BR_EnvFree(br_env, 0)
    reaper.Envelope_SortPoints(env)
  end



 
  
  end
-----------------------------------ene add points

move = -1


function init()
    
  edits = GetRazorEdits()
  
    for i = 1, #edits do
    
            
    if edits[i].env then
        local edge_point_exists = check_point(edits[i].env, edits[i].areaStart, edits[i].areaEnd)
        if not edge_point_exists then
      
      
            local retval, cur_as_start_VAL, dVdS, ddVdS, dddVdS = reaper.Envelope_Evaluate(edits[i].env, edits[i].areaStart, 0, 0)        -- DESTINATION START POINT -- CURENT VALUE AT THAT POSITION
            local retval, cur_as_end_VAL, dVdS, ddVdS, dddVdS = reaper.Envelope_Evaluate(edits[i].env, edits[i].areaEnd, 0, 0) -- DESTINATION END POINT -- CURENT VALUE AT THAT POSITION

            if edits[i].env_points then
            
               reaper.InsertEnvelopePoint(edits[i].env, edits[i].areaStart -0.001, cur_as_start_VAL, 0, 0, true, false) --start value at destination end
                reaper.InsertEnvelopePoint(edits[i].env, edits[i].areaEnd +0.001, cur_as_end_VAL, 0, 0, true, false) --end value at destination end

                reaper.InsertEnvelopePoint(edits[i].env, edits[i].areaStart +0.0001, cur_as_start_VAL+move, 0, 0, true, false) --start value at destination end
                reaper.InsertEnvelopePoint(edits[i].env, edits[i].areaEnd -0.0001, cur_as_end_VAL+move, 0, 0, true, false) --end value at destination end
           
		   
				reaper.TrackList_AdjustWindows(false)
				reaper.UpdateArrange()
		   
		   
            
                y_start = reaper.GetMediaTrackInfo_Value( edits[i].track,"I_TCPY")
                y_end = y_start+reaper.GetMediaTrackInfo_Value( edits[i].track,"I_TCPH")
                
				--m("start_LUA",edits[i].areaStart)
				--m("end_LUA",edits[i].areaEnd)
				
				reaper.Mydaw_ShowTooltips(edits[i].areaStart, edits[i].areaEnd, y_start, y_end, tostring(cur_as_start_VAL+move))
            
            end
   
     
      
      end
        ------------------------------
    end
    end
    
  
   for i = 1, #edits do
       
        if edits[i].env_points and check_point(edits[i].env, edits[i].areaStart, edits[i].areaEnd) then
          
            for j = 1, #edits[i].env_points do
                local env = edits[i].env_points[j]
                
         env.value= math.ceil(env.value)
		
        if (math.abs(env.value) < 10) then
		env.value = env.value+move
		else
		env.value = 0
		end
		
         
		 -- m("env.value",env.value)
        reaper.SetEnvelopePoint(edits[i].env, env.id, env.time, env.value , env.shape, env.tension, env.selected, true)
		
		y_start = reaper.GetMediaTrackInfo_Value( edits[i].track,"I_TCPY")
        y_end = y_start+reaper.GetMediaTrackInfo_Value( edits[i].track,"I_TCPH")
		
		
		reaper.Mydaw_ShowTooltips(edits[i].areaStart, edits[i].areaEnd, y_start, y_end, tostring(env.value))
            end
        end
    end
  
  
  
  
    edits = GetRazorEdits()
	if env then
    reaper.Envelope_SortPoints(env)
	end
  return false


end



init()


