-- @noindex

ICONS = {
    ['PENCIL'] = 'C',
    ['DOCK_DOWN'] = 'D',
    ['UNDOCK'] = 'E',
    ['ARROW_LEFT'] = 'F',
    ['GEAR'] = 'G',
    ['HEADPHONES'] = 'H',
    ['LEFT'] = 'L',
    ['MONEY'] = 'M',
    ['MINUS'] = 'N',
    ['POLARITY'] = 'O',
    ['PLUS'] = 'P',
    ['RIGHT'] = 'R',
    ['STAR'] = 'S',
    ['TRASH'] = 'T',
    ['UNDO'] = 'U',
    ['ENVELOPE'] = 'V',
    ['ARROW_RIGHT'] = 'W',
    ['CLOSE'] = 'X',
    ['STEREO'] = 'Y',
    ['MONO'] = 'Z',
    ['SEARCH'] = '*'
}