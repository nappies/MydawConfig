local change =  1  ---Increase in DB
local length =  3 * 0.001  ---Fade Length





local function eq( a, b )
  return math.abs( a - b ) < 0.00001
end


---------------------------------



function RazorEditSelectionExists()

    for i=0, reaper.CountTracks(0)-1 do

        local retval, x = reaper.GetSetMediaTrackInfo_String(reaper.GetTrack(0,i), "P_RAZOREDITS", "string", false)

        if x ~= "" then return true end

    end
    
    return false

end

-----------------------

function GetEnvelopePointsInRange(envelopeTrack, areaStart, areaEnd)
    local envelopePoints = {}

    for i = 1, reaper.CountEnvelopePoints(envelopeTrack) do
        local retval, time, value, shape, tension, selected = reaper.GetEnvelopePoint(envelopeTrack, i - 1)

        if time >= areaStart and time <= areaEnd then --point is in range
            envelopePoints[#envelopePoints + 1] = {
                id = i-1 ,
                time = time,
                value = value,
                shape = shape,
                tension = tension,
                selected = selected
            }
        end
    end

    return envelopePoints
end


-----------------------

function GetItemsInRange(track, areaStart, areaEnd, areaTop, areaBottom)
    local items = {}
    local itemCount = reaper.CountTrackMediaItems(track)
    for k = 0, itemCount - 1 do 
        local item = reaper.GetTrackMediaItem(track, k)
        local pos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
        local length = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
        local itemEndPos = pos+length
        
        if areaBottom ~= nil then
          itemTop = reaper.GetMediaItemInfo_Value(item, "F_FREEMODE_Y")
          itemBottom = itemTop + reaper.GetMediaItemInfo_Value(item, "F_FREEMODE_H")
          --msg("area: "..tostring(areaTop).." "..tostring(areaBottom).."\n".."item: "..itemTop.." "..itemBottom.."\n\n")
        end

        --check if item is in area bounds
        if itemEndPos > areaStart and pos < areaEnd then
        
          if areaBottom and itemTop then
            if itemTop < areaBottom - 0.001 and itemBottom > areaTop + 0.001 then
              table.insert(items,item)
            end
          else
            table.insert(items,item)
          end
          
        end

    end --end for cycle

    return items
end

-----------------------
-----------------------

function ParseAreaPerLane(RawTable, itemH) --one level metatable
  local ParsedTable = {}
  local PreParsedTable = {}
  
  local lanesN = math.floor((1/itemH)+0.5)
  local laneW = 1/lanesN
  
  for i=1, lanesN do
    PreParsedTable[i] = {}
  end
  
  ---------------
  for i=1, #RawTable do
      --area data
      local areaStart = tonumber(RawTable[i][1])
      local areaEnd = tonumber(RawTable[i][2])
      local GUID = RawTable[i][3]
      local areaTop = tonumber(RawTable[i][4])
      local areaBottom = tonumber(RawTable[i][5])
      
    if not isEnvelope then
      areaWidth = math.floor(((areaBottom - areaTop)/itemH)+0.5) -- how many lanes include
      for w=1, areaWidth do
        local areaLane = math.floor((areaBottom/(laneW*w))+0.5)
        --msg(areaLane)
        local smallRect = {
        
              areaStart,
              areaEnd,
              GUID,
              areaBottom - (laneW*w), --areaTop
              areaBottom - (laneW*(w-1)), --areaBottom
              }

        table.insert(PreParsedTable[areaLane], smallRect)
      end
    else
      table.insert(ParsedTable, RawTable[i])
    end
    
  end
  -------------
  
  for i=1, #PreParsedTable do
    local lane = PreParsedTable[i]
    local prevEnd = nil
    for r=1, #lane do
      local smallRect = lane[r]
      
      if prevEnd ~= smallRect[1] then
        table.insert(ParsedTable, smallRect)
      else
        ParsedTable[#ParsedTable][2] = smallRect[2]
      end
      
      prevEnd = smallRect[2]
    end
  end
  
  return ParsedTable
end

-----------------------
-----------------------

function GetRazorEdits()
    local NeedPerLane = true
    local trackCount = reaper.CountTracks(0)
    local areaMap = {}
    for i = 0, trackCount - 1 do
        local track = reaper.GetTrack(0, i)
        local mode = reaper.GetMediaTrackInfo_Value(track,"I_FREEMODE")
        if mode ~= 0 then
        ----NEW WAY----
        --reaper.ShowConsoleMsg("NEW WAY\n")
        
          local ret, area = reaper.GetSetMediaTrackInfo_String(track, 'P_RAZOREDITS_EXT', '', false)
          
        if area ~= '' then

            --PARSE STRING and CREATE TABLE
            local TRstr = {}
            
            for s in area:gmatch('[^,]+')do
              table.insert(TRstr, s)
            end
            
            for i=1, #TRstr do
            
              local rect = TRstr[i]
              TRstr[i] = {}
              for j in rect:gmatch("%S+") do
                table.insert(TRstr[i], j)
              end
              
            end
            
            local testItemH = reaper.GetMediaItemInfo_Value(reaper.GetTrackMediaItem(track,0), "F_FREEMODE_H")
            
            local AreaParsed = ParseAreaPerLane(TRstr, testItemH)
            
            local TRareaTable
            if NeedPerLane == true then TRareaTable = AreaParsed else TRareaTable = TRstr end
        
            --FILL AREA DATA
            local i = 1
            
            while i <= #TRareaTable do
                --area data
                local areaStart = tonumber(TRareaTable[i][1])
                local areaEnd = tonumber(TRareaTable[i][2])
                local GUID = TRareaTable[i][3]
                local areaTop = tonumber(TRareaTable[i][4])
                local areaBottom = tonumber(TRareaTable[i][5])
                local isEnvelope = GUID ~= '""'
                

                --get item/envelope data
                local items = {}
                local envelopeName, envelope
                local envelopePoints
                
                if not isEnvelope then
                --reaper.ShowConsoleMsg(areaTop.." "..areaBottom.."\n\n")
                    items = GetItemsInRange(track, areaStart, areaEnd, areaTop, areaBottom)
                else
                    envelope = reaper.GetTrackEnvelopeByChunkName(track, GUID:sub(2, -2))
                    local ret, envName = reaper.GetEnvelopeName(envelope)

                    envelopeName = envName
                    envelopePoints = GetEnvelopePointsInRange(envelope, areaStart, areaEnd)
                end

                local areaData = {
                    areaStart = areaStart,
                    areaEnd = areaEnd,
                    areaTop = areaTop,
                    areaBottom = areaBottom,
                    
                    track = track,
                    items = items,
                    
                    --envelope data
                    isEnvelope = isEnvelope,
                    envelope = envelope,
                    envelopeName = envelopeName,
                    envelopePoints = envelopePoints,
                    GUID = GUID:sub(2, -2)
                }

                table.insert(areaMap, areaData)

                i=i+1
            end
          end
        else  
        
        ---OLD WAY for backward compatibility-------
        
          local ret, area = reaper.GetSetMediaTrackInfo_String(track, 'P_RAZOREDITS', '', false)
           if area ~= '' then
            --PARSE STRING
            local str = {}
            for j in string.gmatch(area, "%S+") do
                table.insert(str, j)
            end
        
            --FILL AREA DATA
            local j = 1
            while j <= #str do
                --area data
                local areaStart = tonumber(str[j])
                local areaEnd = tonumber(str[j+1])
                local GUID = str[j+2]
                local isEnvelope = GUID ~= '""'
        
                --get item/envelope data
                local items = {}
                local envelopeName, envelope
                local envelopePoints
                
                if not isEnvelope then
                    items = GetItemsInRange(track, areaStart, areaEnd)
                else
                    envelope = reaper.GetTrackEnvelopeByChunkName(track, GUID:sub(2, -2))
                    local ret, envName = reaper.GetEnvelopeName(envelope)
        
                    envelopeName = envName
                    envelopePoints = GetEnvelopePointsInRange(envelope, areaStart, areaEnd)
                end
        
                local areaData = {
                    areaStart = areaStart,
                    areaEnd = areaEnd,
                    
                    track = track,
                    items = items,
                    
                    --envelope data
                    isEnvelope = isEnvelope,
                    envelope = envelope,
                    envelopeName = envelopeName,
                    envelopePoints = envelopePoints,
                    GUID = GUID:sub(2, -2)
                }
        
                table.insert(areaMap, areaData)
        
                j = j + 3
            end
          end  ---OLD WAY END
        end
    end

    return areaMap
end

--------------------------------




local undo_str = "Decrease Volume"
change = 10 ^ ( change / 20 )
local undo = false
local vol_env = "\n<VOLENV\nEGUID " .. reaper.genGuid("") ..
"\nACT 1 -1\nVIS 0 1 1\nLANEHEIGHT 0 0\nARM 1\nDEFSHAPE 0 -1 -1\nVOLTYPE 1\nPT 0 1 0\n>\n"

local function EnableTakeVol(take, item)
  local retval,takeGUID = reaper.GetSetMediaItemTakeInfo_String( take, "GUID", 0, 0 )
  local take_cnt = reaper.CountTakes( item )
  local fx_count = reaper.TakeFX_GetCount( take )
  local _, chunk = reaper.GetItemStateChunk( item, "", false )
  local t = {}
  local i = 0
  local insert
  local foundTake = take_cnt == 1
  local search_take_end = true
  for line in chunk:gmatch("[^\n]+") do
    i = i + 1
    t[i] = line
    if not foundTake then
      if line:find(takeGUID:gsub("-", "%%-")) then
      foundTake = true
      end
    end
    if foundTake then
      if (not insert) and i > 30 then
        if line:find("^<.-ENV$") then
          insert = i
        elseif fx_count > 0 then
          if line:find("^TAKE_FX_HAVE_") then
            insert = i + 1
          end
        end
      end
      if not insert and search_take_end and line == ">" then
        search_take_end = false
        insert = i + 1
      end
    end
  end
  chunk = table.concat(t, "\n", 1, insert-1 ) .. vol_env .. table.concat(t, "\n", insert )
  reaper.SetItemStateChunk( item, chunk, true )
  return reaper.GetTakeEnvelopeByName( take, "Volume" )
end

local function adjustPoints(env, id1, id2, mode, change)
  for id = id1, id2 do
    local _, time, val, shape, tens, sel = reaper.GetEnvelopePoint( env, id )
    local newval = mode == 0 and val*change or
           reaper.ScaleToEnvelopeMode( 1, (reaper.ScaleFromEnvelopeMode( 1, val )*change))
    reaper.SetEnvelopePoint( env, id, time, newval, shape, tens, sel, true )
  end
end

reaper.PreventUIRefresh( 1 )


razorEdits = GetRazorEdits()


      for i = 1, #razorEdits do
          local areaData = razorEdits[i]
          if not areaData.isEnvelope then
            
            local items = areaData.items
            
            for i = 1, #items do
                  local item = items[i]
                  local take = reaper.GetActiveTake( item )
                  local ST, EN = areaData.areaStart, areaData.areaEnd
          local playrate = reaper.GetMediaItemTakeInfo_Value(take,"D_PLAYRATE")
                  local position = reaper.GetMediaItemInfo_Value( item, "D_POSITION" )
                  local End = position + reaper.GetMediaItemInfo_Value( item, "D_LENGTH" )
                  local inside_area = true
                  if position >= EN or End <= ST then inside_area = false end
                  if inside_area then
                  if ST < position then ST = position end
                  if EN > End then EN = End end
                  local env = reaper.GetTakeEnvelopeByName( take, "Volume" )
                  if not env or not reaper.ValidatePtr2( 0, env, "TrackEnvelope*" ) then env = EnableTakeVol(take, item) end
                  local mode = reaper.GetEnvelopeScalingMode( env )
                  local ST_in_item = (ST - position+0.01)* playrate
                  local EN_in_item = (EN - position)* playrate
                  local id1 = reaper.GetEnvelopePointByTime( env, ST_in_item )
                  local id2 = reaper.GetEnvelopePointByTime( env, EN_in_item )
                  local _, time = reaper.GetEnvelopePoint( env, id1 )
                  local _, time2 = reaper.GetEnvelopePoint( env, id2 )
                  if eq(time, ST_in_item) and eq(time2, EN_in_item) then
                    adjustPoints(env, id1, id2, mode, change)
                  else
        


              if eq(time, ST_in_item) and (not eq(time2, EN_in_item)) then
          
      
              local samplerate = reaper.GetMediaSourceSampleRate( reaper.GetMediaItemTake_Source( take ) )
              local _, val2 = reaper.Envelope_Evaluate( env, EN_in_item + length, samplerate, 5 )
              local newval2 = mode == 0 and val2*change or
                 reaper.ScaleToEnvelopeMode( 1, (reaper.ScaleFromEnvelopeMode( 1, val2 )*change))
              local noSorted = true
              if id1 ~= id2 then
              noSorted = false
              end
              reaper.InsertEnvelopePoint( env, EN_in_item, newval2, 0, 0, 0, noSorted )
              reaper.InsertEnvelopePoint( env, EN_in_item + length, val2, 0, 0, 0, noSorted )
              if not noSorted then
              adjustPoints(env, id1 + 3, id2 + 2, mode, change)
              end

                  
              elseif (not eq(time, ST_in_item)) and eq(time2, EN_in_item) then
          
              
              local samplerate = reaper.GetMediaSourceSampleRate( reaper.GetMediaItemTake_Source( take ) )
              local _, val1 = reaper.Envelope_Evaluate( env, ST_in_item - length, samplerate, 5 )
              local newval1 = mode == 0 and val1*change or
                 reaper.ScaleToEnvelopeMode( 1, (reaper.ScaleFromEnvelopeMode( 1, val1 )*change))
              local noSorted = true
              if id1 ~= id2 then
              noSorted = false
              end
              reaper.InsertEnvelopePoint( env, ST_in_item - length, val1, 0, 0, 0, noSorted )
              reaper.InsertEnvelopePoint( env, ST_in_item, newval1, 0, 0, 0, noSorted )
              if not noSorted then
              adjustPoints(env, id1 + 3, id2 + 2, mode, change)
              end
      
          
               else
         
        
          
              local samplerate = reaper.GetMediaSourceSampleRate( reaper.GetMediaItemTake_Source( take ))
              local _, val1 = reaper.Envelope_Evaluate( env, ST_in_item - length, samplerate, 5 )
              local _, val2 = reaper.Envelope_Evaluate( env, EN_in_item + length, samplerate, 5 )
              local newval1 = mode == 0 and val1*change or
                 reaper.ScaleToEnvelopeMode( 1, (reaper.ScaleFromEnvelopeMode( 1, val1 )*change))
              local newval2 = mode == 0 and val2*change or
                 reaper.ScaleToEnvelopeMode( 1, (reaper.ScaleFromEnvelopeMode( 1, val2 )*change))
              local noSorted = true
              if id1 ~= id2 then
              noSorted = false
              end
              reaper.InsertEnvelopePoint( env, ST_in_item - length, val1, 0, 0, 0, noSorted )
              reaper.InsertEnvelopePoint( env, ST_in_item, newval1, 0, 0, 0, noSorted )
              reaper.InsertEnvelopePoint( env, EN_in_item, newval2, 0, 0, 0, noSorted )
              reaper.InsertEnvelopePoint( env, EN_in_item + length, val2, 0, 0, 0, noSorted )
              if not noSorted then
              adjustPoints(env, id1 + 3, id2 + 2, mode, change)
            end
 
          
          
          end
        
          
          end
                  reaper.Envelope_SortPoints( env )
                  undo = true
                  end
                end

       

        end
    end

reaper.PreventUIRefresh( -1 )

if undo then
  reaper.Undo_OnStateChangeEx( undo_str, 1, -1 )
else
  reaper.defer(function() end)
end
