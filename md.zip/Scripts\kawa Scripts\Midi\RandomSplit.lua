--[[ 
* ReaScript Name: kawa_MIDI_MorseSplit_Random. 
* Version: 2017/02/09 
* Author: kawa_ 
* Author URI: http://forum.cockos.com/member.php?u=105939 
* link: https://bitbucket.org/kawaCat/reascript-m2bpack/ 
--]]
if (package.config:sub(1, 1) == "\\") then
end
math.randomseed(reaper.time_precise() * os.time() / 1e3)
local n = 40815
local f = 40659
function deepcopy(t)
    local n = type(t)
    local e
    if n == "table" then
        e = {}
        for n, t in next, t, nil do
            e[deepcopy(n)] = deepcopy(t)
        end
        setmetatable(e, deepcopy(getmetatable(t)))
    else
        e = t
    end
    return e
end
function createMIDIFunc3(p)
    local e = {}
    e.allNotes = {}
    e.selectedNotes = {}
    e._editingNotes_Original = {}
    e.editingNotes = {}
    e.editorHwnd = nil
    e.take = nil
    e.mediaItem = nil
    e.mediaTrack = nil
    e._limitMaxCount = 1e3
    e._isSafeLimit = true
    function e:_showLimitNoteMsg()
        reaper.ShowMessageBox("over " .. tostring(self._limitMaxCount) .. " clip num .\nstop process", "stop.", 0)
    end
    function e:getMidiNotes()
        reaper.PreventUIRefresh(2)
        reaper.MIDIEditor_OnCommand(self.editorHwnd, n)
        reaper.MIDIEditor_OnCommand(self.editorHwnd, f)
        reaper.PreventUIRefresh(-1)
        local r = {}
        local o = {}
        local c, a, s, t, n, d, f, l = reaper.MIDI_GetNote(self.take, 0)
        local e = 0
        while c do
            t = reaper.MIDI_GetProjQNFromPPQPos(self.take, t)
            n = reaper.MIDI_GetProjQNFromPPQPos(self.take, n)
            local i = {
                selection = a,
                mute = s,
                startQn = t,
                endQn = n,
                chan = d,
                pitch = f,
                vel = l,
                take = self.take,
                idx = e,
                length = n - t
            }
            table.insert(r, i)
            if (a == true) then
                table.insert(o, i)
            end
            e = e + 1
            c, a, s, t, n, d, f, l = reaper.MIDI_GetNote(self.take, e)
            if (e > self._limitMaxCount) then
                r = {}
                o = {}
                self:_showLimitNoteMsg()
                self._isSafeLimit = false
                break
            end
        end
        self.m_existMaxNoteIdx = e
        return r, o
    end
    function e:detectTargetNote()
        if (self._isSafeLimit == false) then
            return {}
        end
        if (#self.selectedNotes >= 1) then
            self._editingNotes_Original = deepcopy(self.selectedNotes)
            self.editingNotes = deepcopy(self.selectedNotes)
            return self.editingNotes
        else
            self._editingNotes_Original = deepcopy(self.allNotes)
            self.editingNotes = deepcopy(self.allNotes)
            return self.editingNotes
        end
    end
    function e:correctOverWrap()
        reaper.MIDIEditor_OnCommand(self.editorHwnd, f)
    end
    function e:flush(t, e)
        self:_deleteAllOriginalNote()
        self:_editingNoteToMediaItem(t)
        self:correctOverWrap()
        if (e == true) then
            reaper.MIDI_Sort(self.take)
        end
    end
    function e:insertNoteFromC(e)
        e.idx = self.m_existMaxNoteIdx + 1
        self.m_existMaxNoteIdx = self.m_existMaxNoteIdx + 1
        table.insert(self.editingNotes, e)
        return e
    end
    function e:insertNotesFromC(e)
        for t, e in ipairs(e) do
            self:insertNoteFromC(e)
        end
        return e
    end
    function e:insertMidiNote(l, r, e, t, n, o, a)
        local e = e
        local t = t
        local r = r
        local n = n or false
        local i = a or false
        local o = o or 1
        local a = l
        local l = self.m_existMaxNoteIdx + 1
        self.m_existMaxNoteIdx = self.m_existMaxNoteIdx + 1
        local e = {
            selection = n,
            mute = i,
            startQn = e,
            endQn = t,
            chan = o,
            pitch = a,
            vel = r,
            take = self.take,
            idx = l,
            length = t - e
        }
        table.insert(self.editingNotes, e)
    end
    function e:deleteNote(t)
        for e, n in ipairs(self.editingNotes) do
            if (n.idx == t.idx) then
                table.remove(self.editingNotes, e)
                break
            end
        end
    end
    function e:deleteNotes(e)
        if (e == self.editingNotes) then
            self.editingNotes = {}
            return
        end
        for t, e in ipairs(e) do
            self:deleteNote(e)
        end
    end
    function e:_init(e)
        self.editorHwnd = reaper.MIDIEditor_GetActive()
        self.take = e or reaper.MIDIEditor_GetTake(self.editorHwnd)
        if (self.take == nil) then
            return
        end
        self.allNotes, self.selectedNotes = self:getMidiNotes()
        self.mediaItem = reaper.GetMediaItemTake_Item(self.take)
        self.mediaTrack = reaper.GetMediaItemTrack(self.mediaItem)
    end
    function e:_deleteAllOriginalNote(e)
        local e = e or self._editingNotes_Original
        while (#e > 0) do
            local t = #e
            reaper.MIDI_DeleteNote(e[t].take, e[t].idx)
            table.remove(e, #e)
        end
    end
    function e:_insertNoteToMediaItem(e, a)
        local t = self.take
        if t == nil then
            return
        end
        local l = e.selection or false
        local o = e.mute
        local i = reaper.MIDI_GetPPQPosFromProjQN(t, e.startQn)
        local c = reaper.MIDI_GetPPQPosFromProjQN(t, e.endQn)
        local s = e.chan
        local d = e.pitch
        local r = e.vel
        local n = 0
        if (a == true) then
            local e = .9
            local o = reaper.MIDI_GetProjQNFromPPQPos(t, e)
            local e = reaper.MIDI_GetProjQNFromPPQPos(t, e * 2)
            n = e - o
        end
        reaper.MIDI_InsertNote(t, l, o, i, c - n, s, d, r, true)
    end
    function e:_editingNoteToMediaItem(t)
        for n, e in ipairs(self.editingNotes) do
            self:_insertNoteToMediaItem(e, t)
        end
    end
    e:_init(p)
    return e
end
if (package.config:sub(1, 1) == "\\") then
end
local d = "kawa MIDI Split Random Morse"
if (d == reaper.Undo_CanUndo2(0)) then
    reaper.PreventUIRefresh(30)
    reaper.Undo_DoUndo2(0)
    reaper.UpdateArrange()
    reaper.PreventUIRefresh(-1)
end
math.randomseed(reaper.time_precise() * os.time() / 1e3)
local e = {}
e["A"] = {1, 2}
e["B"] = {2, 1, 1, 1}
e["C"] = {2, 1, 2, 1}
e["D"] = {2, 1, 1}
e["E"] = {1}
e["F"] = {1, 1, 2}
e["G"] = {2, 2, 1}
e["H"] = {1, 1, 1, 1}
e["I"] = {1, 1}
e["J"] = {1, 2, 2, 2}
e["K"] = {2, 1, 2}
e["L"] = {1, 2, 1, 1}
e["M"] = {2, 2}
e["N"] = {2, 1}
e["O"] = {2, 2, 2}
e["P"] = {1, 2, 2, 1}
e["Q"] = {2, 2, 1, 2}
e["R"] = {1, 2, 1}
e["S"] = {1, 1, 1}
e["T"] = {2}
e["U"] = {1, 1, 2}
e["V"] = {1, 1, 1, 2}
e["W"] = {1, 2, 2}
e["X"] = {2, 1, 1, 2}
e["Y"] = {2, 1, 2, 2}
e["Z"] = {2, 2, 1, 1}
e["1"] = {1, 2, 2, 2, 2}
e["2"] = {1, 1, 2, 2, 2}
e["3"] = {1, 1, 1, 2, 2}
e["4"] = {1, 1, 1, 1, 2}
e["5"] = {2, 1, 1, 1, 1}
e["6"] = {2, 2, 1, 1, 1}
e["7"] = {2, 2, 2, 1, 1}
e["8"] = {2, 2, 2, 2, 1}
e["9"] = {2, 2, 2, 2, 1}
e["0"] = {2, 2, 2, 2, 2}
e["."] = {1, 2, 1, 2, 1, 2}
e[","] = {2, 2, 1, 1, 2, 2}
e["?"] = {1, 1, 2, 2, 1, 1}
e["!"] = {2, 1, 2, 1, 2, 2}
e["-"] = {2, 1, 1, 1, 1, 2}
e["/"] = {2, 1, 1, 2, 1}
e["@"] = {1, 2, 2, 1, 2, 1}
e["("] = {2, 1, 2, 2, 1}
e[")"] = {2, 1, 2, 2, 1, 2}
function string:split(e)
    local t, e = e or ":", {}
    local t = string.format("([^%s]+)", t)
    self:gsub(
        t,
        function(t)
            e[#e + 1] = t
        end
    )
    return e
end
local function c(t)
    local e = 0
    local n = string.len(t)
    return function()
        e = e + 1
        if (e > n) then
            return nil
        else
            return e, string.sub(t, e, e)
        end
    end
end
local function s(n, o)
    local t = createMIDIFunc3()
    local e = t:detectTargetNote()
    if (#e < 1 or t.take == nil or #n < 1) then
        return
    end
    local c = n
    local n = o or .5
    if (n < .05) then
        n = .5
    end
    local o, r, r = reaper.MIDI_GetGrid(t.take)
    local i = {}
    local r = {}
    local l = o
    for e, a in ipairs(e) do
        local e = a
        local d = e.endQn
        local t = e.startQn
        local o = true
        while (o == true) do
            for i, a in ipairs(c) do
                if (a ~= -1) then
                    local a = a * l
                    local e = deepcopy(e)
                    e.startQn = t
                    local n = a * n
                    e.endQn = e.startQn + n
                    e.length = e.endQn - e.startQn
                    e.selection = true
                    if (e.endQn > d) then
                        o = false
                    else
                        table.insert(r, e)
                        t = e.startQn + a
                    end
                else
                    local e = t + l
                    if (e > d) then
                        o = false
                    else
                        t = e
                    end
                end
            end
        end
        table.insert(i, a)
    end
    t:deleteNotes(i)
    t:insertNotesFromC(r)
    t:flush(true, true)
end
local function l(t, o)
    local n = t or "A"
    local t = {}
    local o = o or 1
    n = string.upper(n)
    for r, n in c(n) do
        if (e[n] ~= nil) then
            local e = e[n]
            for n, e in ipairs(e) do
                table.insert(t, e)
            end
            if (o >= 1) then
                for e = 1, o do
                    table.insert(t, -1)
                end
            end
        end
    end
    return t
end
local function a()
    local o = (math.random() * .4) + .5
    local r = math.floor(math.random() * 2.5)
    local n = 4
    local t = ""
    for n = 1, n do
        local n = string.char(math.floor(25 * math.random()) + 64)
        while (e[n] == nil) do
            n = string.char(math.floor(25 * math.random()) + 64)
        end
        t = t .. n
    end
    local e = l(t, r)
    s(e, o)
    reaper.Undo_OnStateChange2(0, d)
end
a()

