reaper.PreventUIRefresh(1) 
reaper.Main_OnCommand(40289, 0) ---Item: Unselect all items
reaper.Main_OnCommand(40331, 0)---Envelope: Unselect all points
reaper.Main_OnCommand(40635 , 0) ----remove time selection
reaper.PreventUIRefresh(-1)
