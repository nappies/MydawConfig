

reaper.PreventUIRefresh(1)
reaper.Main_OnCommand(40514 , 0) -----move cursor to mouse cursor  no snapping           
reaper.Main_OnCommand(40769 , 0) --unselect all items 
reaper.Main_OnCommand(40635 , 0) ----remove time selection
reaper.Main_OnCommand(41110 , 0) ---select track under mouse 

reaper.PreventUIRefresh(-1)


